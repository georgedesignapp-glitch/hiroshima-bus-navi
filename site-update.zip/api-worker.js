/* Offline equivalent of the shared UI's API contract. No realtime fabrication. */
const hhmm=sec=>`${String(Math.floor(sec/3600)).padStart(2,'0')}:${String(Math.floor(sec%3600/60)).padStart(2,'0')}`;
const relay=new BusRelay(read,save);
let viewSnapshot={trip_updates:[],vehicles:[],alerts:[]};
const scheduleCache=new Map();
const dayNow=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tokyo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(relay.now()));
const epoch=(day,sec)=>Date.parse(day+'T00:00:00+09:00')/1000+sec;
const range=(source,day,group)=>source.coverage.filter(c=>!group||group.companies.includes(c.company)).map(c=>({...c,available:c.start<=day&&day<=c.end}));
const rt=()=>relay.status(currentSource?.companies||[]);
let currentSource;
const dataStatus=()=>({state:'idle',updated_at:0,progress:0,message:'PWA検証版：選んだバス停の時刻表を端末に保存します。'});
function polesOf(p){return p.pole_ids?JSON.parse(p.pole_ids):p.pole_id?[p.pole_id]:[];}
function updateFor(r,day,base=[]){return r._update||viewSnapshot.trip_updates.find(v=>BusTripSupport.matches(v,r.company,r.trip_id,day,dayNow(),base));}
function decorate(r,day,source){const meta=source.companies.find(c=>c.slug===r.company)||{},base=scheduleCache.get(r.company+'|'+r.trip_id)||[],tu=updateFor(r,day,base);let p=BusRTModel.prediction(r,day,tu,base),event_kind='departure';if(tu&&(r.arrival_only||p.predicted_epoch==null&&p.status==='scheduled')){const arrival=BusRTModel.prediction(r,day,tu,base,true);if(arrival.predicted_epoch!=null){p=arrival;event_kind='arrival';}}
 const sec=r.departure_sec,chosen=p.predicted_epoch??p.scheduled_epoch,{_update,...visible}=r;return {...visible,...p,departure_time:hhmm(sec),scheduled_time:hhmm(sec),realtime_time:p.predicted_epoch==null?'':hhmm(p.predicted_epoch-epoch(day,0)),service_date:day,company_name:meta.name,company_short:meta.short,company_color:meta.color,sort_epoch:chosen,departure_state:relay.now()/1000<epoch(day,r.origin_sec??sec)&&!['cancelled','deleted','skipped'].includes(p.status)?'waiting':'running',delay_known:p.delay_sec!=null,delay_min:p.delay_sec==null?null:p.delay_sec/60,minutes_until:Math.max(0,Math.ceil((chosen-relay.now()/1000)/60)),is_next_day_preview:false,event_kind};}
const decoded=new Map();
const catalogs=new Map();
async function notices(source,scope=null){
 const active=viewSnapshot.alerts.filter(a=>!scope||(a.informed_entity||[]).length===0||(a.informed_entity||[]).some(e=>scope.some(r=>r.company===a.company&&(!e.route_id||e.route_id===r.route_id)&&(!e.trip?.trip_id||e.trip.trip_id===r.trip_id)&&(!e.stop_id||e.stop_id===r.stop_id)&&(e.direction_id==null||String(e.direction_id)===String(r.direction_id)))));
 if(!active.length)return [];if(!catalogs.has(source.notice_file.revision))catalogs.set(source.notice_file.revision,await rows(source.notice_file));const catalog=catalogs.get(source.notice_file.revision);
 const target=(company,e)=>{const labels=[];let unresolved=false;const t=e.trip||{},trip=catalog.trips[company+'|'+t.trip_id];if(t.trip_id){if(trip)labels.push(`便：${[trip[0],trip[1]].filter(Boolean).join(' ')} ／ ${trip[3]} ${hhmm(trip[4])}発 → ${trip[2]||trip[5]}`);else{labels.push('便：保存済み時刻表から名称・時刻を照合できません');unresolved=true;}if(t.start_date)labels.push('便の運行日：'+t.start_date);if(t.start_time)labels.push('配信指定の便開始時刻：'+t.start_time);}else if(e.route_id){const routes=(catalog.routes[company+'|'+e.route_id]||[]).filter(r=>e.direction_id==null||String(e.direction_id)===String(r[2]));if(routes.length)labels.push('路線：'+[...new Set(routes.map(r=>[r[0],r[1]].filter(Boolean).join(' ')||'名称未設定'))].join('・'));else{labels.push('路線：保存済み時刻表から名称を照合できません');unresolved=true;}}
 if(e.stop_id){const stop=catalog.stops[company+'|'+e.stop_id];if(stop)labels.push('バス停：'+stop[0]+(stop[1]?' ［'+stop[1]+'］のりば':''));else{labels.push('バス停：保存済み時刻表から名称を照合できません');unresolved=true;}}if(!labels.length)labels.push('対象路線・便：配信に詳細の指定なし');return {labels,unresolved,trip:!!t.trip_id,trip_key:t.trip_id?JSON.stringify([company,t.trip_id,t.start_date||'',t.start_time||'']):null};};
 const tidy=v=>String(v||'').normalize('NFKC').replace(/[\u200b\u200c\u200d\ufeff]/g,'').trim().replace(/\s+/g,' '),merged=new Map();
 for(const a of active){const key=JSON.stringify([a.company,tidy(a.header_text),tidy(a.description_text),a.url||'']);const old=merged.get(key);const entities=[...(old?.informed_entity||[]),...(a.informed_entity||[])],periods=[...(old?.active_period||[]),...(a.active_period||[])];merged.set(key,{...a,header:a.header_text||'',description:a.description_text||'',informed_entity:[...new Map(entities.map(e=>[JSON.stringify(e),e])).values()],active_period:[...new Map(periods.map(e=>[JSON.stringify(e),e])).values()]});}
 return [...merged.values()].map(a=>{const targets=(a.informed_entity.length?a.informed_entity:[{}]).map(e=>target(a.company,e));return {...a,targets,target_trip_count:new Set(targets.filter(t=>t.trip).map(t=>t.trip_key)).size};});
}
async function groupRows(group){if(decoded.has(group.revision))return decoded.get(group.revision);const table=await rows(group);for(const [key,points] of Object.entries(table.schedules||{}))scheduleCache.set(key,points.map(p=>({stop_sequence:p[0],departure_sec:p[1],arrival_sec:p[2],stop_id:typeof p[3]==='number'?table.stop_ids[p[3]]:p[3]})));const result=table.rows.map(r=>Object.fromEntries(table.columns.map((c,i)=>[c,r[i]])));decoded.set(group.revision,result);if(decoded.size>24)decoded.delete(decoded.keys().next().value);return result;}
function activeRows(raw,source,day,poles=[]){return raw.filter(r=>(source.services[r.service_key]||[]).includes(day)&&r.pickup_type!==1&&!r.is_last_stop&&(!poles.length||poles.includes(r.same_pole_id)));}
async function tripRows(company,trip,source){const file=source.trip_files[source.trip_shards[company+'|'+trip]];if(!file)throw Error('便の停車順が見つかりません');const table=await rows(file);const list=table.trips[company+'|'+trip];if(!list)throw Error('便の停車順が見つかりません');return list.map(r=>Object.fromEntries(table.columns.map((c,i)=>[c,r[i]])));}
let operationsPromise,dynamicCache;
function operations(){return operationsPromise||=(rows(BusOperations).catch(e=>{operationsPromise=null;throw e;}));}
async function dynamicFor(source,day){
 const key=relay.generation+'|'+day;
 if(dynamicCache?.key===key)return dynamicCache.value;
 const value=(async()=>{
  if(!viewSnapshot.trip_updates.some(v=>[1,5,6,8].includes(v.trip?.schedule_relationship)))return {trips:new Map(),unresolved:[],replaced:new Set()};
  const result=await BusTripSupport.dynamic(viewSnapshot,day,dayNow(),await operations(),(company,trip)=>tripRows(company,trip,source),source.group_codes);
  for(const [key,list] of result.trips)scheduleCache.set(key,list);
  return result;
 })().catch(()=>({trips:new Map(),unresolved:[{reason:'臨時便の補助データを取得できません。通信中に開き直してください。'}],replaced:new Set(viewSnapshot.trip_updates.filter(v=>v.trip?.schedule_relationship===5&&((v.trip_properties?.start_date||v.trip?.start_date)?(v.trip_properties?.start_date||v.trip.start_date)===day.replaceAll('-',''):day===dayNow())).map(v=>v.company+'|'+v.trip.trip_id))}));dynamicCache={key,value};return value;
}
async function selectedTrip(source,company,tid,day){const dynamic=await dynamicFor(source,day);const key=company+'|'+tid;if(dynamic.trips.has(key))return dynamic.trips.get(key);if(dynamic.replaced.has(key))throw Error('変更便の停車情報が不足しています。公式案内をご確認ください。');const raw=await tripRows(company,tid,source);if(!(source.services[raw[0].service_key]||[]).includes(day))throw Error('指定日はこの便の運行日ではありません');return raw;}
async function motionProfile(source,company,tid,day,raw){
 raw=raw||await selectedTrip(source,company,tid,day);
 let catalog;try{catalog=await operations();}catch{catalog={shapes:{},trip_shapes:{}};}
 const tu=updateFor(raw[0],day,raw),relation=tu?.trip?.schedule_relationship;
 const requested=tu?.trip_properties?.shape_id;
 const key=requested?company+'|'+requested:[1,5,8].includes(relation)?null:catalog.trip_shapes[company+'|'+(raw[0].source_trip_id||tid)];
 const file=key&&catalog.shapes[key];let points=[];if(file)try{points=(await rows(file)).points;}catch{/* Cached timetable and observed GPS remain usable offline. */}
 const stops=raw.filter(r=>Number.isFinite(r.lat)&&Number.isFinite(r.lon)).map(r=>({sequence:r.stop_sequence,lat:r.lat,lon:r.lon,arrival_epoch:epoch(day,r.arrival_sec??r.departure_sec),departure_epoch:epoch(day,r.departure_sec)}));
 return {points,stops,service_date:day,signature:(file?.revision||'stops-only')+'|'+JSON.stringify(stops)};
}
async function tripDetail(source,p,day){
 const raw=await selectedTrip(source,p.company,p.trip_id,day);scheduleCache.set(p.company+'|'+p.trip_id,raw);
 const tu=updateFor(raw[0],day,raw),vp=BusTripSupport.vehicleFor(viewSnapshot,p.company,p.trip_id,day,dayNow(),raw);
 let stops=raw.map(r=>({...decorate(r,day,source),is_highlighted:r.group_id===p.highlight_group_id&&(!p.highlight_sequence||Number(p.highlight_sequence)===r.stop_sequence)}));
 if(vp&&vp.current_stop_sequence>raw[0].stop_sequence)stops=stops.map(s=>({...s,departure_state:'running'}));
 const annotated=BusTripSupport.annotate(stops,vp,stops[0].departure_state==='waiting');stops=annotated.stops;
 const first=stops[0],profile=await motionProfile(source,p.company,p.trip_id,day,raw);
 const point=vp?.position,hasPoint=point&&Number.isFinite(point.latitude)&&Number.isFinite(point.longitude)&&Math.abs(point.latitude)<=90&&Math.abs(point.longitude)<=180;
 const vehicle=hasPoint?{company:p.company,trip_id:p.trip_id,service_date:day,company_short:first.company_short,company_color:first.company_color,route_short_name:first.route_short_name,route_long_name:first.route_long_name,headsign:first.headsign,vehicle_id:vp.vehicle?.id||vp.entity_id||'',lat:point.latitude,lon:point.longitude,bearing:point.bearing,position_updated_at:vp.timestamp,last_known:vp.last_known,cached:vp.cached,current_stop_sequence:vp.current_stop_sequence,current_status:vp.current_status,feed_generated_at:vp.feed_generated_at,relay_received_at:vp.received_at,age_sec:Math.max(0,relay.now()/1000-vp.timestamp)}:null;
 return {company:p.company,trip_id:p.trip_id,service_date:day,headsign:first.headsign,company_short:first.company_short,company_color:first.company_color,route_short_name:first.route_short_name,route_long_name:first.route_long_name,departure_state:first.departure_state,stops,vehicle,timeline_position:annotated.current,polyline:profile.points,geometry_source:profile.points.length?'gtfs_shape':null,simulation_profile:profile,simulation:BusTripSupport.simulation(raw,tu,p.company,p.trip_id,day)};
}
async function detail(source,p){
 const day=p.service_date||dayNow(),group=source.groups.find(g=>g.group_id===p.group_id);if(!group)throw Error('バス停が見つかりません');
 const raw=await groupRows(group),pol=polesOf(p),dynamic=await dynamicFor(source,day);
 const additions=[...dynamic.trips.values()].flat().filter(r=>r.group_id===p.group_id&&r.pickup_type!==1&&!r.is_last_stop&&(!pol.length||pol.includes(r.same_pole_id)));
 let selected=activeRows(raw,source,day,pol).filter(r=>!dynamic.trips.has(r.company+'|'+r.trip_id)&&!dynamic.replaced.has(r.company+'|'+r.trip_id)).map(r=>({...r,instance_day:day}));selected.push(...additions);
 if(day===dayNow()){const previous=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tokyo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(Date.parse(day+'T12:00:00+09:00')-86400000));selected.push(...activeRows(raw,source,previous,pol).map(r=>({...r,instance_day:previous})));}
 const eligible=new Set();
 const reachableCodes=new Set(selected.flatMap(r=>r.downstream||[]));
 if(p.dest_group_id){selected=selected.filter(r=>r.downstream.includes(source.group_codes[p.dest_group_id]));selected.forEach(r=>eligible.add(r.same_pole_id));}
 else selected.forEach(r=>eligible.add(r.same_pole_id));
 const departed=[];let upcoming=selected.map(r=>decorate(r,r.instance_day,source)).filter(r=>{const v=BusTripSupport.vehicleFor(viewSnapshot,r.company,r.trip_id,r.service_date,dayNow(),scheduleCache.get(r.company+'|'+r.trip_id));if(v&&v.current_stop_sequence>r.stop_sequence){departed.push(`${r.company}|${r.trip_id}|${r.service_date}|${r.stop_sequence}`);return false;}return r.status!=='deleted';});if(day===dayNow())upcoming=upcoming.filter(r=>r.sort_epoch>=relay.now()/1000-(r.source==='prediction'?60:0));upcoming.sort((a,b)=>a.sort_epoch-b.sort_epoch||a.company.localeCompare(b.company)||a.trip_id.localeCompare(b.trip_id));
 let next=null;
 if(!upcoming.length&&day===dayNow()&&!p.dest_group_id){next=new Date(Date.parse(day+'T12:00:00+09:00')+86400000).toLocaleDateString('en-CA',{timeZone:'Asia/Tokyo'});upcoming=activeRows(raw,source,next,pol).map(r=>({...decorate(r,next,source),is_next_day_preview:true}));if(!upcoming.length)next=null;}
 const cov=range(source,day,group);
 for(const r of additions)for(const code of r.downstream||[])reachableCodes.add(code);
 const reachable=source.groups.filter(g=>g.group_id!==group.group_id&&reachableCodes.has(source.group_codes[g.group_id])).map(g=>({group_id:g.group_id,name:g.name}));
 return {...group,service_date:day,current_time:new Date(relay.now()).toLocaleTimeString('ja-JP',{timeZone:'Asia/Tokyo',hour:'2-digit',minute:'2-digit'}),upcoming:upcoming.slice(0,p.summary?3:40),departed_keys:departed,reachable_destinations:reachable,eligible_pole_ids:[...eligible],next_service_date:next,coverage:cov,service_state:!cov.some(c=>c.available)?'out_of_range':next?'next_day':upcoming.length?'available':'no_service',realtime:rt(),alerts:await notices(source,[...raw,...additions]),dynamic_issues:dynamic.unresolved};
}
async function handleLocalAPI(path,p={}){
 const source=await index();currentSource=source;await relay.ready;const day=p.service_date||dayNow();
 if(path==='/api/realtime/settings')return p.config?relay.configure(p.config):relay.settings();
 if(path==='/api/realtime/demand'){relay.demand=p.enabled===1||p.enabled==='1';if(relay.demand)await relay.refresh(source.companies);return {enabled:relay.demand};}
 if(['/api/meta','/api/refresh'].includes(path))await relay.refresh(source.companies);
 viewSnapshot=relay.snapshot(source.companies);
 if(path==='/api/meta')return {service_date:day,server_time:new Date(relay.now()).toISOString(),total_stop_groups:source.groups.length,companies:source.companies,realtime:rt(),coverage:range(source,day),alerts:await notices(source),all_alerts:await notices(source),data_update:dataStatus(),realtime_policy:{foreground:true,demanded:relay.demand,next_check_in_seconds:Math.max(0,(relay.next-performance.now())/1000)}};
 if(path==='/api/refresh')return {realtime:rt(),alerts:await notices(source)};
 if(path==='/api/data/status')return dataStatus();
 if(path==='/api/data/update'){indexPromise=null;await index();return {...dataStatus(),message:'索引を確認しました。時刻表は各バス停を開くと最新版を取得します。'};}
 if(path==='/api/stops/search'){
  const q=normalize(p.q),kanaGroups={'あ':'あいうえおぁぃぅぇぉ','か':'かきくけこがぎぐげご','さ':'さしすせそざじずぜぞ','た':'たちつてとだぢづでどっ','な':'なにぬねの','は':'はひふへほばびぶべぼぱぴぷぺぽ','ま':'まみむめも','や':'やゆよゃゅょ','ら':'らりるれろ','わ':'わをん'};
  const result=source.groups.filter(g=>(!q||[g.name,g.hira,g.kana,g.en].some(v=>normalize(v).includes(q)))&&(!p.company||g.companies.includes(p.company))&&(!p.kana_row||(kanaGroups[p.kana_row]||p.kana_row).includes(normalize(g.hira||g.kana)[0]||'?')));
  const rank=g=>[g.name,g.hira,g.kana,g.en].some(v=>q&&normalize(v)===q)?0:[g.name,g.hira,g.kana,g.en].some(v=>q&&normalize(v).startsWith(q))?1:2;
  result.sort((a,b)=>rank(a)-rank(b)||(a.hira||a.name).localeCompare(b.hira||b.name,'ja'));return {stops:result.slice(0,80),total:result.length};
 }
 if(path==='/api/stops/detail')return detail(source,p);
 if(path==='/api/stops/timetable'){
  const group=source.groups.find(g=>g.group_id===p.group_id);if(!group)throw Error('バス停が見つかりません');const dynamic=await dynamicFor(source,day),pol=polesOf(p);const selected=activeRows(await groupRows(group),source,day,pol).filter(r=>!dynamic.trips.has(r.company+'|'+r.trip_id)&&!dynamic.replaced.has(r.company+'|'+r.trip_id));selected.push(...[...dynamic.trips.values()].flat().filter(r=>r.group_id===p.group_id&&r.pickup_type!==1&&!r.is_last_stop&&(!pol.length||pol.includes(r.same_pole_id))));const routes=new Map(),hours=new Map();
  for(const r of selected){const key=`${r.company}|${r.route_short_name}|${r.headsign}`;routes.set(key,{key,route_short_name:r.route_short_name,headsign:r.headsign,company_short:source.companies.find(c=>c.slug===r.company)?.short});if(p.route_filter&&p.route_filter!==key)continue;const h=Math.floor(r.departure_sec/3600);if(!hours.has(h))hours.set(h,[]);hours.get(h).push({...decorate(r,day,source),minute:String(Math.floor(r.departure_sec%3600/60)).padStart(2,'0')});}
  return {group_id:p.group_id,name:group.name,service_date:day,route_options:[...routes.values()],hourly_schedule:[...hours].sort((a,b)=>a[0]-b[0]).map(([hour,entries])=>({hour,entries:entries.sort((a,b)=>a.departure_sec-b.departure_sec)})),total_departures:[...hours.values()].reduce((n,v)=>n+v.length,0),coverage:range(source,day,group),dynamic_issues:dynamic.unresolved};
 }
 if(path==='/api/stops/nearby'){
  const rad=v=>v*Math.PI/180;const distance=g=>{const a=Math.sin(rad(g.lat-p.lat)/2)**2+Math.cos(rad(p.lat))*Math.cos(rad(g.lat))*Math.sin(rad(g.lon-p.lon)/2)**2;return Math.round(6371000*2*Math.asin(Math.sqrt(a)));};
  return {stops:source.groups.map(g=>({...g,distance_m:distance(g)})).filter(g=>g.distance_m<=Number(p.radius||1200)).sort((a,b)=>a.distance_m-b.distance_m).slice(0,Number(p.limit||30)),center:{lat:p.lat,lon:p.lon},service_date:day};
 }
 if(path==='/api/trips/detail')return tripDetail(source,p,day);
 if(path==='/api/routes/shape')return motionProfile(source,p.company,p.trip_id,day);
 if(path==='/api/routes/profiles'){const requests=JSON.parse(p.requests||'[]');if(!Array.isArray(requests)||requests.length>12)throw Error('経路リクエスト数が不正です');return {profiles:await Promise.all(requests.map(v=>motionProfile(source,v.company,v.trip_id,v.service_date||day)))};}
 throw Error('このPWA検証版では、この機能はまだ利用できません');
}
