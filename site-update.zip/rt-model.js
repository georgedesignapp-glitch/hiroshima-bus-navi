/* Deterministic prediction rules; scheduled time alone is never departure evidence. */
(() => {
 function prediction(row,day,tu,base=[],arrival=false){const midnight=Date.parse(day+'T00:00:00+09:00')/1000,scheduled=midnight+(arrival?(row.arrival_sec??row.departure_sec):row.departure_sec);const result={scheduled_epoch:scheduled,predicted_epoch:null,delay_sec:null,status:'scheduled',source:'schedule',updated_at:null,cached:false};if(!tu)return result;
 const relation=tu.trip?.schedule_relationship||0;if([3,7].includes(relation))return {...result,status:relation===3?'cancelled':'deleted',updated_at:tu.timestamp};
 let delay=tu.delay??null,status='scheduled',direct=null,missing=false;const updates=(tu.stop_time_updates||[]).map(stu=>{const old=base.find(r=>r.stop_sequence===stu.stop_sequence)||base.find(r=>stu.stop_id&&r.stop_id===stu.stop_id);return {stu,old,seq:stu.stop_sequence??old?.stop_sequence??(stu.stop_id===row.stop_id?row.stop_sequence:999999)};}).sort((a,b)=>a.seq-b.seq);
 for(const {stu,old,seq} of updates){if(seq>row.stop_sequence)break;const rel=stu.schedule_relationship||0;if(rel===2){delay=null;if(seq===row.stop_sequence)direct=null;continue;}if(rel===1&&seq===row.stop_sequence)status='skipped';let kind=stu.departure?'departure':'arrival',value=stu[kind]||{};if(seq===row.stop_sequence){const primary=arrival?'arrival':'departure';missing=!stu[primary];if(!missing){kind=primary;value=stu[primary];if(value.time!==undefined)direct=value.time;}}
 if(value.delay!==undefined)delay=value.delay;else if(value.time!==undefined&&old){const seconds=kind==='arrival'?old.arrival_sec:old.departure_sec;if(seconds!=null)delay=value.time-midnight-seconds;}}
 let predicted=direct??(delay==null?null:scheduled+delay);if(missing)predicted=null;if(predicted!=null)Object.assign(result,{predicted_epoch:predicted,delay_sec:Math.trunc(predicted-scheduled),source:'prediction',status:'realtime'});if(status==='skipped')result.status=status;result.updated_at=tu.timestamp??null;result.cached=!!tu.cached;return result;
 }
 const matches=(item,company,trip,day,today)=>item.company===company&&item.trip?.trip_id===trip&&((item.trip_properties?.start_date||item.trip?.start_date)?(item.trip_properties?.start_date||item.trip.start_date)===day.replaceAll('-',''):day===today);
 globalThis.BusRTModel={prediction,matches};
})();
