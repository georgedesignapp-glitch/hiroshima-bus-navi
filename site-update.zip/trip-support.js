/* Trip-instance matching, observed position and explicit realtime trip construction. */
(() => {
 'use strict';
 const dayKey=day=>day.replaceAll('-','');
 const midnight=day=>Date.parse(day+'T00:00:00+09:00')/1000;
 const seconds=value=>{if(typeof value!=='string'||!/^\d{1,3}:[0-5]\d:[0-5]\d$/.test(value))return null;const [h,m,s]=value.split(':').map(Number);return h*3600+m*60+s;};
 const instance=item=>item.trip?.schedule_relationship===6?(item.trip_properties?.trip_id||item.trip?.trip_id):item.trip?.trip_id;
 function matches(item,company,trip,day,today,base=[]){
  if(item.company!==company||instance(item)!==trip)return false;
  const explicit=item.trip_properties?.start_date||item.trip?.start_date;
  if(explicit)return explicit===dayKey(day);
  if(day===today)return true;
  const events=(item.stop_time_updates||[]).flatMap(s=>[s.arrival?.time,s.departure?.time]).filter(Number.isFinite);
  return base.some(r=>r.departure_sec>=86400&&events.some(t=>Math.abs(t-midnight(day)-r.departure_sec)<21600));
 }
 function distance(a,b){const rad=Math.PI/180,y=(a[0]-b[0])*rad,x=(a[1]-b[1])*rad*Math.cos((a[0]+b[0])*rad/2);return Math.hypot(x,y)*6371000;}
 const coordinate=p=>p&&Number.isFinite(p.latitude)&&Number.isFinite(p.longitude)&&Math.abs(p.latitude)<=90&&Math.abs(p.longitude)<=180;
 function vehicleFor(snapshot,company,trip,day,today,base=[]){
  return snapshot.vehicles.filter(v=>matches(v,company,trip,day,today,base)).sort((a,b)=>(b.timestamp||0)-(a.timestamp||0))[0]||null;
 }
 function position(rows,vp){
  if(!vp)return null;
  const found=rows.findIndex(r=>r.stop_sequence===vp.current_stop_sequence);
  if(found>=0)return {index:found,source:'stop_sequence',label:({0:'この停留所へ接近中',1:'この停留所に停車中',2:'この停留所へ走行中'})[vp.current_status??2]||'配信で示された停留所',distance_m:null};
  const ids=rows.map((r,i)=>r.stop_id===vp.stop_id?i:-1).filter(i=>i>=0);
  if(vp.stop_id&&ids.length===1)return {index:ids[0],source:'stop_id',label:'配信で示された停留所',distance_m:null};
  if(!coordinate(vp.position))return null;
  const candidates=rows.map((r,i)=>({index:i,distance_m:Number.isFinite(r.lat)&&Number.isFinite(r.lon)?distance([r.lat,r.lon],[vp.position.latitude,vp.position.longitude]):Infinity})).sort((a,b)=>a.distance_m-b.distance_m);
  const first=candidates[0];if(!first||first.distance_m>1500||candidates.some(v=>Math.abs(v.distance_m-first.distance_m)<1&&Math.abs(v.index-first.index)>1))return null;
  return {...first,distance_m:Math.round(first.distance_m),source:'gps_nearest',label:`GPS最寄り・目安（約${Math.round(first.distance_m)} m）`};
 }
 function annotate(rows,vp,waiting){
  const current=position(rows,vp);
  return {current,stops:rows.map((r,i)=>({...r,position_status:current&&i===current.index?'current':!waiting&&current&&i<current.index?(current.source==='gps_nearest'?'estimated_passed':'passed'):'unknown',position_label:current&&i===current.index?current.label:'',position_source:current&&i===current.index?current.source:null}))};
 }
 async function dynamic(snapshot,day,today,catalog,loadTrip,groupCodes){
  const trips=new Map(),unresolved=[],replaced=new Set();
  const updates=[...snapshot.trip_updates].sort((a,b)=>(b.timestamp||0)-(a.timestamp||0));
  for(const tu of updates){
   const trip=tu.trip||{},props=tu.trip_properties||{},relation=trip.schedule_relationship;
   if(![1,5,6,8].includes(relation))continue;
   const explicit=props.start_date||trip.start_date;if(explicit?explicit!==dayKey(day):day!==today)continue;
   const tid=relation===6?props.trip_id:trip.trip_id;
   if(!tid){unresolved.push({company:tu.company,reason:'臨時便の便IDが未提供です'});continue;}
   const key=tu.company+'|'+tid;if(trips.has(key))continue;
   if(relation===5)replaced.add(tu.company+'|'+trip.trip_id);
   try{
    let base=[];if(relation===6){
     if(!props.trip_id||!props.start_date||seconds(props.start_time)===null)throw Error('複製便の開始日・開始時刻が不足しています');
     base=await loadTrip(tu.company,trip.trip_id);if(!base.length)throw Error('複製元の時刻表が見つかりません');
    }
    const route=catalog.routes[tu.company+'|'+trip.route_id]||{},offset=relation===6?seconds(props.start_time)-base[0].departure_sec:0;
    let result=[];
    if(relation===6){result=base.map(r=>({...r,trip_id:tid,source_trip_id:trip.trip_id,added:true,schedule_offset:offset,departure_sec:r.departure_sec+offset,arrival_sec:(r.arrival_sec??r.departure_sec)+offset,_update:tu}));}
    else {
     if((tu.stop_time_updates||[]).length<2)throw Error('臨時便の停車順・時刻が不足しています');
     for(const [i,stu] of tu.stop_time_updates.entries()){
      const stop=catalog.stops[tu.company+'|'+stu.stop_id];if(!stop)throw Error('保存済みデータにない停留所を含みます');
      const event=stu.departure||stu.arrival||{},scheduled=event.scheduled_time??event.time;
      if(!Number.isFinite(scheduled))throw Error('臨時便の停車時刻が不足しています');
      const depart=scheduled-midnight(day),arrive=(stu.arrival?.scheduled_time??stu.arrival?.time??scheduled)-midnight(day);
      if(depart<0||depart>7*86400)throw Error('臨時便の運行日と時刻が一致しません');
      result.push({...stop,trip_id:tid,route_id:trip.route_id||'',direction_id:trip.direction_id,stop_sequence:stu.stop_sequence??i+1,departure_sec:depart,arrival_sec:arrive,pickup_type:0,drop_off_type:0,is_last_stop:i===tu.stop_time_updates.length-1,route_short_name:route.route_short_name||'臨時',route_long_name:route.route_long_name||'',arrival_only:!stu.departure,added:true,_update:tu});
     }
    }
    result.sort((a,b)=>a.stop_sequence-b.stop_sequence);
    if(new Set(result.map(r=>r.stop_sequence)).size!==result.length)throw Error('臨時便の停車順が重複しています');
    const headsign=props.trip_headsign||result.at(-1).stop_name;
    for(const [i,r] of result.entries()){
     r.headsign=headsign;r.origin_sec=result[0].departure_sec;r.instance_day=day;
     r.downstream=[...new Set(result.slice(i+1).filter(s=>s.drop_off_type!==1).map(s=>groupCodes[s.group_id]).filter(Number.isInteger))];
    }
    trips.set(key,result);
   }catch(error){unresolved.push({company:tu.company,trip_id:tid,reason:error.message});}
  }
  return {trips,unresolved,replaced};
 }
 function simulation(rows,tu,company,tid,day){
  if(rows.length<2||[3,7].includes(tu?.trip?.schedule_relationship))return null;
  const timing=rows.map(r=>{const a=BusRTModel.prediction(r,day,tu,rows,true),d=BusRTModel.prediction(r,day,tu,rows);return [r.stop_sequence,a.predicted_epoch??a.scheduled_epoch+(d.delay_sec||0),d.predicted_epoch??d.scheduled_epoch+(a.delay_sec||0),d.status==='skipped'];});
  const hasPrediction=tu&&(tu.delay!=null||(tu.stop_time_updates||[]).some(s=>[s.arrival,s.departure].some(v=>v&&(v.time!=null||v.delay!=null))));
  return {company,trip_id:tid,service_date:day,route_short_name:rows[0].route_short_name,route_long_name:rows[0].route_long_name||'',headsign:rows[0].headsign,start_epoch:timing[0][2],end_epoch:Math.max(timing[0][2],timing.at(-1)[1]),timing,timing_key:JSON.stringify(timing),simulation_source:hasPrediction?'prediction':'schedule',prediction_updated_at:tu?.timestamp,prediction_feed_generated_at:tu?.feed_generated_at,prediction_received_at:tu?.received_at,vehicle_id:'sim:'+tid,is_simulation:true};
 }
 globalThis.BusTripSupport={matches,vehicleFor,position,annotate,dynamic,simulation,distance,instance};
})();
