const CACHE='hbn-pwa-shell-54bfe9b24be09412';
const ASSETS=["./index.html", "./manifest.webmanifest", "./data-worker.js", "./api-worker.js", "./pwa-boot.js", "./pwa.css", "./gtfs-rt.js", "./rt-model.js", "./relay-client.js", "./trip-support.js", "./operations-descriptor.js", "./css/app-layout.css", "./css/brand-motion.css", "./css/styles.css", "./css/transit.css", "./js/app-clock.js", "./js/app.js", "./js/brand-motion.js", "./js/company-links.js", "./js/route-motion.js", "./js/transit-app.js", "./images/brand/bus.png", "./images/brand/frame.png", "./images/brand/icon-192.png", "./images/brand/icon-512.png", "./images/brand/icon.png", "./images/brand/text.png", "./vendor/leaflet-maplibre-gl.js", "./vendor/leaflet-maplibre-LICENSE.txt", "./vendor/leaflet-maplibre-PATCHES.txt", "./vendor/leaflet.css", "./vendor/leaflet.js", "./vendor/maplibre-gl.css", "./vendor/maplibre-gl.js", "./vendor/maplibre-LICENSE.txt", "./vendor/images/marker-icon-2x.png", "./vendor/images/marker-icon.png", "./vendor/images/marker-shadow.png", "./map-styles/dark.json", "./map-styles/light.json"];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)));});
self.addEventListener('activate',event=>{event.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(key=>key.startsWith('hbn-pwa-shell-')&&key!==CACHE).map(key=>caches.delete(key)));await self.clients.claim();})());});
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url),base=new URL(self.registration.scope);
 if(event.request.method!=='GET'||url.origin!==base.origin||!url.pathname.startsWith(base.pathname))return;
 const relative=url.pathname.slice(base.pathname.length);
 if(relative.startsWith('data/')||relative.startsWith('api/'))return;
 if(event.request.mode==='navigate'){event.respondWith(caches.open(CACHE).then(cache=>cache.match(new URL('index.html',base).href)).then(response=>response||fetch(event.request)));return;}
 if(!ASSETS.some(asset=>new URL(asset,base).pathname===url.pathname))return;
 event.respondWith(caches.open(CACHE).then(cache=>cache.match(event.request)).then(response=>response||fetch(event.request)));
});
