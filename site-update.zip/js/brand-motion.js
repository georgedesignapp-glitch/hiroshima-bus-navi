(() => {
  'use strict';
  const band=document.getElementById('brand-loading-band');
  const ribbon=document.createElement('div');ribbon.className='brand-ribbon';ribbon.setAttribute('aria-hidden','true');
  for(let n=0;n<3;n++){const cycle=document.createElement('div');cycle.className='brand-cycle';for(let i=0;i<4;i++)cycle.append(document.createElement('i'));ribbon.append(cycle);}band.append(ribbon);
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const pending=new Set();let epoch=0,animation=null,failed=false;
  function cancelFinish(){epoch++;animation?.cancel();animation=null;band.querySelector('.brand-final')?.remove();band.classList.remove('brand-idle','brand-error');}
  function finish(error){
    cancelFinish();const current=epoch,final=document.createElement('div');final.className='brand-final';final.setAttribute('aria-hidden','true');for(let i=0;i<4;i++)final.append(document.createElement('span'));band.append(final);
    const done=()=>{if(epoch!==current)return;band.classList.add('brand-idle');band.classList.toggle('brand-error',error);band.setAttribute('aria-label',error?'読み込みに失敗しました':'読み込み完了');};
    if(reduced.matches||document.visibilityState!=='visible'){done();return;}
    animation=final.animate([{transform:'translateX(100%)'},{transform:'translateX(0)'}],{duration:650,easing:'cubic-bezier(.2,.65,.3,1)'});animation.finished.then(done,()=>{});
  }
  function begin(){
    if(!pending.size){failed=false;cancelFinish();band.setAttribute('aria-label','読み込み中');}
    const token={};pending.add(token);let ended=false;
    return error=>{if(ended)return;ended=true;failed=failed||!!error;pending.delete(token);if(!pending.size)finish(failed);};
  }
  function ready(){try{window.BusBrand?.ready();}catch{/* The browser version has no native startup screen. */}}
  function page(){if(reduced.matches)return;const deck=document.getElementById('content-deck');deck.classList.remove('brand-page-enter');void deck.offsetWidth;deck.classList.add('brand-page-enter');}
  // Keep the final static stripe until a foreground operation actually starts.
  band.classList.add('brand-idle');finish(false);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState!=='visible'&&animation){animation.finish();}});
  reduced.addEventListener('change',()=>{if(reduced.matches&&animation)animation.finish();});
  window.BusBrandMotion={begin,ready,page};
})();
