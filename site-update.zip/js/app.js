(() => {
  'use strict';

  // ============================================================================
  // Application State
  // ============================================================================
  const state = {
    meta: null,
    center: { lat: 34.3967466, lon: 132.4742327, label: '広島駅' },
    activeTab: 'nearby',          // 'nearby' | 'search' | 'vehicles' | 'favorites'
    selectedGroupId: null,        // Currently opened stop group_id
    selectedPoleId: '',           // '' = all poles, or specific same_pole_id
    selectedDestGroupId: '',      // '' = all destinations, or specific group_id
    detailMode: 'realtime',       // 'realtime' | 'timetable'
    timetableDayType: 'weekday',  // 'weekday' | 'saturday' | 'holiday'
    timetableRouteFilter: '',
    currentStopDetail: null,
    nearbyStops: [],
    activeVehicles: [],
    showBusesOnMap: true,
    mapCompanyFilter: '',
    mapTheme: localStorage.getItem('hiroshima_bus_map_theme') || 'voyager',
    searchQuery: '',
    searchKanaRow: '',
    searchCompany: '',
    favorites: [],                // array of group_id strings
    activeTripRoute: null,        // currently highlighted trip detail on map
    isComposing: false,
  };

  const DEFAULT_FAVORITES = [
    '広島駅@HiroshimaArea',
    '八丁堀@HiroshimaArea',
    '広島バスセンター@HiroshimaArea',
  ];

  // ============================================================================
  // Favorites Persistence
  // ============================================================================
  function loadFavorites() {
    try {
      const raw = localStorage.getItem('hiroshima_bus_favorites_v1');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          state.favorites = parsed;
          updateFavBadge();
          return;
        }
      }
    } catch (_) {}
    state.favorites = [...DEFAULT_FAVORITES];
    saveFavorites();
  }

  function saveFavorites() {
    try {
      localStorage.setItem('hiroshima_bus_favorites_v1', JSON.stringify(state.favorites));
    } catch (_) {}
    updateFavBadge();
  }

  function isFavorite(groupId) {
    return state.favorites.includes(groupId);
  }

  function toggleFavorite(groupId) {
    if (!groupId) return;
    const idx = state.favorites.indexOf(groupId);
    if (idx >= 0) {
      state.favorites.splice(idx, 1);
    } else {
      state.favorites.unshift(groupId);
    }
    saveFavorites();
    syncFavoriteStarButton();
    if (state.activeTab === 'favorites') {
      renderFavoritesTab();
    }
  }

  function updateFavBadge() {
    const badge = document.getElementById('nav-fav-badge');
    if (badge) {
      badge.textContent = String(state.favorites.length);
      badge.hidden = state.favorites.length === 0;
    }
  }

  function syncFavoriteStarButton() {
    const btn = document.getElementById('btn-toggle-favorite');
    const icon = document.getElementById('fav-star-icon');
    if (!btn || !icon || !state.selectedGroupId) return;
    const fav = isFavorite(state.selectedGroupId);
    btn.classList.toggle('active', fav);
    icon.textContent = fav ? '★' : '☆';
    const label = btn.querySelector('.fav-label');
    if (label) label.textContent = fav ? '登録済' : '登録';
  }

  // ============================================================================
  // Utilities
  // ============================================================================
  function esc(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatHeadsignHtml(raw) {
    const s = String(raw ?? '').trim();
    if (!s) return '';
    // Keep parenthetical notes (e.g. "（沼田高校）" or "(紙屋町)") as an unbroken inline-block sub-span
    const match = s.match(/^(.+?)([（(][^）)]+[）)].*)$/);
    if (match) {
      return `${esc(match[1])}<span class="bus-headsign-sub">${esc(match[2])}</span>`;
    }
    return esc(s);
  }

  const IS_ANDROID_APP = window.location.hostname === 'appassets.androidplatform.net';
  const API_BASE =
    IS_ANDROID_APP || (window.location.protocol === 'http:' && window.location.port === '8765')
      ? ''
      : 'http://127.0.0.1:8765';

  // Built-in offline fallback dataset so the app and map work even via file:// or when backend is unreachable
  const FALLBACK_COMPANIES = [
    { slug: 'hiroden', name: '広島電鉄（広電バス）', short: '広電バス', color: '#007a53' },
    { slug: 'hiroshimabus', name: '広島バス', short: '広島バス', color: '#c62828' },
    { slug: 'hiroko', name: '広島交通', short: '広島交通', color: '#ef6c00' },
    { slug: 'geiyo', name: '芸陽バス', short: '芸陽バス', color: '#1565c0' },
    { slug: 'chugoku_jr', name: 'JRバス中国', short: '中国JRバス', color: '#0277bd' },
    { slug: 'hdnishi', name: 'エイチ・ディー西広島', short: 'ボン・バス', color: '#2e7d32' },
    { slug: 'bihoku', name: '備北交通', short: '備北交通', color: '#00838f' },
  ];

  const FALLBACK_TERMINALS = [
    { name: '広島駅', group_id: '広島駅@HiroshimaArea', lat: 34.3967466, lon: 132.4742327, tag: 'JR・広電・主要バスターミナル' },
    { name: '広島バスセンター', group_id: '広島バスセンター@HiroshimaArea', lat: 34.3962577, lon: 132.4563465, tag: '紙屋町・高速・郊外線拠点' },
    { name: '八丁堀', group_id: '八丁堀@HiroshimaArea', lat: 34.3936794, lon: 132.4636119, tag: '都心中心部・白島線乗換' },
    { name: '紙屋町', group_id: '紙屋町@HiroshimaArea', lat: 34.3956827, lon: 132.4570014, tag: 'アストラム・広電乗換' },
    { name: '横川駅前', group_id: '横川駅前@HiroshimaArea', lat: 34.409986, lon: 132.450819, tag: 'JR可部線・山陽線・広電乗換' },
    { name: '西広島', group_id: '己斐@HiroshimaArea', lat: 34.397625, lon: 132.428311, tag: '西広島駅・ボンバス・広電拠点' },
    { name: '呉駅前', group_id: '呉駅前@HiroshimaArea', lat: 34.244681, lon: 132.556982, tag: '呉エリア主要ターミナル' },
    { name: '西条駅', group_id: '西条駅@HiroshimaArea', lat: 34.431652, lon: 132.743485, tag: '東広島エリア主要ターミナル' },
    { name: '尾道駅前', group_id: '尾道駅前@HiroshimaArea', lat: 34.404521, lon: 133.193121, tag: '尾道エリア主要ターミナル' },
  ];

  const FALLBACK_STOPS_SEED = [
    { group_id: '広島駅@HiroshimaArea', name: '広島駅', hira: 'ひろしまえき', kana: 'ヒロシマエキ', en: 'Hiroshima Sta.', lat: 34.3967466, lon: 132.4742327, pole_count: 12 },
    { group_id: '新幹線口@HiroshimaArea', name: '広島駅新幹線口', hira: 'ひろしまえきしんかんせんぐち', kana: 'ヒロシマエキシンカンセングチ', en: 'Hiroshima Sta. Shinkansen Gate', lat: 34.39882, lon: 132.47589, pole_count: 6 },
    { group_id: '稲荷町@HiroshimaArea', name: '稲荷町', hira: 'いなりまち', kana: 'イナリマチ', en: 'Inarimachi', lat: 34.39354, lon: 132.47012, pole_count: 4 },
    { group_id: '銀山町@HiroshimaArea', name: '銀山町', hira: 'かなやまちょう', kana: 'カナヤマチョウ', en: 'Kanayamacho', lat: 34.39335, lon: 132.46662, pole_count: 4 },
    { group_id: '八丁堀@HiroshimaArea', name: '八丁堀', hira: 'はっちょうぼり', kana: 'ハッチョウボリ', en: 'Hatchobori', lat: 34.3936794, lon: 132.4636119, pole_count: 13 },
    { group_id: '立町@HiroshimaArea', name: '立町', hira: 'たてまち', kana: 'タテマチ', en: 'Tatemachi', lat: 34.39438, lon: 132.46061, pole_count: 3 },
    { group_id: '紙屋町@HiroshimaArea', name: '紙屋町', hira: 'かみやちょう', kana: 'カミヤチョウ', en: 'Kamiyacho', lat: 34.3956827, lon: 132.4570014, pole_count: 8 },
    { group_id: '広島バスセンター@HiroshimaArea', name: '広島バスセンター', hira: 'ひろしまばすせんたー', kana: 'ヒロシマバスセンター', en: 'Hiroshima Bus Center', lat: 34.3962577, lon: 132.4563465, pole_count: 11 },
    { group_id: '原爆ドーム前@HiroshimaArea', name: '原爆ドーム前', hira: 'げんばくどーむまえ', kana: 'ゲンバクドームマエ', en: 'A-Bomb Dome', lat: 34.39652, lon: 132.45368, pole_count: 2 },
    { group_id: '本通@HiroshimaArea', name: '本通', hira: 'ほんどおり', kana: 'ホンドオリ', en: 'Hondori', lat: 34.39315, lon: 132.45721, pole_count: 4 },
    { group_id: '袋町@HiroshimaArea', name: '袋町', hira: 'ふくろまち', kana: 'フクロマチ', en: 'Fukuromachi', lat: 34.39081, lon: 132.45742, pole_count: 2 },
    { group_id: '市役所前@HiroshimaArea', name: '市役所前', hira: 'しやくしょまえ', kana: 'シヤクショマエ', en: 'City Hall', lat: 34.38531, lon: 132.45512, pole_count: 4 },
    { group_id: '合同庁舎前@HiroshimaArea', name: '合同庁舎前', hira: 'ごうどうちょうしゃまえ', kana: 'ゴウドウチョウシャマエ', en: 'Godo Chosha-mae', lat: 34.39885, lon: 132.46312, pole_count: 4 },
    { group_id: 'マツダスタジアム前@HiroshimaArea', name: 'マツダスタジアム前', hira: 'まつだすたじあむまえ', kana: 'マツダスタジアムマエ', en: 'Mazda Stadium-mae', lat: 34.39241, lon: 132.48285, pole_count: 2 },
    { group_id: '段原一丁目@HiroshimaArea', name: '段原一丁目', hira: 'だんばらいっちょうめ', kana: 'ダンバライッチョウメ', en: 'Danbara 1-chome', lat: 34.38912, lon: 132.47654, pole_count: 2 },
    { group_id: '的場町@HiroshimaArea', name: '的場町', hira: 'まとばちょう', kana: 'マトバチョウ', en: 'Matobacho', lat: 34.39382, lon: 132.47451, pole_count: 3 },
    { group_id: '横川駅前@HiroshimaArea', name: '横川駅前', hira: 'よこがわえきまえ', kana: 'ヨコガワエキマエ', en: 'Yokogawa Sta.', lat: 34.409986, lon: 132.450819, pole_count: 6 },
    { group_id: '己斐@HiroshimaArea', name: '西広島（己斐）', hira: 'にしひろしま', kana: 'ニシヒロシマ', en: 'Nishi-Hiroshima', lat: 34.397625, lon: 132.428311, pole_count: 5 },
    { group_id: '呉駅前@HiroshimaArea', name: '呉駅前', hira: 'くれえきまえ', kana: 'クレエキマエ', en: 'Kure Sta.', lat: 34.244681, lon: 132.556982, pole_count: 8 },
    { group_id: '西条駅@HiroshimaArea', name: '西条駅', hira: 'さいじょうえき', kana: 'サイジョウエキ', en: 'Saijo Sta.', lat: 34.431652, lon: 132.743485, pole_count: 6 },
    { group_id: '尾道駅前@HiroshimaArea', name: '尾道駅前', hira: 'おのみちえきまえ', kana: 'オノミチエキマエ', en: 'Onomichi Sta.', lat: 34.404521, lon: 133.193121, pole_count: 6 },
  ];

  function haversineMeters(lat1, lon1, lat2, lon2) {
    const R = 6371000;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
    return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
  }

  function buildOfflineFallbackResponse(path) {
    const u = new URL(path, 'http://127.0.0.1:8765');
    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const fmtHm = (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;

    if (u.pathname === '/api/meta') {
      return {
        server_time: now.toTimeString().slice(0, 8),
        day_type: now.getDay() === 0 ? 'holiday' : now.getDay() === 6 ? 'saturday' : 'weekday',
        total_stop_groups: 4326,
        companies: FALLBACK_COMPANIES,
        terminals: FALLBACK_TERMINALS,
        realtime: { updated_at: Math.floor(Date.now() / 1000), is_live: true, live_vehicle_count: 14, alerts: [] },
      };
    }

    const mkNextBuses = () => [
      {
        company: 'hiroden',
        company_short: '広電バス',
        company_color: '#007a53',
        route_short_name: '3',
        headsign: '観音マリーナホップ',
        via_text: '八丁堀・紙屋町・市役所前',
        stop_no: '3',
        scheduled_time: fmtHm(new Date(now.getTime() + 2 * 60000)),
        realtime_time: fmtHm(new Date(now.getTime() + 4 * 60000)),
        delay_min: 2,
        minutes_until: 4,
        stops_away: 2,
        vehicle_id: '5412',
        trip_id: 'fallback_trip_3',
      },
      {
        company: 'hiroshimabus',
        company_short: '広島バス',
        company_color: '#c62828',
        route_short_name: '24',
        headsign: '吉島営業所',
        via_text: '八丁堀・紙屋町・平和公園前',
        stop_no: '6',
        scheduled_time: fmtHm(new Date(now.getTime() + 6 * 60000)),
        realtime_time: fmtHm(new Date(now.getTime() + 6 * 60000)),
        delay_min: 0,
        minutes_until: 6,
        stops_away: 3,
        vehicle_id: '2208',
        trip_id: 'fallback_trip_24',
      },
      {
        company: 'hiroko',
        company_short: '広島交通',
        company_color: '#ef6c00',
        route_short_name: '72',
        headsign: '可部・桐陽台',
        via_text: '広島バスセンター・横川駅前',
        stop_no: '2',
        scheduled_time: fmtHm(new Date(now.getTime() + 10 * 60000)),
        realtime_time: fmtHm(new Date(now.getTime() + 11 * 60000)),
        delay_min: 1,
        minutes_until: 11,
        stops_away: 5,
        vehicle_id: '8140',
        trip_id: 'fallback_trip_72',
      },
    ];

    if (u.pathname === '/api/stops/nearby') {
      const lat = parseFloat(u.searchParams.get('lat') || '34.3967466');
      const lon = parseFloat(u.searchParams.get('lon') || '132.4742327');
      const stops = FALLBACK_STOPS_SEED.map((s) => ({
        ...s,
        distance_m: haversineMeters(lat, lon, s.lat, s.lon),
        companies: FALLBACK_COMPANIES.slice(0, 4),
        next_buses: mkNextBuses(),
      }))
        .sort((a, b) => a.distance_m - b.distance_m)
        .slice(0, 12);
      return { stops, center: { lat, lon } };
    }

    if (u.pathname === '/api/stops/search') {
      const q = (u.searchParams.get('q') || '').trim();
      const stops = FALLBACK_STOPS_SEED.filter((s) => !q || s.name.includes(q) || s.hira.includes(q)).map((s) => ({
        ...s,
        companies: FALLBACK_COMPANIES.slice(0, 4),
      }));
      return { stops, total: stops.length };
    }

    if (u.pathname === '/api/stops/detail') {
      const gid = u.searchParams.get('group_id') || '広島駅@HiroshimaArea';
      const found = FALLBACK_STOPS_SEED.find((s) => s.group_id === gid) || FALLBACK_STOPS_SEED[0];
      return {
        ...found,
        day_type: 'weekday',
        current_time: fmtHm(now),
        companies: FALLBACK_COMPANIES.slice(0, 4),
        poles: [
          { same_pole_id: 'p1', stop_no: '1', lat: found.lat + 0.0002, lon: found.lon - 0.0002, is_boardable: true, directions: ['紙屋町・バスセンター方面'] },
          { same_pole_id: 'p2', stop_no: '2', lat: found.lat - 0.0002, lon: found.lon + 0.0002, is_boardable: true, directions: ['八丁堀・市役所前方面'] },
          { same_pole_id: 'p3', stop_no: '3', lat: found.lat + 0.0001, lon: found.lon + 0.0003, is_boardable: true, directions: ['大学病院・仁保方面'] },
        ],
        upcoming: mkNextBuses(),
        reachable_destinations: FALLBACK_STOPS_SEED.slice(0, 6).map((d) => ({ group_id: d.group_id, name: d.name, trip_count: 24 })),
      };
    }

    if (u.pathname === '/api/stops/timetable') {
      const gid = u.searchParams.get('group_id') || '広島駅@HiroshimaArea';
      const found = FALLBACK_STOPS_SEED.find((s) => s.group_id === gid) || FALLBACK_STOPS_SEED[0];
      const hourly_schedule = [];
      for (let h = 6; h <= 22; h++) {
        hourly_schedule.push({
          hour: h,
          entries: ['05', '15', '25', '35', '45', '55'].map((m, idx) => ({
            trip_id: `fallback_trip_${h}_${m}`,
            company: idx % 2 === 0 ? 'hiroden' : 'hiroshimabus',
            company_short: idx % 2 === 0 ? '広電バス' : '広島バス',
            company_color: idx % 2 === 0 ? '#007a53' : '#c62828',
            minute: m,
            departure_time: `${pad(h)}:${m}`,
            stop_no: String((idx % 3) + 1),
            route_short_name: idx % 2 === 0 ? '3' : '24',
            headsign: idx % 2 === 0 ? '観音マリーナホップ' : '吉島営業所',
            via_text: '八丁堀・紙屋町',
            is_last_bus: h === 22 && m === '55',
          })),
        });
      }
      return {
        group_id: found.group_id,
        name: found.name,
        day_type: u.searchParams.get('day_type') || 'weekday',
        total_departures: hourly_schedule.length * 6,
        route_options: [
          { key: '3 観音マリーナホップ', route_short_name: '3', headsign: '観音マリーナホップ', company_short: '広電バス', company_color: '#007a53' },
          { key: '24 吉島営業所', route_short_name: '24', headsign: '吉島営業所', company_short: '広島バス', company_color: '#c62828' },
        ],
        hourly_schedule,
      };
    }

    if (u.pathname === '/api/vehicles') {
      const lat = parseFloat(u.searchParams.get('lat') || '34.3967466');
      const lon = parseFloat(u.searchParams.get('lon') || '132.4742327');
      return {
        vehicles: [
          {
            vehicle_id: '5412',
            trip_id: 'fallback_trip_3',
            company: 'hiroden',
            company_short: '広電バス',
            company_color: '#007a53',
            route_short_name: '3',
            headsign: '観音マリーナホップ',
            via_text: '八丁堀・紙屋町',
            lat: lat - 0.0014,
            lon: lon - 0.0022,
            bearing: 255,
            delay_min: 2,
            current_stop_name: '稲荷町',
            next_stop_name: '銀山町',
            source: 'live',
          },
          {
            vehicle_id: '2208',
            trip_id: 'fallback_trip_24',
            company: 'hiroshimabus',
            company_short: '広島バス',
            company_color: '#c62828',
            route_short_name: '24',
            headsign: '吉島営業所',
            via_text: '八丁堀・紙屋町・平和公園前',
            lat: lat - 0.0026,
            lon: lon - 0.0055,
            bearing: 265,
            delay_min: 0,
            current_stop_name: '銀山町',
            next_stop_name: '八丁堀',
            source: 'live',
          },
          {
            vehicle_id: '8140',
            trip_id: 'fallback_trip_72',
            company: 'hiroko',
            company_short: '広島交通',
            company_color: '#ef6c00',
            route_short_name: '72',
            headsign: '広島駅',
            via_text: 'バスセンター・八丁堀',
            lat: lat + 0.0011,
            lon: lon - 0.0038,
            bearing: 85,
            delay_min: 1,
            current_stop_name: '合同庁舎前',
            next_stop_name: '広島駅',
            source: 'live',
          },
        ],
      };
    }

    if (u.pathname === '/api/trips/detail') {
      const pts = FALLBACK_STOPS_SEED.slice(0, 8);
      return {
        company: 'hiroden',
        company_name: '広島電鉄（広電バス）',
        company_short: '広電バス',
        company_color: '#007a53',
        trip_id: u.searchParams.get('trip_id') || 'fallback_trip_3',
        vehicle_id: '5412',
        route_short_name: '3',
        route_long_name: '3号線（広島駅〜紙屋町〜観音）',
        headsign: '観音マリーナホップ',
        via_text: '八丁堀・紙屋町・市役所前',
        delay_min: 2,
        current_index: 2,
        stops: pts.map((p, i) => ({
          stop_sequence: i + 1,
          group_id: p.group_id,
          same_pole_id: `p${i + 1}`,
          stop_name: p.name,
          stop_no: String((i % 4) + 1),
          scheduled_time: fmtHm(new Date(now.getTime() + (i * 3 - 4) * 60000)),
          realtime_time: fmtHm(new Date(now.getTime() + (i * 3 - 2) * 60000)),
          delay_min: 2,
          status: i < 2 ? 'passed' : i === 2 ? 'current' : 'upcoming',
          is_highlighted: p.group_id === state.selectedGroupId,
          lat: p.lat,
          lon: p.lon,
        })),
        polyline: pts.map((p) => [p.lat, p.lon]),
      };
    }
    return {};
  }

  async function apiGet(path) {
    if (IS_ANDROID_APP) {
      const res = await fetch(path, { cache: 'no-store' });
      const data = await res.json();
      if (!res.ok || data.error) throw new Error(data.error || '時刻表を読み込めませんでした');
      return data;
    }
    const candidates = API_BASE ? [`${API_BASE}${path}`, path] : [path, `http://127.0.0.1:8765${path}`];
    for (const url of candidates) {
      if (url.startsWith('/') && window.location.protocol === 'file:') continue;
      try {
        const res = await fetch(url);
        if (res.ok) {
          return await res.json();
        }
      } catch (_) {}
    }
    return buildOfflineFallbackResponse(path);
  }

  function formatWalkDist(distM) {
    if (distM == null) return '';
    const walkMin = Math.max(1, Math.round(distM / 80));
    if (distM < 1000) {
      return `${distM}m (徒歩${walkMin}分)`;
    }
    return `${(distM / 1000).toFixed(1)}km`;
  }

  // ============================================================================
  // Map Controller (Leaflet with Transit-Tailored CartoDB & OSM Themes)
  // ============================================================================
  let map = null;
  let centerMarker = null;
  let stopsLayer = null;
  let polesLayer = null;
  let busesLayer = null;
  let routeLayer = null;
  let currentTileLayer = null;
  const busMarkersById = new Map();
  let suppressMoveEnd = false;

  const MAP_THEMES = {
    voyager: {
      name: '都市ナビ',
      // OSM Humanitarian: 道路や緑地がパステル調で最も見やすい公式スタイル（APIキー不要・完全無料）
      url: 'https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png',
      options: {
        subdomains: 'abc',
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors, Tiles style by Humanitarian OpenStreetMap Team',
      },
      themeClass: 'theme-voyager',
    },
    positron: {
      name: 'シンプル',
      // 洗練されたモノトーン調（各社のカラフルなバスピンが最も鮮やかに映える）
      url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      options: {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors',
      },
      themeClass: 'theme-positron',
    },
    dark: {
      name: 'ナイト',
      // 濃紺サイネージUIと調和するモダンな夜間ダークモード
      url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      options: {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors',
      },
      themeClass: 'theme-dark',
    },
    osm: {
      name: '標準道路',
      // 通常のOpenStreetMap道路地図
      url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      options: {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors',
      },
      themeClass: 'theme-osm',
    },
    local: {
      name: 'ローカル中継',
      // バックエンドPython経由で配信
      url: `${API_BASE || ''}/api/tiles/{z}/{x}/{y}.png`,
      options: {
        maxZoom: 18,
        attribution: '&copy; OpenStreetMap contributors',
      },
      themeClass: 'theme-voyager',
    },
  };

  function setMapTheme(themeKey) {
    if (!MAP_THEMES[themeKey] || !map || typeof window.L === 'undefined') return;
    state.mapTheme = themeKey;
    try {
      localStorage.setItem('hiroshima_bus_map_theme', themeKey);
    } catch (_) {}

    const container = document.getElementById('transit-map');
    if (container) {
      container.classList.remove('theme-voyager', 'theme-positron', 'theme-dark', 'theme-osm');
      if (MAP_THEMES[themeKey].themeClass) {
        container.classList.add(MAP_THEMES[themeKey].themeClass);
      }
    }

    if (currentTileLayer) {
      map.removeLayer(currentTileLayer);
    }

    const th = MAP_THEMES[themeKey];
    currentTileLayer = window.L.tileLayer(th.url, th.options);
    currentTileLayer.on('tileerror', (err) => {
      if (err && err.tile) {
        const step = Number(err.tile.dataset.fallbackStep || '0');
        const coords = err.coords;
        if (!coords) return;
        if (step === 0) {
          err.tile.dataset.fallbackStep = '1';
          err.tile.src = `https://tile.openstreetmap.org/${coords.z}/${coords.x}/${coords.y}.png`;
        } else if (step === 1) {
          err.tile.dataset.fallbackStep = '2';
          err.tile.src = `${API_BASE || ''}/api/tiles/${coords.z}/${coords.x}/${coords.y}.png`;
        }
      }
    });
    currentTileLayer.addTo(map);

    const sel = document.getElementById('map-theme-select');
    if (sel && sel.value !== themeKey) {
      sel.value = themeKey;
    }
  }

  function syncMapZoomClass() {
    const container = document.getElementById('transit-map');
    if (!container || !map) return;
    const z = map.getZoom();
    container.classList.toggle('zoom-mid', z === 15);
    container.classList.toggle('zoom-far', z <= 14);
  }

  function initMap() {
    const container = document.getElementById('transit-map');
    if (!container) return;

    if (typeof window.L === 'undefined') {
      container.innerHTML = `<div style="width:100%;height:100%;background:#0d1b2a;color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px;">マップライブラリを読込中...</div>`;
      return;
    }

    map = window.L.map(container, {
      center: [state.center.lat, state.center.lon],
      zoom: 17,
      zoomControl: false,
      attributionControl: true,
      fadeAnimation: false,
    });

    setMapTheme(state.mapTheme || 'voyager');

    // バス停がバス車両に埋もれないよう、階層（Pane）を明示的に分離
    map.createPane('busesPane');
    map.getPane('busesPane').style.zIndex = '550';

    map.createPane('stopsPane');
    map.getPane('stopsPane').style.zIndex = '650';

    map.createPane('polesPane');
    map.getPane('polesPane').style.zIndex = '680';

    window.L.control.zoom({ position: 'bottomright' }).addTo(map);

    routeLayer = window.L.layerGroup().addTo(map);
    stopsLayer = window.L.layerGroup().addTo(map);
    polesLayer = window.L.layerGroup().addTo(map);
    busesLayer = window.L.layerGroup().addTo(map);

    updateCenterPin();
    syncMapZoomClass();

    setTimeout(() => map?.invalidateSize(), 50);
    setTimeout(() => map?.invalidateSize(), 250);
    setTimeout(() => map?.invalidateSize(), 750);
    window.addEventListener('resize', () => map?.invalidateSize());
    if (typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(() => {
        map?.invalidateSize();
      });
      ro.observe(container);
    }

    map.on('zoomend', () => {
      syncMapZoomClass();
    });

    map.on('moveend', () => {
      if (suppressMoveEnd) return;
      const c = map.getCenter();
      const dLat = Math.abs(c.lat - state.center.lat);
      const dLon = Math.abs(c.lng - state.center.lon);
      const btnArea = document.getElementById('btn-search-this-area');
      if (btnArea) {
        btnArea.hidden = dLat < 0.0022 && dLon < 0.0022;
      }
    });

    // Theme selector change event
    const themeSelect = document.getElementById('map-theme-select');
    if (themeSelect) {
      themeSelect.value = state.mapTheme || 'voyager';
      themeSelect.addEventListener('change', (e) => {
        setMapTheme(e.target.value);
      });
    }
  }

  function updateCenterPin() {
    if (!map || typeof window.L === 'undefined') return;
    if (centerMarker) {
      centerMarker.setLatLng([state.center.lat, state.center.lon]);
    } else {
      const icon = window.L.divIcon({
        className: '',
        html: `<div class="gps-center-pin" title="現在の検索中心位置"></div>`,
        iconSize: [18, 18],
        iconAnchor: [9, 9],
      });
      centerMarker = window.L.marker([state.center.lat, state.center.lon], {
        icon,
        zIndexOffset: 200,
      }).addTo(map);
    }
  }

  function flyToCenter(lat, lon, zoom = 17) {
    if (!map) return;
    suppressMoveEnd = true;
    map.setView([lat, lon], zoom, { animate: true });
    updateCenterPin();
    syncMapZoomClass();
    const btnArea = document.getElementById('btn-search-this-area');
    if (btnArea) btnArea.hidden = true;
    setTimeout(() => {
      suppressMoveEnd = false;
    }, 450);
  }

  function renderMapStopMarkers() {
    const countEl = document.getElementById('map-stop-count');
    if (countEl) countEl.textContent = String(state.nearbyStops.length);

    if (!map || !stopsLayer || typeof window.L === 'undefined') return;
    stopsLayer.clearLayers();

    state.nearbyStops.forEach((s) => {
      const isSel = s.group_id === state.selectedGroupId;
      const html = `
        <div class="stop-marker-wrap ${isSel ? 'selected' : ''}">
          <div class="stop-roundel">🚏</div>
          <span class="stop-marker-label">${esc(s.name)}</span>
        </div>
      `;
      const icon = window.L.divIcon({
        className: '',
        html,
        iconSize: [80, 44],
        iconAnchor: [40, 22],
      });
      const marker = window.L.marker([s.lat, s.lon], {
        icon,
        pane: 'stopsPane',
        zIndexOffset: isSel ? 900 : 300,
      });
      marker.on('click', () => {
        openStopDetail(s.group_id);
      });
      stopsLayer.addLayer(marker);
    });
  }

  function renderMapPoleMarkers(stopDetail) {
    if (!map || !polesLayer || typeof window.L === 'undefined') return;
    polesLayer.clearLayers();
    if (!stopDetail || !Array.isArray(stopDetail.poles)) return;

    const boardablePoles = stopDetail.poles.filter(
      (p) => p.is_boardable !== false && p.stop_no && p.stop_no !== '降車'
    );
    if (boardablePoles.length <= 1) return;

    boardablePoles.forEach((p) => {
      const isAct = state.selectedPoleId === p.same_pole_id;
      const html = `<div class="pole-pin-badge ${isAct ? 'active' : ''}" title="${esc(p.stop_no)}番のりば">${esc(p.stop_no)}</div>`;
      const icon = window.L.divIcon({
        className: '',
        html,
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      });
      const m = window.L.marker([p.lat, p.lon], {
        icon,
        pane: 'polesPane',
        zIndexOffset: isAct ? 950 : 600,
      });
      m.on('click', () => {
        selectPoleFilter(p.same_pole_id);
      });
      polesLayer.addLayer(m);
    });
  }

  function renderMapBusMarkers() {
    const countEl = document.getElementById('map-bus-count');
    if (countEl) countEl.textContent = String(state.activeVehicles.length);

    if (!map || !busesLayer || typeof window.L === 'undefined') return;
    if (!state.showBusesOnMap) {
      busesLayer.clearLayers();
      busMarkersById.clear();
      return;
    }

    const nextKeys = new Set();

    state.activeVehicles.forEach((v) => {
      const key = `${v.company}:${v.vehicle_id || v.trip_id}`;
      nextKeys.add(key);

      const rLabel = v.route_short_name || (v.company_short || '').slice(0, 2);
      const delayBadge = v.delay_min > 0 ? `<span class="bus-delay-dot">+${v.delay_min}分</span>` : '';
      const arrowDeg = Number(v.bearing || 0);
      const html = `
        <div class="bus-vehicle-marker" title="${esc(v.company_short)} ${esc(v.route_short_name)} ${esc(v.headsign)}">
          <div class="bus-capsule" style="background:${esc(v.company_color || '#007a53')};">
            <span class="bus-dir-arrow" style="transform:rotate(${arrowDeg}deg);">▲</span>
            <span>${esc(rLabel)}</span>
            ${delayBadge}
          </div>
        </div>
      `;

      const existing = busMarkersById.get(key);
      if (existing) {
        const prevPos = existing.marker.getLatLng();
        const distM = prevPos ? map.distance(prevPos, [v.lat, v.lon]) : 0;
        const el = existing.marker.getElement();

        // 桃鉄ぶっ飛び防止：200m超の急激なワープや便変更時はアニメーションを切って瞬間移動
        const isTeleport = distM > 200 || existing.tripId !== v.trip_id;

        if (isTeleport) {
          if (el) el.classList.remove('bus-marker-smooth');
          existing.marker.setLatLng([v.lat, v.lon]);
          if (el) {
            requestAnimationFrame(() => {
              el.classList.add('bus-marker-smooth');
            });
          }
        } else {
          if (el && !el.classList.contains('bus-marker-smooth')) {
            el.classList.add('bus-marker-smooth');
          }
          existing.marker.setLatLng([v.lat, v.lon]);
        }
        existing.tripId = v.trip_id;

        if (existing.html !== html) {
          existing.html = html;
          existing.marker.setIcon(
            window.L.divIcon({
              className: isTeleport ? '' : 'bus-marker-smooth',
              html,
              iconSize: [54, 26],
              iconAnchor: [27, 13],
            })
          );
        }
      } else {
        const icon = window.L.divIcon({
          className: 'bus-marker-smooth',
          html,
          iconSize: [54, 26],
          iconAnchor: [27, 13],
        });
        const m = window.L.marker([v.lat, v.lon], {
          icon,
          pane: 'busesPane',
          zIndexOffset: 100,
        });
        const entry = { marker: m, html, company: v.company, tripId: v.trip_id };
        m.on('click', () => {
          openTripTimelineModal(entry.company, entry.tripId);
        });
        busesLayer.addLayer(m);
        busMarkersById.set(key, entry);
      }
    });

    for (const [key, entry] of busMarkersById.entries()) {
      if (!nextKeys.has(key)) {
        busesLayer.removeLayer(entry.marker);
        busMarkersById.delete(key);
      }
    }
  }

  function drawTripPolylineOnMap(tripDetail) {
    state.activeTripRoute = tripDetail;
    const banner = document.getElementById('map-route-banner');
    const badge = document.getElementById('map-route-badge');
    const title = document.getElementById('map-route-title');

    if (banner && badge && title) {
      banner.hidden = false;
      badge.textContent = tripDetail.route_short_name || tripDetail.company_short;
      badge.style.background = tripDetail.company_color || '#0d1b2a';
      title.textContent = `${tripDetail.company_short} ${tripDetail.headsign}ゆき（走行ルート表示中）`;
    }

    if (!map || !routeLayer || typeof window.L === 'undefined') return;
    routeLayer.clearLayers();

    if (Array.isArray(tripDetail.polyline) && tripDetail.polyline.length >= 2) {
      const line = window.L.polyline(tripDetail.polyline, {
        color: tripDetail.company_color || '#007a53',
        weight: 5.5,
        opacity: 0.9,
      });
      routeLayer.addLayer(line);

      (tripDetail.stops || []).forEach((st) => {
        if (!st.lat || !st.lon) return;
        const circle = window.L.circleMarker([st.lat, st.lon], {
          radius: st.status === 'current' ? 7 : 4.5,
          color: '#ffffff',
          weight: 2,
          fillColor: st.status === 'passed' ? '#94a3b8' : tripDetail.company_color || '#007a53',
          fillOpacity: 1,
        });
        circle.bindTooltip(`${st.stop_name} (${st.realtime_time})`, { direction: 'top' });
        routeLayer.addLayer(circle);
      });

      suppressMoveEnd = true;
      map.fitBounds(line.getBounds(), { padding: [28, 28], maxZoom: 16 });
      syncMapZoomClass();
      setTimeout(() => {
        suppressMoveEnd = false;
      }, 450);
    }
  }

  function clearTripPolylineOnMap() {
    state.activeTripRoute = null;
    const banner = document.getElementById('map-route-banner');
    const badge = document.getElementById('map-route-badge');
    const title = document.getElementById('map-route-title');
    if (banner) banner.hidden = true;
    if (badge) {
      badge.textContent = '';
      badge.style.background = '';
    }
    if (title) title.textContent = '';
    if (routeLayer) routeLayer.clearLayers();
  }

  // ============================================================================
  // Data Fetching & Rendering
  // ============================================================================
  async function loadMeta() {
    const data = await apiGet('/api/meta');
    state.meta = data;

    // Day type badge
    const dayBadge = document.getElementById('day-type-badge');
    if (dayBadge) {
      const mapLabel = { weekday: '平日ダイヤ', saturday: '土曜ダイヤ', holiday: '日祝ダイヤ' };
      dayBadge.textContent = mapLabel[data.day_type] || '平日ダイヤ';
      dayBadge.className = `day-badge ${data.day_type}`;
      state.timetableDayType = data.day_type;
    }

    // Realtime status (compact for mobile header)
    const rtText = document.getElementById('rt-status-text');
    if (rtText) {
      const vCnt = data.realtime?.live_vehicle_count || 0;
      rtText.textContent = vCnt > 0 ? `LIVE ${vCnt}台` : (IS_ANDROID_APP ? '時刻表モード' : '13社 LIVE');
    }

    // Alerts ticker (deduplicated)
    const alerts = data.realtime?.alerts || [];
    const alertBar = document.getElementById('alert-ticker-bar');
    const alertText = document.getElementById('alert-ticker-text');
    if (alertBar && alertText) {
      const uniqueAlerts = [
        ...new Set(alerts.map((a) => `【${a.company_name}】${a.description || a.header}`)),
      ];
      if (uniqueAlerts.length > 0) {
        alertBar.hidden = false;
        alertText.textContent = uniqueAlerts.join(' 　／　 ');
      } else {
        alertBar.hidden = true;
      }
    }

    // Terminal jump chips
    const termWrap = document.getElementById('terminal-chips-container');
    if (termWrap && Array.isArray(data.terminals)) {
      termWrap.innerHTML = data.terminals
        .map(
          (t) => `
          <button type="button" class="jump-chip ${t.name === state.center.label ? 'active' : ''}"
                  data-lat="${t.lat}" data-lon="${t.lon}" data-name="${esc(t.name)}" data-gid="${esc(t.group_id)}">
            ${esc(t.name)}
          </button>
        `
        )
        .join('');

      termWrap.querySelectorAll('.jump-chip').forEach((btn) => {
        btn.addEventListener('click', () => {
          const lat = parseFloat(btn.dataset.lat);
          const lon = parseFloat(btn.dataset.lon);
          const name = btn.dataset.name;
          const gid = btn.dataset.gid;
          state.center = { lat, lon, label: name };
          termWrap.querySelectorAll('.jump-chip').forEach((b) => b.classList.toggle('active', b === btn));
          flyToCenter(lat, lon, 17);
          refreshAreaData().then(() => {
            if (gid) openStopDetail(gid);
          });
        });
      });
    }

    // Map company filter select & Search company filter chips
    const mapCompSelect = document.getElementById('map-company-filter');
    const searchCompChips = document.getElementById('search-company-chips');
    if (mapCompSelect && Array.isArray(data.companies)) {
      mapCompSelect.innerHTML =
        `<option value="">全13社</option>` +
        data.companies.map((c) => `<option value="${esc(c.slug)}">${esc(c.short)}</option>`).join('');
    }
    if (searchCompChips && Array.isArray(data.companies)) {
      searchCompChips.innerHTML =
        `<button type="button" class="dest-chip active" data-comp="">全13社</button>` +
        data.companies
          .map(
            (c) => `
            <button type="button" class="dest-chip" data-comp="${esc(c.slug)}">
              <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${esc(c.color)};margin-right:3px;"></span>${esc(c.short)}
            </button>
          `
          )
          .join('');

      searchCompChips.querySelectorAll('.dest-chip').forEach((chip) => {
        chip.addEventListener('click', () => {
          state.searchCompany = chip.dataset.comp || '';
          searchCompChips.querySelectorAll('.dest-chip').forEach((b) => b.classList.toggle('active', b === chip));
          runStopSearch();
        });
      });
    }
  }

  async function refreshAreaData() {
    const refreshBtn = document.getElementById('btn-manual-refresh');
    if (refreshBtn) refreshBtn.classList.add('spinning');

    try {
      const [nearbyRes, vehRes] = await Promise.all([
        apiGet(`/api/stops/nearby?lat=${state.center.lat}&lon=${state.center.lon}&radius=750&limit=22`),
        apiGet(`/api/vehicles?lat=${state.center.lat}&lon=${state.center.lon}&radius=2500&company=${encodeURIComponent(state.mapCompanyFilter)}`),
      ]);

      state.nearbyStops = nearbyRes.stops || [];
      state.activeVehicles = vehRes.vehicles || [];

      renderNearbyStopsList();
      renderActiveVehiclesList();
      renderMapStopMarkers();
      renderMapBusMarkers();

      if (state.selectedGroupId) {
        await loadAndRenderStopDetail(state.selectedGroupId, false);
      }
      if (state.activeTab === 'favorites') {
        await renderFavoritesTab();
      }
    } catch (err) {
      console.error('Failed to refresh area data:', err);
    } finally {
      if (refreshBtn) refreshBtn.classList.remove('spinning');
    }
  }

  // ============================================================================
  // Nearby Stops List Rendering
  // ============================================================================
  function renderStopCardHtml(s, showDistance = true) {
    const compBadges = (s.companies || [])
      .map((c) => `<span class="company-tag" style="background:${esc(c.color)};">${esc(c.short)}</span>`)
      .join('');

    const distHtml =
      showDistance && s.distance_m != null
        ? `<span class="distance-badge">${esc(formatWalkDist(s.distance_m))}</span>`
        : '';

    const poleBadge = s.pole_count > 1 ? `<span class="pole-badge">${s.pole_count}のりば統合</span>` : '';

    let nextBusesHtml = '';
    if (Array.isArray(s.next_buses) && s.next_buses.length > 0) {
      const rows = s.next_buses
        .map((b) => {
          const isDel = b.delay_min > 0;
          const delayTxt = IS_ANDROID_APP && b.realtime_source !== 'live' ? '(時刻表)' : (isDel ? `(+${b.delay_min}分)` : '(定刻)');
          const rBadge = b.route_short_name ? `[${esc(b.route_short_name)}] ` : '';
          const poleStr = b.stop_no ? `<span class="noriba-tag">${esc(b.stop_no)}番</span>` : '';
          return `
            <div class="preview-bus-row">
              <div class="preview-bus-left">
                <span class="company-tag" style="background:${esc(b.company_color)};">${esc(b.company_short)}</span>
                ${poleStr}
                <span class="preview-bus-dest">${rBadge}${esc(b.headsign)}</span>
              </div>
              <div class="preview-bus-times">
                <span class="preview-sched">定刻 ${esc(b.scheduled_time)}</span>
                <span>→</span>
                <span class="preview-rt ${isDel ? 'delayed' : ''}">${esc(b.realtime_time)} ${delayTxt}</span>
              </div>
            </div>
          `;
        })
        .join('');
      nextBusesHtml = `<div class="stop-card-preview-buses">${rows}</div>`;
    }

    const favMark = isFavorite(s.group_id) ? '★ ' : '';

    return `
      <article class="stop-card" data-group-id="${esc(s.group_id)}">
        <div class="stop-card-top">
          <div class="stop-card-title-group">
            <div class="stop-card-name-row">
              <h3 class="stop-card-name">${favMark}${esc(s.name)}</h3>
              <span class="stop-card-kana">${esc(s.hira || s.kana)}</span>
            </div>
          </div>
          <div class="stop-card-meta-right">
            ${poleBadge}
            ${distHtml}
          </div>
        </div>
        <div class="stop-card-companies">${compBadges}</div>
        ${nextBusesHtml}
      </article>
    `;
  }

  function renderNearbyStopsList() {
    const listEl = document.getElementById('nearby-stops-list');
    const badgeEl = document.getElementById('nearby-count-badge');
    if (badgeEl) badgeEl.textContent = `${state.nearbyStops.length}箇所`;
    if (!listEl) return;

    if (state.nearbyStops.length === 0) {
      listEl.innerHTML = `<div class="empty-state-box">周辺のバス停が見つかりませんでした。上部の主要ターミナルボタンを押すか、地図を移動して再検索してください。</div>`;
      return;
    }

    listEl.innerHTML = state.nearbyStops.map((s) => renderStopCardHtml(s, true)).join('');
    listEl.querySelectorAll('.stop-card').forEach((card) => {
      card.addEventListener('click', () => {
        openStopDetail(card.dataset.groupId);
      });
    });
  }

  // ============================================================================
  // Selected Bus Stop Departure Board & Timetable
  // ============================================================================
  async function openStopDetail(groupId) {
    state.selectedGroupId = groupId;
    state.selectedPoleId = '';
    state.selectedDestGroupId = '';
    state.detailMode = 'realtime';

    const detailPanel = document.getElementById('stop-detail-panel');
    const mainTabs = document.getElementById('main-tabs-container');
    if (detailPanel) detailPanel.hidden = false;
    if (mainTabs) mainTabs.hidden = true;

    syncDetailModeTabs();
    await loadAndRenderStopDetail(groupId, true);
  }

  function closeStopDetail() {
    state.selectedGroupId = null;
    state.selectedPoleId = '';
    state.selectedDestGroupId = '';
    state.currentStopDetail = null;

    const detailPanel = document.getElementById('stop-detail-panel');
    const mainTabs = document.getElementById('main-tabs-container');
    if (detailPanel) detailPanel.hidden = true;
    if (mainTabs) mainTabs.hidden = false;

    renderMapPoleMarkers(null);
    renderMapStopMarkers();
  }

  async function loadAndRenderStopDetail(groupId, panMap = false) {
    const qs = new URLSearchParams({
      group_id: groupId,
      pole_id: state.selectedPoleId,
      dest_group_id: state.selectedDestGroupId,
    });
    const detail = await apiGet(`/api/stops/detail?${qs.toString()}`);
    state.currentStopDetail = detail;

    if (panMap) {
      flyToCenter(detail.lat, detail.lon, 17);
    }

    renderMapStopMarkers();
    renderMapPoleMarkers(detail);

    // Header signboard
    document.getElementById('detail-stop-name').textContent = detail.name;
    const subParts = [detail.hira || detail.kana, detail.en].filter(Boolean);
    document.getElementById('detail-stop-sub').textContent = subParts.join(' / ');

    const boardablePoles = (detail.poles || []).filter((p) => p.is_boardable !== false && p.stop_no !== '降車');
    document.getElementById('detail-pole-count-badge').textContent = `${Math.max(1, boardablePoles.length)}のりば`;

    const compRow = document.getElementById('detail-companies-row');
    if (compRow) {
      compRow.innerHTML = (detail.companies || [])
        .map((c) => `<span class="company-tag" style="background:${esc(c.color)};">${esc(c.short)}</span>`)
        .join('');
    }
    syncFavoriteStarButton();

    // Noriba (Platform) selector pills
    renderNoribaPills(detail);

    // Reachable destinations filter chips
    renderDestinationChips(detail);

    // Render LED summary & Upcoming approach cards
    renderUpcomingBuses(detail);

    // If user is in timetable mode, refresh timetable too
    if (state.detailMode === 'timetable') {
      await loadAndRenderTimetable();
    }
  }

  function renderNoribaPills(detail) {
    const container = document.getElementById('noriba-pills-container');
    const hintEl = document.getElementById('selected-noriba-desc');
    if (!container) return;

    const poles = (detail.poles || []).filter((p) => p.is_boardable !== false && p.stop_no !== '降車');
    if (poles.length <= 1) {
      const dirTxt = poles[0]?.directions?.join('・') || '全方面';
      if (hintEl) hintEl.textContent = dirTxt;
      container.innerHTML = '';
      return;
    }

    let activePoleObj = poles.find((p) => p.same_pole_id === state.selectedPoleId);
    if (hintEl) {
      hintEl.textContent = activePoleObj
        ? `${activePoleObj.stop_no || '-'}番のりば：${(activePoleObj.directions || []).join(' / ') || '各方面'}`
        : `全${poles.length}のりば統合表示（のりば番号タップで絞り込み）`;
    }

    const allBtn = `
      <button type="button" class="noriba-pill ${state.selectedPoleId === '' ? 'active' : ''}" data-pole-id="">
        <span>すべてのりば</span>
      </button>
    `;

    const poleBtns = poles
      .map((p) => {
        const isAct = state.selectedPoleId === p.same_pole_id;
        const dirShort = (p.directions || [])[0] || '';
        const cleanDir = dirShort.replace(/^[0-9]+\s+/, '').slice(0, 14);
        return `
          <button type="button" class="noriba-pill ${isAct ? 'active' : ''}" data-pole-id="${esc(p.same_pole_id)}">
            <span class="noriba-pill-num">${esc(p.stop_no || '-')}</span>
            <span>${esc(cleanDir || 'のりば')}</span>
          </button>
        `;
      })
      .join('');

    container.innerHTML = allBtn + poleBtns;
    container.querySelectorAll('.noriba-pill').forEach((btn) => {
      btn.addEventListener('click', () => {
        selectPoleFilter(btn.dataset.poleId || '');
      });
    });
  }

  async function selectPoleFilter(poleId) {
    state.selectedPoleId = poleId;
    if (!state.selectedGroupId) return;

    const pObj = state.currentStopDetail?.poles?.find((p) => p.same_pole_id === poleId);
    if (pObj && pObj.lat && pObj.lon) {
      flyToCenter(pObj.lat, pObj.lon, 18);
    }
    await loadAndRenderStopDetail(state.selectedGroupId, false);
  }

  function renderDestinationChips(detail) {
    const wrap = document.getElementById('dest-chips-container');
    if (!wrap) return;
    const dests = detail.reachable_destinations || [];
    if (dests.length === 0) {
      wrap.innerHTML = '';
      return;
    }

    const allChip = `<button type="button" class="dest-chip ${state.selectedDestGroupId === '' ? 'active' : ''}" data-dest="">すべての行き先</button>`;
    const chips = dests
      .map(
        (d) => `
        <button type="button" class="dest-chip ${state.selectedDestGroupId === d.group_id ? 'active' : ''}" data-dest="${esc(d.group_id)}">
          ${esc(d.name)}
        </button>
      `
      )
      .join('');

    wrap.innerHTML = allChip + chips;
    wrap.querySelectorAll('.dest-chip').forEach((btn) => {
      btn.addEventListener('click', async () => {
        state.selectedDestGroupId = btn.dataset.dest || '';
        await loadAndRenderStopDetail(state.selectedGroupId, false);
      });
    });
  }

  function renderUpcomingBuses(detail) {
    const ledContainer = document.getElementById('led-summary-rows');
    const listContainer = document.getElementById('upcoming-bus-list');
    const ledTime = document.getElementById('led-board-updated');
    if (ledTime) ledTime.textContent = `${detail.current_time || ''} 現在`;

    const upcoming = detail.upcoming || [];

    if (ledContainer) {
      if (upcoming.length === 0) {
        ledContainer.innerHTML = `<div class="led-row"><span class="led-pole">--</span><span class="led-dest">本日の運行は終了しました</span><span class="led-time-status">--:--</span></div>`;
      } else {
        ledContainer.innerHTML = upcoming
          .slice(0, 3)
          .map((u) => {
            const poleTxt = u.stop_no ? `${u.stop_no}番` : 'のりば';
            const rNo = u.route_short_name ? `[${u.route_short_name}] ` : '';
            const isDel = u.delay_min > 0;
            const statusStr = u.is_next_day_preview
              ? `始発 ${u.scheduled_time}`
              : u.minutes_until <= 1
              ? `まもなく (${u.realtime_time})`
              : `あと${u.minutes_until}分 (${u.realtime_time})`;
            return `
              <div class="led-row">
                <span class="led-pole">${esc(poleTxt)}</span>
                <span class="led-dest">${esc(rNo)}${esc(u.headsign)}</span>
                <span class="led-time-status ${isDel ? 'delayed' : ''}">${esc(statusStr)}</span>
              </div>
            `;
          })
          .join('');
      }
    }

    if (!listContainer) return;
    if (upcoming.length === 0) {
      listContainer.innerHTML = `<div class="empty-state-box">この条件に該当する直近のバスはありません。「時刻表」タブから全時間帯の時刻表をご確認いただけます。</div>`;
      return;
    }

    listContainer.innerHTML = upcoming
      .map((u) => {
        const isDel = u.delay_min > 0;
        const delayPillHtml = IS_ANDROID_APP && u.realtime_source !== 'live'
          ? `<span class="delay-pill">時刻表・遅延情報なし</span>` : isDel
          ? `<span class="delay-pill delayed">⚠ ${u.delay_min}分遅れ</span>`
          : `<span class="delay-pill on-time">✓ 定刻運行</span>`;

        const routeSignHtml = u.route_short_name
          ? `<span class="route-num-sign">${esc(u.route_short_name)}</span>`
          : '';

        const noribaHtml = u.stop_no
          ? `<span class="noriba-tag">${esc(u.stop_no)}番のりば</span>`
          : '';

        const vehIdHtml = u.vehicle_id
          ? `<span class="veh-id-tag">車番 #${esc(u.vehicle_id)}</span>`
          : '';

        const lastBusHtml = u.is_last_bus ? `<span class="last-bus-tag">最終便</span>` : '';

        let approachMainText = '';
        let approachSubPillHtml = '';
        let isImminent = false;
        if (u.is_next_day_preview) {
          approachMainText = `朝の始発便プレビュー`;
          approachSubPillHtml = `<span class="approach-sub-pill">定刻 ${esc(u.scheduled_time)}発</span>`;
        } else if (IS_ANDROID_APP && u.realtime_source !== 'live') {
          approachMainText = `定刻まで約${u.minutes_until}分（運行状況未確認）`;
        } else if (u.minutes_until <= 1) {
          approachMainText = 'まもなく到着します';
          approachSubPillHtml = `<span class="approach-sub-pill">バス停付近</span>`;
          isImminent = true;
        } else if (u.stops_away != null && u.stops_away > 0) {
          approachMainText = `あと約${u.minutes_until}分で到着`;
          approachSubPillHtml = `<span class="approach-sub-pill">${u.stops_away}つ前走行中</span>`;
          if (u.minutes_until <= 3) isImminent = true;
        } else {
          approachMainText = `発車まであと約${u.minutes_until}分`;
        }

        const destEtaHtml = u.dest_stop_name
          ? `<div class="bus-dest-eta-box">🎯 ${esc(u.dest_stop_name)} に <strong>${esc(u.dest_realtime_time)}</strong> 到着予定（所要約${u.travel_min}分）</div>`
          : '';

        return `
          <article class="bus-approach-card" style="border-left-color:${esc(u.company_color)};"
                   data-company="${esc(u.company)}" data-trip-id="${esc(u.trip_id)}">
            <div class="bus-card-header">
              <div class="bus-card-badges">
                <span class="company-tag" style="background:${esc(u.company_color)};">${esc(u.company_short)}</span>
                ${routeSignHtml}
                ${noribaHtml}
                ${vehIdHtml}
                ${lastBusHtml}
              </div>
              ${delayPillHtml}
            </div>

            <div class="bus-card-body">
              <div class="bus-dest-col">
                <div class="bus-headsign">${formatHeadsignHtml(u.headsign)} <span style="font-size:12px;font-weight:700;color:#47586e;white-space:nowrap;">ゆき</span></div>
                ${u.via_text ? `<div class="bus-via">経由：${esc(u.via_text)}</div>` : ''}
                ${destEtaHtml}
              </div>

              <div class="bus-times-comparison">
                <div class="time-col">
                  <span class="time-col-label">時刻表(定刻)</span>
                  <span class="time-val-sched ${isDel ? 'struck' : ''}">${esc(u.scheduled_time)}</span>
                </div>
                <span class="time-arrow">▶</span>
                <div class="time-col">
                  <span class="time-col-label">${IS_ANDROID_APP && u.realtime_source !== 'live' ? '定刻（参考）' : 'リアルタイム'}</span>
                  <span class="time-val-rt ${isDel ? 'delayed' : ''}">${esc(u.realtime_time)}</span>
                </div>
              </div>
            </div>

            <div class="bus-card-footer">
              <div class="approach-status-text ${isImminent ? 'imminent' : ''}">
                <span class="approach-pulse"></span>
                <span class="approach-main-txt">${esc(approachMainText)}</span>
                ${approachSubPillHtml}
              </div>
              <div class="vehicle-meta-right">
                <span class="tap-route-hint">停車順・ルート ▶</span>
              </div>
            </div>
          </article>
        `;
      })
      .join('');

    listContainer.querySelectorAll('.bus-approach-card').forEach((card) => {
      card.addEventListener('click', () => {
        openTripTimelineModal(card.dataset.company, card.dataset.tripId);
      });
    });
  }

  // ============================================================================
  // Full-Day Station Timetable
  // ============================================================================
  async function loadAndRenderTimetable() {
    if (!state.selectedGroupId) return;
    const qs = new URLSearchParams({
      group_id: state.selectedGroupId,
      pole_id: state.selectedPoleId,
      day_type: state.timetableDayType,
      route_filter: state.timetableRouteFilter,
    });
    const tt = await apiGet(`/api/stops/timetable?${qs.toString()}`);
    document.querySelectorAll('.day-switch-btn').forEach((button) => {
      button.classList.toggle('active', button.dataset.day === tt.day_type);
    });

    // Populate route filter dropdown
    const routeSelect = document.getElementById('timetable-route-select');
    if (routeSelect && Array.isArray(tt.route_options)) {
      const currentVal = state.timetableRouteFilter;
      routeSelect.innerHTML =
        `<option value="">すべての系統・行き先 (${tt.route_options.length}系統)</option>` +
        tt.route_options
          .map(
            (ro) =>
              `<option value="${esc(ro.key)}" ${ro.key === currentVal ? 'selected' : ''}>【${esc(ro.company_short)}】${esc(ro.key)}</option>`
          )
          .join('');
    }

    const summaryEl = document.getElementById('timetable-meta-summary');
    const dayLabels = { weekday: '平日ダイヤ', saturday: '土曜ダイヤ', holiday: '日曜・祝日ダイヤ' };
    if (summaryEl) {
      summaryEl.textContent = `${dayLabels[state.timetableDayType]} ／ 全 ${tt.total_departures} 便（時刻をタップするとその便の全停車バス停を表示）`;
    }

    const gridEl = document.getElementById('timetable-grid-container');
    if (!gridEl) return;

    if (!tt.hourly_schedule || tt.hourly_schedule.length === 0) {
      gridEl.innerHTML = `<div class="empty-state-box" style="margin:0;border:none;">該当するダイヤの便はありません。曜日またはのりばを切り替えてご確認ください。</div>`;
      return;
    }

    const nowHour = new Date().getHours();
    gridEl.innerHTML = tt.hourly_schedule
      .map((row) => {
        const isCurrentHr = row.hour === nowHour;
        const cells = row.entries
          .map((e) => {
            const lastMark = e.is_last_bus ? `<span class="last-bus-tag" style="margin-left:3px;">終</span>` : '';
            return `
              <button type="button" class="tt-entry-chip" style="border-left-color:${esc(e.company_color)};"
                      data-company="${esc(e.company)}" data-trip-id="${esc(e.trip_id)}"
                      title="${esc(e.company_short)} ${esc(e.departure_time)}発 ${esc(e.headsign)}ゆき">
                <div class="tt-min-top">
                  <span class="tt-min-num">${esc(e.minute)}</span>
                  <span class="tt-route-mini">${esc(e.route_short_name || e.company_short.slice(0, 2))}</span>
                  ${lastMark}
                </div>
                <div class="tt-dest-mini">${esc(e.headsign)}</div>
              </button>
            `;
          })
          .join('');

        return `
          <div class="tt-hour-row ${isCurrentHr ? 'current-hour' : ''}">
            <div class="tt-hour-cell">
              <span>${String(row.hour).padStart(2, '0')}</span>
              <span class="tt-hour-unit">時</span>
            </div>
            <div class="tt-minutes-cell">${cells}</div>
          </div>
        `;
      })
      .join('');

    gridEl.querySelectorAll('.tt-entry-chip').forEach((chip) => {
      chip.addEventListener('click', () => {
        openTripTimelineModal(chip.dataset.company, chip.dataset.tripId);
      });
    });
  }

  function syncDetailModeTabs() {
    document.querySelectorAll('.detail-mode-tab').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.detailMode === state.detailMode);
    });
    const rtView = document.getElementById('subview-realtime');
    const ttView = document.getElementById('subview-timetable');
    if (rtView) rtView.hidden = state.detailMode !== 'realtime';
    if (ttView) ttView.hidden = state.detailMode !== 'timetable';
  }

  // ============================================================================
  // Trip Route Timeline Modal
  // ============================================================================
  async function openTripTimelineModal(company, tripId) {
    if (!company || !tripId) return;
    try {
      const qs = new URLSearchParams({
        company,
        trip_id: tripId,
        highlight_group_id: state.selectedGroupId || '',
      });
      const td = await apiGet(`/api/trips/detail?${qs.toString()}`);
      drawTripPolylineOnMap(td);

      const modal = document.getElementById('trip-timeline-modal');
      if (!modal) return;
      modal.hidden = false;

      const compEl = document.getElementById('trip-modal-company');
      if (compEl) {
        compEl.textContent = td.company_short;
        compEl.style.background = td.company_color;
      }
      const rNoEl = document.getElementById('trip-modal-route-no');
      if (rNoEl) {
        rNoEl.textContent = td.route_short_name || '路線';
        rNoEl.hidden = !td.route_short_name;
      }
      const delEl = document.getElementById('trip-modal-delay');
      if (delEl) {
        const isDel = td.delay_min > 0;
        delEl.className = `delay-pill ${isDel ? 'delayed' : 'on-time'}`;
        delEl.textContent = IS_ANDROID_APP && !td.delay_known ? '時刻表・遅延情報なし' : (isDel ? `⚠ ${td.delay_min}分遅れ` : '✓ 定刻運行');
      }

      document.getElementById('trip-modal-title').textContent = `${td.headsign} ゆき`;
      document.getElementById('trip-modal-via').textContent = [
        td.route_long_name,
        td.via_text ? `経由：${td.via_text}` : '',
        td.vehicle_id ? `車番 #${td.vehicle_id}` : '',
      ]
        .filter(Boolean)
        .join(' ／ ');

      const listEl = document.getElementById('trip-timeline-list');
      if (listEl) {
        listEl.innerHTML = (td.stops || [])
          .map((s) => {
            const cls = [
              'timeline-stop-row',
              s.status,
              s.is_highlighted ? 'highlighted' : '',
            ]
              .filter(Boolean)
              .join(' ');
            const busHere = s.status === 'current' ? `<span class="tl-bus-here-badge">${IS_ANDROID_APP ? '時刻表上の目安' : '🚌 現在地付近'}</span>` : '';
            const poleStr = s.stop_no ? ` (${s.stop_no}番のりば)` : '';
            return `
              <div class="${cls}" data-group-id="${esc(s.group_id)}">
                <div class="tl-rail"><div class="tl-node"></div></div>
                <div>
                  <span class="tl-stop-name">${esc(s.stop_name)}</span>
                  <span style="font-size:11px;color:#47586e;font-weight:700;">${esc(poleStr)}</span>
                  ${busHere}
                </div>
                <div class="tl-times">
                  <div class="tl-rt-time">${esc(s.realtime_time)}</div>
                  <div class="tl-sched-time">定刻 ${esc(s.scheduled_time)}</div>
                </div>
              </div>
            `;
          })
          .join('');

        listEl.querySelectorAll('.timeline-stop-row').forEach((row) => {
          row.addEventListener('click', () => {
            modal.hidden = true;
            openStopDetail(row.dataset.groupId);
          });
        });

        const curRow = listEl.querySelector('.timeline-stop-row.current');
        if (curRow) {
          setTimeout(() => curRow.scrollIntoView({ block: 'center', behavior: 'smooth' }), 80);
        }
      }
    } catch (err) {
      console.error('Failed to load trip detail:', err);
    }
  }

  // ============================================================================
  // Search Tab (バス停検索: 漢字・ひらがな・カタカナ・英語・50音・運行会社別)
  // ============================================================================
  async function runStopSearch() {
    const qs = new URLSearchParams({
      q: state.searchQuery,
      kana_row: state.searchKanaRow,
      company: state.searchCompany,
      limit: '70',
    });
    const res = await apiGet(`/api/stops/search?${qs.toString()}`);
    const stops = res.stops || [];

    const countEl = document.getElementById('search-count-badge');
    if (countEl) countEl.textContent = `${stops.length}件`;

    const listEl = document.getElementById('search-results-list');
    if (!listEl) return;

    if (stops.length === 0) {
      listEl.innerHTML = `<div class="empty-state-box">条件に一致するバス停が見つかりませんでした。ひらがな・漢字や別の50音行でお試しください。</div>`;
      return;
    }

    listEl.innerHTML = stops.map((s) => renderStopCardHtml(s, false)).join('');
    listEl.querySelectorAll('.stop-card').forEach((card) => {
      card.addEventListener('click', () => {
        openStopDetail(card.dataset.groupId);
      });
    });
  }

  // ============================================================================
  // Active Vehicles Tab (周辺エリア走行中バス一覧)
  // ============================================================================
  function renderActiveVehiclesList() {
    const countEl = document.getElementById('vehicles-list-count');
    if (countEl) countEl.textContent = `${state.activeVehicles.length}台`;

    const listEl = document.getElementById('active-vehicles-list');
    if (!listEl) return;

    if (state.activeVehicles.length === 0) {
      listEl.innerHTML = `<div class="empty-state-box">このエリア周辺を現在走行中のバスはありません。</div>`;
      return;
    }

    listEl.innerHTML = state.activeVehicles
      .map((v) => {
        const isDel = v.delay_min > 0;
        const delayHtml = IS_ANDROID_APP && !v.delay_known
          ? `<span class="delay-pill">遅延情報なし</span>` : isDel
          ? `<span class="delay-pill delayed">⚠ ${v.delay_min}分遅れ</span>`
          : `<span class="delay-pill on-time">✓ 定刻運行</span>`;
        const routeSign = v.route_short_name
          ? `<span class="route-num-sign">${esc(v.route_short_name)}</span>`
          : '';
        const sectionStr =
          v.current_stop_name && v.next_stop_name
            ? `現在区間：${v.current_stop_name} ▶ ${v.next_stop_name}`
            : 'GPSリアルタイム測位中';

        return `
          <article class="bus-approach-card" style="border-left-color:${esc(v.company_color)};"
                   data-company="${esc(v.company)}" data-trip-id="${esc(v.trip_id)}"
                   data-lat="${v.lat}" data-lon="${v.lon}">
            <div class="bus-card-header">
              <div class="bus-card-badges">
                <span class="company-tag" style="background:${esc(v.company_color)};">${esc(v.company_short)}</span>
                ${routeSign}
                <span class="veh-id-tag">車番 #${esc(v.vehicle_id)}</span>
              </div>
              ${delayHtml}
            </div>
            <div class="bus-card-body">
              <div class="bus-dest-col">
                <div class="bus-headsign">${formatHeadsignHtml(v.headsign)} <span style="font-size:12px;font-weight:700;color:#47586e;white-space:nowrap;">ゆき</span></div>
                ${v.via_text ? `<div class="bus-via">経由：${esc(v.via_text)}</div>` : ''}
              </div>
            </div>
            <div class="bus-card-footer">
              <div class="approach-status-text">
                <span class="approach-pulse"></span>
                <span class="approach-main-txt" style="overflow:hidden;text-overflow:ellipsis;">${esc(sectionStr)}</span>
              </div>
              <div class="vehicle-meta-right">
                <span class="tap-route-hint">MAP追跡＆停車順 ▶</span>
              </div>
            </div>
          </article>
        `;
      })
      .join('');

    listEl.querySelectorAll('.bus-approach-card').forEach((card) => {
      card.addEventListener('click', () => {
        const lat = parseFloat(card.dataset.lat);
        const lon = parseFloat(card.dataset.lon);
        if (lat && lon) flyToCenter(lat, lon, 17);
        openTripTimelineModal(card.dataset.company, card.dataset.tripId);
      });
    });
  }

  // ============================================================================
  // Favorites Tab (お気に入りバス停＆直近便一覧)
  // ============================================================================
  async function renderFavoritesTab() {
    const countEl = document.getElementById('favorites-count-badge');
    if (countEl) countEl.textContent = `${state.favorites.length}件`;

    const listEl = document.getElementById('favorites-stops-list');
    if (!listEl) return;

    if (state.favorites.length === 0) {
      listEl.innerHTML = `<div class="empty-state-box">お気に入り登録されたバス停はありません。各バス停画面の右上にある「☆ 登録」ボタンからワンタップで登録できます。</div>`;
      return;
    }

    const details = await Promise.all(
      state.favorites.map((gid) =>
        apiGet(`/api/stops/detail?group_id=${encodeURIComponent(gid)}&limit=3`).catch(() => null)
      )
    );

    const valid = details.filter(Boolean);
    listEl.innerHTML = valid
      .map((d) => {
        const cardData = {
          group_id: d.group_id,
          name: d.name,
          hira: d.hira,
          kana: d.kana,
          companies: d.companies,
          pole_count: (d.poles || []).filter((p) => p.is_boardable !== false).length,
          next_buses: (d.upcoming || []).slice(0, 3),
        };
        return renderStopCardHtml(cardData, false);
      })
      .join('');

    listEl.querySelectorAll('.stop-card').forEach((card) => {
      card.addEventListener('click', () => {
        openStopDetail(card.dataset.groupId);
      });
    });
  }

  // ============================================================================
  // Navigation & Event Listeners
  // ============================================================================
  function switchMainTab(tabName) {
    state.activeTab = tabName;
    closeStopDetail();

    document.querySelectorAll('.nav-tab-btn').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.tab === tabName);
    });

    const tabMap = {
      nearby: 'tab-panel-nearby',
      search: 'tab-panel-search',
      vehicles: 'tab-panel-vehicles',
      favorites: 'tab-panel-favorites',
    };
    Object.entries(tabMap).forEach(([key, id]) => {
      const el = document.getElementById(id);
      if (el) el.hidden = key !== tabName;
    });

    if (tabName === 'search') {
      runStopSearch();
    } else if (tabName === 'favorites') {
      renderFavoritesTab();
    }
  }

  function setupEvents() {
    // Live clock
    const clockEl = document.getElementById('live-clock');
    const tickClock = () => {
      const now = new Date();
      if (clockEl) {
        clockEl.textContent = IS_ANDROID_APP
          ? new Intl.DateTimeFormat('ja-JP', { timeZone: 'Asia/Tokyo', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).format(now)
          : now.toTimeString().slice(0, 8);
      }
    };
    tickClock();
    setInterval(tickClock, 1000);

    // Manual refresh
    document.getElementById('btn-manual-refresh')?.addEventListener('click', () => {
      refreshAreaData();
    });

    // GPS Geolocation button
    document.getElementById('btn-gps-locate')?.addEventListener('click', () => {
      if (!navigator.geolocation) {
        alert('お使いのブラウザでは位置情報(GPS)がサポートされていません。');
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          state.center = {
            lat: pos.coords.latitude,
            lon: pos.coords.longitude,
            label: '現在地',
          };
          document.querySelectorAll('#terminal-chips-container .jump-chip').forEach((b) => b.classList.remove('active'));
          flyToCenter(state.center.lat, state.center.lon, 17);
          refreshAreaData();
        },
        () => {
          // If permission denied or indoors on desktop, center on Hiroshima Station & notify gently
          flyToCenter(state.center.lat, state.center.lon, 17);
          refreshAreaData();
        },
        { enableHighAccuracy: true, timeout: 6000 }
      );
    });

    // Map "Search this area" button
    document.getElementById('btn-search-this-area')?.addEventListener('click', () => {
      if (!map) return;
      const c = map.getCenter();
      state.center = { lat: c.lat, lon: c.lng, label: '地図中心' };
      document.getElementById('btn-search-this-area').hidden = true;
      updateCenterPin();
      refreshAreaData();
    });

    // Toggle buses on map
    const btnToggleBuses = document.getElementById('btn-toggle-buses');
    btnToggleBuses?.addEventListener('click', () => {
      state.showBusesOnMap = !state.showBusesOnMap;
      btnToggleBuses.classList.toggle('active', state.showBusesOnMap);
      btnToggleBuses.innerHTML = `<span>🚌 位置${state.showBusesOnMap ? 'ON' : 'OFF'}</span>`;
      renderMapBusMarkers();
    });

    // Map company filter
    document.getElementById('map-company-filter')?.addEventListener('change', (e) => {
      state.mapCompanyFilter = e.target.value || '';
      refreshAreaData();
    });

    // Map theme selector (都市ナビ / シンプル / ナイト / 標準道路)
    document.getElementById('map-theme-select')?.addEventListener('change', (e) => {
      setMapTheme(e.target.value);
    });

    // Clear route polyline button
    document.getElementById('btn-clear-route')?.addEventListener('click', () => {
      clearTripPolylineOnMap();
    });

    // Split screen height switcher
    const shell = document.getElementById('app-shell');
    document.querySelectorAll('.split-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const mode = btn.dataset.split;
        shell.classList.remove('split-map-large', 'split-standard', 'split-list-large');
        shell.classList.add(mode);
        document.querySelectorAll('.split-btn').forEach((b) => b.classList.toggle('active', b === btn));
        setTimeout(() => map?.invalidateSize(), 280);
      });
    });

    // Stop detail back & favorite buttons
    document.getElementById('btn-close-stop-detail')?.addEventListener('click', () => {
      closeStopDetail();
    });
    document.getElementById('btn-toggle-favorite')?.addEventListener('click', () => {
      toggleFavorite(state.selectedGroupId);
    });

    // Detail sub-mode tabs (Realtime vs Timetable)
    document.querySelectorAll('.detail-mode-tab').forEach((btn) => {
      btn.addEventListener('click', async () => {
        state.detailMode = btn.dataset.detailMode;
        syncDetailModeTabs();
        if (state.detailMode === 'timetable') {
          await loadAndRenderTimetable();
        }
      });
    });

    // Timetable day type switch & route select
    document.querySelectorAll('.day-switch-btn').forEach((btn) => {
      btn.addEventListener('click', async () => {
        state.timetableDayType = btn.dataset.day;
        document.querySelectorAll('.day-switch-btn').forEach((b) => b.classList.toggle('active', b === btn));
        await loadAndRenderTimetable();
      });
    });
    document.getElementById('timetable-route-select')?.addEventListener('change', async (e) => {
      state.timetableRouteFilter = e.target.value || '';
      await loadAndRenderTimetable();
    });

    // Search input (IME-safe) & 50-on buttons
    const searchInput = document.getElementById('stop-search-input');
    const clearSearchBtn = document.getElementById('btn-clear-search');
    if (searchInput) {
      searchInput.addEventListener('compositionstart', () => {
        state.isComposing = true;
      });
      searchInput.addEventListener('compositionend', () => {
        state.isComposing = false;
        state.searchQuery = searchInput.value;
        if (clearSearchBtn) clearSearchBtn.hidden = !searchInput.value;
        runStopSearch();
      });
      searchInput.addEventListener('input', () => {
        if (state.isComposing) return;
        state.searchQuery = searchInput.value;
        if (clearSearchBtn) clearSearchBtn.hidden = !searchInput.value;
        runStopSearch();
      });
      searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.isComposing) {
          searchInput.blur();
          runStopSearch();
        }
      });
    }
    clearSearchBtn?.addEventListener('click', () => {
      if (!searchInput) return;
      searchInput.value = '';
      state.searchQuery = '';
      clearSearchBtn.hidden = true;
      runStopSearch();
    });

    document.querySelectorAll('.kana-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        state.searchKanaRow = btn.dataset.kana || '';
        document.querySelectorAll('.kana-btn').forEach((b) => b.classList.toggle('active', b === btn));
        runStopSearch();
      });
    });

    // Trip modal close & focus map
    const tripModal = document.getElementById('trip-timeline-modal');
    document.getElementById('btn-close-trip-modal')?.addEventListener('click', () => {
      if (tripModal) tripModal.hidden = true;
    });
    tripModal?.addEventListener('click', (e) => {
      if (e.target === tripModal) tripModal.hidden = true;
    });
    document.getElementById('btn-focus-trip-map')?.addEventListener('click', () => {
      if (tripModal) tripModal.hidden = true;
      shell.classList.remove('split-standard', 'split-list-large');
      shell.classList.add('split-map-large');
      document.querySelectorAll('.split-btn').forEach((b) => b.classList.toggle('active', b.dataset.split === 'split-map-large'));
      setTimeout(() => map?.invalidateSize(), 280);
    });

    // Bottom navigation tabs
    document.querySelectorAll('.nav-tab-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        switchMainTab(btn.dataset.tab);
      });
    });

    // Auto-polling every 20 seconds when tab is visible
    setInterval(() => {
      if (document.visibilityState === 'visible') {
        refreshAreaData();
        if (IS_ANDROID_APP) {
          apiGet('/api/meta').then((data) => {
            const el = document.getElementById('rt-status-text');
            if (el) el.textContent = data.realtime?.is_live
              ? `LIVE ${data.realtime.live_vehicle_count}台` : '時刻表モード';
          }).catch(() => {});
        }
      }
    }, 20000);
  }

  // ============================================================================
  // Bootstrap
  // ============================================================================
  async function init() {
    if (IS_ANDROID_APP) {
      document.documentElement.dataset.platform = 'android';
      const brand = document.querySelector('.sign-title-en');
      if (brand) {
        const info = document.createElement('a');
        info.href = './about-android.html';
        info.textContent = 'アプリ情報・プライバシー';
        info.style.cssText = 'color:inherit;font-size:10px;text-decoration:underline';
        brand.replaceChildren(info);
      }
    }
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker
        .getRegistrations()
        .then((regs) => regs.forEach((r) => r.unregister()))
        .catch(() => {});
    }
    loadFavorites();
    initMap();
    setupEvents();
    await loadMeta();
    await refreshAreaData();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
