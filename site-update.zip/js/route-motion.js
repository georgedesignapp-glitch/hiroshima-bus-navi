/* Bounded timetable simulation anchored to an observed GPS fix. Not live GPS. */
(function(root){
  'use strict';
  const R=6371000,rad=Math.PI/180;
  const distance=(a,b)=>{const y=(b[0]-a[0])*rad,x=(b[1]-a[1])*rad*Math.cos((a[0]+b[0])*rad/2);return Math.hypot(x,y)*R;};
  function prepare(points){
    if(!Array.isArray(points)||points.length<2)return null;
    const path=points.filter(p=>Array.isArray(p)&&p.length>=2&&p.every(Number.isFinite)&&Math.abs(p[0])<=90&&Math.abs(p[1])<=180);
    if(path.length<2)return null;const lengths=[0];for(let i=1;i<path.length;i++)lengths.push(lengths[i-1]+distance(path[i-1],path[i]));
    return {path,lengths,total:lengths.at(-1)};
  }
  function project(route,point){
    const candidates=[];
    for(let i=1;i<route.path.length;i++){
      const a=route.path[i-1],b=route.path[i],scale=Math.cos(point[0]*rad),dx=(b[1]-a[1])*scale,dy=b[0]-a[0],den=dx*dx+dy*dy;
      if(!den)continue;
      const t=Math.max(0,Math.min(1,((point[1]-a[1])*scale*dx+(point[0]-a[0])*dy)/den));
      const p=[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];
      candidates.push({distance:distance(p,point),along:route.lengths[i-1]+t*(route.lengths[i]-route.lengths[i-1])});
    }
    candidates.sort((a,b)=>a.distance-b.distance);const best=candidates[0];
    if(!best||best.distance>150)return null;
    if(candidates.some(c=>c.distance<=best.distance+5&&Math.abs(c.along-best.along)>250))return null;
    return best.along;
  }
  function at(route,along){
    along=Math.max(0,Math.min(route.total,along));let low=1,high=route.lengths.length-1;
    while(low<high){const mid=(low+high)>>1;if(route.lengths[mid]<along)low=mid+1;else high=mid;}const i=low;
    const a=route.path[i-1],b=route.path[i],span=route.lengths[i]-route.lengths[i-1],t=span?(along-route.lengths[i-1])/span:0;
    return [a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];
  }
  function between(route,from,to){
    if(!route)return null;const a=project(route,from),b=project(route,to);
    if(a===null||b===null||b<a-5||b-a>3000)return null;
    return t=>at(route,a+(b-a)*Math.max(0,Math.min(1,t)));
  }
  function profile(points,stops){
    const route=prepare(points),valid=(stops||[]).filter(s=>[s.lat,s.lon,s.arrival_epoch,s.departure_epoch].every(Number.isFinite));
    if(valid.length<2)return null;
    if(!route)return {route:null,stops:valid.map((s,i)=>({...s,along:i}))};
    // Match the complete ordered stop list. A greedy nearest-point choice can
    // select the return leg of a loop and discard every intervening stop.
    const better=(a,b)=>!b||a.count>b.count||(a.count===b.count&&a.cost<b.cost);
    let states=[{along:0,count:0,cost:0,previous:null,stop:null}];
    for(const s of valid){
      const candidates=[];
      for(let i=1;i<route.path.length;i++){
        const a=route.path[i-1],b=route.path[i],scale=Math.cos(s.lat*rad),dx=(b[1]-a[1])*scale,dy=b[0]-a[0],den=dx*dx+dy*dy;if(!den)continue;
        const t=Math.max(0,Math.min(1,((s.lon-a[1])*scale*dx+(s.lat-a[0])*dy)/den));
        const point=[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t],d=distance(point,[s.lat,s.lon]),along=route.lengths[i-1]+t*(route.lengths[i]-route.lengths[i-1]);
        if(d<=150)candidates.push({along,distance:d});
      }
      candidates.sort((a,b)=>a.along-b.along);
      const next=[...states];let cursor=0,best=null;
      for(const candidate of candidates){
        while(cursor<states.length&&states[cursor].along<=candidate.along+5){const state=states[cursor++];if(better(state,best))best=state;}
        if(best)next.push({along:Math.max(best.along,candidate.along),count:best.count+1,cost:best.cost+candidate.distance**2,previous:best,stop:s});
      }
      // Earlier positions with an equal or better score dominate later ones.
      next.sort((a,b)=>a.along-b.along);states=[];best=null;
      for(const state of next)if(better(state,best)){states.push(state);best=state;}
    }
    let best=null;for(const state of states)if(better(state,best))best=state;
    const schedule=[];
    for(let state=best;state?.stop;state=state.previous)schedule.push({...state.stop,along:state.along});
    schedule.reverse();
    if(schedule.length<2)return {route:null,stops:valid.map((s,i)=>({...s,along:i}))};
    const matched=new Map(schedule.map(s=>[s.sequence,s.along]));
    // Keep all timetable events even where the supplied shape misses a stop.
    // Those intervals use labelled stop-position fallback, never a made-up road.
    return {route,stops:valid.map(s=>({...s,along:matched.get(s.sequence)??null}))};
  }
  function clockPlan(data,timing=[]){
    if(!data)return null;
    const updates=new Map(timing.map(t=>[t[0],t]));let previous=-Infinity;
    const stops=data.stops.map((s,i)=>{
      const u=updates.get(s.sequence);if(u?.[3])return null;
      const departure=Math.max(previous,u?.[2]??s.departure_epoch),explicit=u?.[1]??s.arrival_epoch;
      let arrival=Math.max(previous,Math.min(explicit,departure));
      if(i>0&&i<data.stops.length-1&&departure-arrival<1)arrival=Math.max(previous,departure-Math.min(10,Math.max(0,(departure-previous)*.25)));
      previous=departure;return {...s,arrival,departure};
    }).filter(Boolean);
    if(stops.length<2)return null;
    return {route:data.route,stops,start:stops[0].departure,end:stops.at(-1).arrival};
  }
  function clockPosition(plan,now,single=false){
    if(!plan)return null;const {stops,start,end}=plan;
    let from=stops[0],to=from,along=from.along,phase='waiting';
    if(now>=end){from=to=stops.at(-1);along=from.along;phase='arrived';}
    else if(now>=start){
      let low=0,high=stops.length-1;
      while(low<high){const mid=(low+high+1)>>1;if(stops[mid].departure<=now)low=mid;else high=mid-1;}
      from=stops[low];to=stops[Math.min(low+1,stops.length-1)];
      if(now>=to.arrival){along=to.along;phase='dwell';}
      else {const t=Math.max(0,Math.min(1,(now-from.departure)/(to.arrival-from.departure||1)));along=Number.isFinite(from.along)&&Number.isFinite(to.along)?from.along+(to.along-from.along)*t:null;phase='running';}
    }
    const routeUnavailable=!plan.route||!Number.isFinite(along);
    const fallback=phase==='dwell'?to:from,point=routeUnavailable?[fallback.lat,fallback.lon]:at(plan.route,along);
    const opacity=single&&now<start-30 ? .65 : Math.max(0,Math.min(1,(now-(start-30))/3,(end+30-now)/10));
    return {point,along,phase,opacity,simulated:true,routeUnavailable};
  }
  function simulate(data,v){
    if(!data||v.last_known||!Number.isFinite(v.position_updated_at))return null;
    const {route,stops}=data,anchor=project(route,[v.lat,v.lon]),stamp=v.position_updated_at;
    if(anchor===null)return null;
    const sequence=v.current_stop_sequence;
    const current=stops.find(s=>s.sequence===sequence);
    const stopped=v.current_status===1&&current&&Math.abs(current.along-anchor)<60;
    const next=stops.find(s=>s.along>anchor+8&&(!Number.isFinite(sequence)||s.sequence>=(stopped?sequence+1:sequence)));
    if(!next)return null;
    const previous=[...stops].reverse().find(s=>s.along<=anchor+8&&s.sequence<next.sequence);
    if(!previous||next.along<=previous.along||next.arrival_epoch<=previous.departure_epoch)return null;
    const fraction=Math.max(0,Math.min(1,(anchor-previous.along)/(next.along-previous.along)));
    const scheduled=stopped?current.arrival_epoch:previous.departure_epoch+(next.arrival_epoch-previous.departure_epoch)*fraction;
    // Infer a timing offset from the received fix if no delay prediction is provided.
    const offset=v.delay_known&&Number.isFinite(v.delay_sec)?v.delay_sec:stamp-scheduled;
    const start=stopped?Math.max(stamp,current.departure_epoch+offset):stamp;
    const remaining=next.along-anchor;
    let end=next.arrival_epoch+offset;
    // Never rush a marker to catch up to an already elapsed timetable.
    if(end<=start)end=start+(next.arrival_epoch-previous.departure_epoch)*(1-fraction);
    end=Math.max(end,start+remaining/22.2); // ceiling ~80km/h, animation only
    if(!Number.isFinite(end)||end<=start)return null;
    return {route,anchor,next:next.along,start,end,expires:stamp+120,
      along(now){const t=Math.max(0,Math.min(1,(Math.min(now,stamp+120)-start)/(end-start)));return anchor+remaining*t;}};
  }
  // Distances are metres. Limit catch-up speed and never rewind the displayed trip.
  function forwardCorrection(previous,target,elapsed){
    if(!Number.isFinite(previous))return target;
    return previous+Math.min(Math.max(0,target-previous),20*Math.max(0,Math.min(1,elapsed)));
  }
  const api={prepare,project,at,between,profile,simulate,clockPlan,clockPosition,forwardCorrection};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.BusRouteMotion=api;
})(typeof window!=='undefined'?window:globalThis);
