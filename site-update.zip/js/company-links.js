(() => {
  const trigger=document.getElementById('btn-company-links');
  const dialog=document.getElementById('company-links-dialog');
  const list=document.getElementById('company-links-list');
  const labels={'73308150':['ボン・バス','エイチ・ディー西広島'],'73805130':['おおのハートバス','ささき観光'],'73885010':['廿日市市','佐伯・吉和さくらバス']};
  const colors={'73086101':'#1b7f3b','73008250':'#d32f2f','73385130':'#e65100','73900430':'#0d1b2a','72700110':'#0075c9','73208220':'#1565c0','73308150':'#2cb693','73805130':'#c18a26','73885010':'#e57994','73785010':'#4aa9db','72904160':'#1b7f3b','73385140':'#e65100','72200510':'#009e96','73700560':'#1e3a8a'};
  const companies=[{"url": "https://www.hiroden.co.jp", "class": "busCompanyNewsName bus-73086101 busCompanyUrl", "id": "73086101", "name": "広島電鉄"}, {"url": "http://www.hirobus.co.jp", "class": "busCompanyNewsName bus-73008250 busCompanyUrl", "id": "73008250", "name": "広島バス"}, {"url": "https://www.hiroko-group.co.jp/kotsu/", "class": "busCompanyNewsName bus-73385130 busCompanyUrl", "id": "73385130", "name": "広島交通"}, {"url": "http://www.geiyo.co.jp", "class": "busCompanyNewsName bus-73900430 busCompanyUrl", "id": "73900430", "name": "芸陽バス"}, {"url": "http://bihoku.co.jp/", "class": "busCompanyNewsName bus-72700110 busCompanyUrl", "id": "72700110", "name": "備北交通"}, {"url": "http://www.chugoku-jrbus.co.jp/index.html", "class": "busCompanyNewsName bus-73208220 busCompanyUrl", "id": "73208220", "name": "ＪＲバス中国"}, {"url": "http://www.bonbus.co.jp/", "class": "busCompanyNewsName bus-73308150 busCompanyUrl", "id": "73308150", "name": "エイチ・ディー西広島（ボンバス）"}, {"url": "https://www.sasakikanko.co.jp/ono-heart-bus.html", "class": "busCompanyNewsName bus-73805130 busCompanyUrl", "id": "73805130", "name": "おおのハートバス（ささき観光）"}, {"url": "https://www.city.hatsukaichi.hiroshima.jp/soshiki/118/12398.html", "class": "busCompanyNewsName bus-73885010 busCompanyUrl", "id": "73885010", "name": "廿日市市：佐伯・吉和さくらバス"}, {"url": "https://www.city.kure.lg.jp/soshiki/28/koutu.html", "class": "busCompanyNewsName bus-73785010 busCompanyUrl", "id": "73785010", "name": "呉市生活バス"}, {"url": "https://www.hiroden.co.jp", "class": "busCompanyNewsName bus-72904160 busCompanyUrl", "id": "72904160", "name": "リムジンバス"}, {"url": "https://www.hiroko-group.co.jp/kanko/", "class": "busCompanyNewsName bus-73385140 busCompanyUrl", "id": "73385140", "name": "広交観光"}, {"url": "https://onomichibus.jp/", "class": "busCompanyNewsName bus-72200510 busCompanyUrl", "id": "72200510", "name": "おのみちバス"}, {"url": "https://asahi-kotsu.co.jp/", "class": "busCompanyNewsName bus-73700560 busCompanyUrl", "id": "73700560", "name": "朝日交通"}];
  for(const company of companies){
    const a=document.createElement('a');a.className='company-site-link';a.href=company.url;
    a.setAttribute('aria-label',company.name+'の公式サイトを外部ブラウザーで開く');
    a.style.setProperty('--company',colors[company.id]);
    const name=document.createElement('span');name.className='company-site-name';
    const parts=labels[company.id]||[company.name];name.textContent=parts[0];
    if(parts[1]){const small=document.createElement('small');small.textContent=parts[1];name.append(small);}
    const arrow=document.createElement('span');arrow.className='company-site-arrow';arrow.textContent='↗';arrow.setAttribute('aria-hidden','true');a.append(name,arrow);list.append(a);
    // Android sends navigation to the external browser; browsers open a new tab.
    if(!window.BusBrand){a.target='_blank';a.rel='noopener noreferrer';}
  }
  trigger.addEventListener('click',()=>{dialog.showModal();trigger.setAttribute('aria-expanded','true');});
  document.getElementById('btn-close-company-links').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('close',()=>trigger.setAttribute('aria-expanded','false'));
})();
