(function(root){
  'use strict';
  function create(wall=()=>Date.now(),steady=()=>performance.now()){
    let sample=null;
    function status(){
      if(!sample)return {synchronized:false,source:'device'};
      const elapsed=steady()-sample.at;
      if(elapsed<0||sample.age+elapsed/1000>21600)return {synchronized:false,source:'device'};
      return {...sample,now_ms:sample.anchor+elapsed,synchronized:true,device_offset_seconds:(sample.anchor+elapsed-wall())/1000};
    }
    function now(){const s=status();return s.synchronized?s.now_ms:wall();}
    function accept(data,started,finished){
      if(!data?.synchronized){sample=null;return false;}
      const elapsed=finished-started,received=Number(data.request_received_ms),sent=Number(data.now_ms),processing=sent-received;
      if(![elapsed,received,sent,processing].every(Number.isFinite)||elapsed<0||elapsed>20000||processing<0||processing>elapsed+250)return false;
      const network=Math.max(0,elapsed-processing);
      sample={anchor:sent+network/2,at:finished,age:Number(data.synchronized_age_seconds)||0,
        source:data.source,uncertainty_seconds:(Number(data.uncertainty_seconds)||0)+network/2000};
      return true;
    }
    return {now,accept,status};
  }
  if(typeof module!=='undefined'&&module.exports)module.exports={create};else root.BusAppClock={create};
})(typeof window!=='undefined'?window:globalThis);
