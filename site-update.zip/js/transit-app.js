(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const appClock=BusAppClock.create(),appNow=()=>appClock.now();
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const today = () => new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Tokyo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(appNow()));
  const dateLabel = date => new Intl.DateTimeFormat('ja-JP',{timeZone:'Asia/Tokyo',month:'long',day:'numeric',weekday:'short'}).format(new Date(date+'T12:00:00+09:00'));
  const defaults = ['広島駅@HiroshimaArea','八丁堀@HiroshimaArea','広島バスセンター@HiroshimaArea'];
  function stored(key, fallback) { try { const value=JSON.parse(localStorage.getItem(key)); return value ?? fallback; } catch { return fallback; } }
  const S = { date:today(), pinned:false, tab:'home', group:'', pole:'', dest:'', mode:'realtime', route:'',
    center:{lat:34.3967466,lon:132.4742327}, nearby:[], vehicles:[], meta:null, detail:null, timetable:null,
    favorites:stored('hiroshima_bus_favorites_v2',stored('hiroshima_bus_favorites_v1', defaults)), poleIds:[], company:'', relevant:true, mapVisible:false,animation:true,simulations:[],
    revision:0, renderedRevision:-1, refreshing:null, again:false, forceQueued:false, selectedTrip:null, search:'', kana:'', searchCompany:'', dataState:null };
  if (!Array.isArray(S.favorites)) S.favorites=[...defaults];
  S.favorites=S.favorites.map(f=>typeof f==='string'?{group_id:f,pole_ids:[],name:f.split('@')[0],labels:[]}:f).filter(f=>f&&typeof f.group_id==='string'&&Array.isArray(f.pole_ids)).map(f=>({...f,pole_ids:[...new Set(f.pole_ids.filter(v=>typeof v==='string'&&v))].sort(),labels:Array.isArray(f.labels)?f.labels:[]}));
  S.favorites=S.favorites.filter((f,i,a)=>a.findIndex(v=>favoriteKey(v)===favoriteKey(f))===i);
  let map, markers, poles, vehiclesLayer, routeLayer, locationLayer, currentTile, searchTimer, areaTimer, dataTimer;
  let suppressMap=false, lastGeneration=-1, lastDataUpdated=0, lastFocus=null, modalAbort=null, dataLoadEnd=null;
  // Signage UI 0.6.0: independent measured GPS and timetable simulation modes.
  Object.assign(S,{positionModes:stored('hiroshima_bus_position_modes_v2',{vehicles:true,single:true}),navRoot:'home',showPrevious:true,gps:null,mapKind:null,mapViews:{},returnTab:'home',singleVehicle:null,follow:false,rows:null,rowContext:'',pendingRows:[],touching:false,interactionUntil:0,readNotices:stored('hiroshima_bus_read_notices_v3',[]),notices:stored('hiroshima_bus_notices_v3',[])});
  if(!S.positionModes||typeof S.positionModes!=='object')S.positionModes={vehicles:true,single:true};
  if(!Array.isArray(S.readNotices))S.readNotices=[];
  if(!Array.isArray(S.notices))S.notices=[];
  const vehicleMarkers=new Map();
  let followFrame=0,followTarget=null,followPanning=false;
  // Global radar display defaults do not alter remote polling.
  const radarDisplay={correction:'forward',fps:15};
  const radarZoomKey='hiroshima_bus_radar_zoom_unlocked_v1';
  let radarZoomUnlocked=stored(radarZoomKey,false)===true;
  const motionPaths=new Map(),motionFailures=new Map(),motionQueue=[];let motionRequests=0,motionFrame=0,motionPaint=0,motionLayoutAt=0;
  const motionKey=v=>`${v.company}|${v.trip_id}|${v.service_date||today()}`;
  function requestMotionPath(v){
    const key=motionKey(v);if(!S.animation||motionPaths.has(key)||Date.now()-(motionFailures.get(key)||0)<30000)return;
    motionPaths.set(key,null);motionQueue.push({key,company:v.company,trip_id:v.trip_id,service_date:v.service_date});pumpMotionPaths();
  }
  function pumpMotionPaths(){
    while(motionRequests<3&&motionQueue.length){
      const jobs=motionQueue.splice(0,12);motionRequests++;
      api('/api/routes/profiles',{requests:JSON.stringify(jobs.map(({company,trip_id,service_date})=>({company,trip_id,service_date})))}).then(data=>{
        jobs.forEach((job,i)=>{const p=data.profiles[i];motionPaths.set(job.key,BusRouteMotion.profile(p.points,p.stops));motionFailures.delete(job.key);});scheduleMotionRender();
        while(motionPaths.size>1536)motionPaths.delete(motionPaths.keys().next().value);
      }).catch(()=>{for(const job of jobs){motionPaths.delete(job.key);motionFailures.set(job.key,Date.now());}}).finally(()=>{motionRequests--;pumpMotionPaths();});
    }
  }
  const htmlCache=new WeakMap();
  let motionRenderTimer=null;
  function scheduleMotionRender(){if(motionRenderTimer||!S.mapVisible)return;motionRenderTimer=setTimeout(()=>{motionRenderTimer=null;renderMap();startVehicleMotion();},80);}

  function qs(values) { return new URLSearchParams(Object.entries(values).filter(([,v])=>v!==undefined && v!==null)).toString(); }
  async function api(path, values={}, foreground=false) {
    const end=foreground?BusBrandMotion.begin():null;let failed=false;
    try {
    if(window.BusLocalAPI){const started=performance.now(),data=await window.BusLocalAPI.request(path,values);if(path==='/api/meta'&&data.clock_sync){appClock.accept(data.clock_sync,started,performance.now());setTimeout(()=>{if(!S.pinned&&S.date!==today())changeDate(today(),false);},0);}return data;}
    const started=performance.now();
    const res=await fetch(path+'?'+qs(values),{cache:'no-store'});
    const data=await res.json();
    if(path==='/api/meta'&&data.clock_sync){appClock.accept(data.clock_sync,started,performance.now());setTimeout(()=>{if(!S.pinned&&S.date!==today())changeDate(today(),false);},0);}
    if (!res.ok || data.error) throw new Error(data.error || 'データを読み込めませんでした');
    return data;
    }catch(e){failed=true;throw e;}finally{end?.(failed);}
  }
  function toast(message) { $('toast').textContent=message;$('toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,4500); }
  function error(message='') { $('error-message').textContent=message;$('error-message').hidden=!message; }
  function age(epoch) { if (!epoch) return '時刻未取得'; const sec=Math.max(0,Math.round(appNow()/1000-epoch));return sec<60?`${sec}秒前`:`${Math.floor(sec/60)}分前`; }
  function stamp(epoch,label='更新') { return epoch?`<span class="position-age" data-age="${epoch}" data-age-label="${esc(label)}">${age(epoch)}${esc(label)}</span>`:''; }
  function distance(m) {return m>=1000?`${(m/1000).toFixed(1)} km`:`${m} m`;}
  function favoriteKey(f){return JSON.stringify([f.group_id,[...f.pole_ids].sort()]);}
  function selectedPoles(){return S.poleIds.length?S.poleIds:S.pole?[S.pole]:[];}
  function poleParams(ids=selectedPoles()){return ids.length>1?{pole_ids:JSON.stringify(ids)}:{pole_id:ids[0]||''};}
  function favoriteScope(f){return f.pole_ids.length?(f.labels.length?f.labels.join('・'):f.pole_ids.length+'か所ののりば'):'すべてののりば';}
  function favoriteCard(f,d=null,note=''){
    const preview=(d?.upcoming||[]).filter(b=>!['cancelled','skipped','deleted'].includes(b.status)).slice(0,2);
    return `<article class="stop-card" data-key="${esc(favoriteKey(f))}"><button data-action="favorite" data-favorite="${esc(favoriteKey(f))}"><span class="stop-name">★ ${esc(d?.name||f.name||f.group_id.split('@')[0])}</span><p class="stop-meta">${esc(favoriteScope(f))}</p>${note?`<p class="stop-meta">${esc(note)}</p>`:''}${preview.map(b=>`<p class="stop-preview">${esc(timeText(b))} ${esc(b.headsign)} ${b.source==='prediction'?'〔予測〕':'〔定刻〕'}</p>`).join('')}</button></article>`;
  }
  function saveFavorites() { try {localStorage.setItem('hiroshima_bus_favorites_v2',JSON.stringify(S.favorites));} catch {toast('お気に入りを保存できませんでした');renderHomeFavorites();return false;}renderHomeFavorites();return true; }
  function renderHomeFavorites(){patch($('home-favorites'),S.favorites.length?S.favorites.map(f=>favoriteCard(f)).join(''):'<div class="empty-state">バス停の☆を押すと登録できます。</div>');}
  function boardablePoles(){return (S.detail?.poles||[]).filter(p=>p.is_boardable!==false&&p.stop_no!=='降車');}
  function poleChoice(p,type,name,checked){const number=poleNumber(p.stop_no),label=poleOption(p),description=number?label.replace('［'+number+'］','').trim():label;return `<label class="pole-choice"><span class="pole-choice-number">${esc(number)}</span><span class="pole-choice-description">${esc(description||'乗車場所')}</span><input type="${type}" name="${name}" value="${esc(p.same_pole_id)}" ${checked?'checked':''} aria-label="${esc(label)}"></label>`;}
  function renderPoleTrigger(){
    const ids=selectedPoles(),selected=boardablePoles().filter(p=>ids.includes(p.same_pole_id));
    $('btn-pole-picker').disabled=!S.detail;
    $('btn-pole-picker').textContent=ids.length>1?`選択した${ids.length}か所ののりば　⌄`:ids.length?(selected.length?poleOption(selected[0]):'選択したのりば')+'　⌄':'すべてののりば　⌄';
  }
  function openPolePicker(){
    if(!S.detail)return;
    const ids=selectedPoles(),eligible=S.dest?S.detail.eligible_pole_ids:null;
    const choices=boardablePoles().filter(p=>!eligible||eligible.includes(p.same_pole_id)||ids.includes(p.same_pole_id));
    $('pole-picker-choices').innerHTML=`<label class="pole-choice"><span class="pole-choice-all">すべてののりば</span><input type="radio" name="stop-pole" value="" ${!ids.length?'checked':''}></label>`+(ids.length>1?`<label class="pole-choice"><span class="pole-choice-all">選択した${ids.length}か所ののりば</span><input type="radio" name="stop-pole" value="__saved__" checked></label>`:'')+choices.map(p=>poleChoice(p,'radio','stop-pole',ids.length===1&&ids[0]===p.same_pole_id)).join('');
    $('pole-picker-dialog').showModal();document.querySelector('#pole-picker-choices input:checked')?.focus();
  }
  function renderFavoriteEditor(){
    const saved=S.favorites.filter(f=>f.group_id===S.group);
    $('favorite-existing').innerHTML=saved.length?'<p>登録済み</p>'+saved.map(f=>`<div class="favorite-existing-row"><span>${esc(favoriteScope(f))}</span><button data-action="remove-favorite" data-favorite="${esc(favoriteKey(f))}" aria-label="${esc(favoriteScope(f))}のお気に入りを解除">解除</button></div>`).join(''):'';
    const custom=$('favorite-scope-poles').checked;$('favorite-pole-choices').hidden=!custom;
    $('btn-save-favorite').disabled=custom&&!document.querySelector('#favorite-pole-choices input:checked');
  }
  function openFavoriteEditor(){
    if(!S.detail)return;
    const ids=selectedPoles();$('favorite-stop-name').textContent=S.detail.name;
    $('favorite-scope-all').checked=!ids.length;$('favorite-scope-poles').checked=!!ids.length;
    $('favorite-pole-choices').innerHTML=boardablePoles().map(p=>poleChoice(p,'checkbox','favorite-pole',ids.includes(p.same_pole_id))).join('');
    renderFavoriteEditor();$('favorite-dialog').showModal();
  }
  function saveFavoriteSelection(){
    const ids=$('favorite-scope-poles').checked?[...document.querySelectorAll('#favorite-pole-choices input:checked')].map(i=>i.value).sort():[];
    if($('favorite-scope-poles').checked&&!ids.length)return;
    const f={group_id:S.group,name:S.detail.name,pole_ids:ids,labels:boardablePoles().filter(p=>ids.includes(p.same_pole_id)).map(p=>poleOption(p))};
    const index=S.favorites.findIndex(v=>favoriteKey(v)===favoriteKey(f));if(index>=0)S.favorites[index]=f;else S.favorites.unshift(f);
    if(!saveFavorites())return;$('favorite-dialog').close();renderDetail(S.detail);toast('お気に入りに登録しました');
  }

  // Preserve keyed nodes, focus, open details and the reader's scroll anchor.
  function morph(oldNode, newNode) {
    if (oldNode.nodeType!==newNode.nodeType || oldNode.nodeName!==newNode.nodeName) {oldNode.replaceWith(newNode);return;}
    if (oldNode.nodeType===Node.TEXT_NODE) {if(oldNode.data!==newNode.data)oldNode.data=newNode.data;return;}
    if (!(oldNode instanceof Element)) return;
    for(const a of [...oldNode.attributes]) if(!newNode.hasAttribute(a.name) && !(oldNode.tagName==='DETAILS'&&a.name==='open'))oldNode.removeAttribute(a.name);
    for(const a of [...newNode.attributes]) if(oldNode.getAttribute(a.name)!==a.value)oldNode.setAttribute(a.name,a.value);
    if(oldNode.tagName==='INPUT' && document.activeElement!==oldNode && oldNode.type!=='search') oldNode.value=newNode.value;
    if(oldNode.tagName==='INPUT' && oldNode.type==='checkbox')oldNode.checked=newNode.checked;
    const keyed=new Map([...oldNode.childNodes].filter(n=>n.nodeType===1 && n.dataset.key).map(n=>[n.dataset.key,n]));
    let cursor=oldNode.firstChild;
    for(const fresh of [...newNode.childNodes]) {
      let existing=fresh.nodeType===1 && fresh.dataset.key?keyed.get(fresh.dataset.key):cursor;
      if(existing && fresh.nodeType===1 && fresh.dataset.key && existing.dataset?.key!==fresh.dataset.key)existing=null;
      if(existing?.nodeType===1 && existing.dataset.key && !(fresh.nodeType===1&&fresh.dataset.key))existing=null;
      if(existing) {if(existing!==cursor)oldNode.insertBefore(existing,cursor);const after=existing.nextSibling;morph(existing,fresh);cursor=after;}
      else {oldNode.insertBefore(fresh,cursor);}
    }
    while(cursor){const next=cursor.nextSibling;cursor.remove();cursor=next;}
  }
  function patch(element,html) {
    if(!element || htmlCache.get(element)===html)return;
    const deck=element.id==='trip-timeline-list'?element:$('content-deck');
    const anchor=[...element.children].find(n=>n.dataset.key && n.getBoundingClientRect().top>=deck.getBoundingClientRect().top);
    const before=anchor?.getBoundingClientRect().top;const key=anchor?.dataset.key;
    const fresh=element.cloneNode(false);fresh.innerHTML=html;
    morph(element,fresh);htmlCache.set(element,html);
    if(key){const after=[...element.children].find(n=>n.dataset.key===key);if(after)deck.scrollTop+=after.getBoundingClientRect().top-before;}
  }
  function options(element, choices, value, placeholder) {
    const html=`<option value="">${esc(placeholder)}</option>`+choices.map(c=>`<option value="${esc(c.value)}">${esc(c.label)}</option>`).join('');
    if(element.dataset.options!==html){const focus=document.activeElement===element;patch(element,html);element.dataset.options=html;if(focus)element.focus({preventScroll:true});}
    element.value=value;
  }
  const itemKey = u => `${u.company}|${u.trip_id}|${u.service_date}|${u.stop_sequence}`;
  const tripAttrs = u => `data-company="${esc(u.company)}" data-trip-id="${esc(u.trip_id)}" data-date="${esc(u.service_date)}" data-stop-sequence="${esc(u.stop_sequence||'')}"`;
  function timeText(u) {return u.realtime_time || u.scheduled_time || '時刻未取得';}
  function delayText(u) {
    if(u.status==='cancelled')return '運休';
    if(u.status==='skipped')return 'この停留所には停車しません';
    if(u.departure_state==='waiting')return '出発待ち';
    if(!u.delay_known)return '時刻表のみ・運行状況未取得';
    const minutes=Math.abs(Math.round(u.delay_sec/60));
    return u.delay_sec>0?`${minutes<1?'1分未満':minutes+'分'}遅れ`:u.delay_sec<0?`${minutes<1?'1分未満':minutes+'分'}早い予測`:'遅延なしの予測';
  }
  function departureCard(u) {
    const inactive=['cancelled','skipped','deleted'].includes(u.status), predicted=u.source==='prediction';
    const departed=u.departure_confirmed===true;
    const status=departed?'発車済み':inactive?delayText(u):u.departure_state==='waiting'?'出発待ち':predicted?delayText(u):'予測なし';
    return `<article class="departure-card ${esc(u.status)} ${departed?'departed':''}" data-key="${esc(itemKey(u))}"><button class="departure-row" data-action="trip" ${tripAttrs(u)} style="${companyStyle(u.company)}" aria-label="${esc(timeText(u)+' '+u.headsign+' '+status)}"><span class="departure-time">${esc(timeText(u))}<small>${departed?esc(status):predicted?`${u.event_kind==='arrival'?'到着予測':'予定'} ${esc(u.scheduled_time)}`:'時刻表'}</small></span><span class="destination"><span class="route-badge">${esc(u.route_short_name||'—')}</span>${esc(u.headsign||'行先未取得')}<span class="departure-meta">${companyTag(u.company)}${esc(status)}${u.added?'・臨時':''}</span></span>${poleBadge(u.stop_no)}</button></article>`;
  }
  function poleNumber(value){const n=String(value||'').trim();return !n||/^(番号なし|なし|不明|[-—－])$/.test(n)?'':n;}
  function unnumberedPlace(group=S.group,name=''){return group==='広島バスセンター@HiroshimaArea'||name==='広島バスセンター'?'降車ホーム':'乗車場所';}
  function poleBadge(value){const n=poleNumber(value),place=unnumberedPlace();return n?`<span class="pole-label"><b>${esc(n)}</b>のりば</span>`:`<span class="pole-label unnumbered"><b>${place==='降車ホーム'?'降車<br>ホーム':'乗車<br>場所'}</b></span>`;}
  function poleOption(p){
    const n=poleNumber(p.stop_no);
    const clean=v=>{let s=String(v||'').trim().replace(/^(?:番号なし|番号無し)\s*(?:[\/／・:：]\s*)?/,'');if(n){const e=n.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');s=s.replace(new RegExp('^(?:[［\\[]'+e+'[］\\]]|'+e+'(?:\\s*(?:番)?のりば)?)(?:\\s+|[\\/／・:：]\\s*|$)'),'');}return s.trim();};
    const text=[...new Set((p.directions||[]).map(clean).map(v=>v.replace(/^[\/／・:：]\s*/, '')).filter(Boolean))].join('・');
    return `${n?'［'+n+'］':''}${text?' '+text:''}`.trim()||unnumberedPlace();
  }
  function scheduledFallback(row){
    if(row.departure_confirmed)return {...row,departed:true};
    return {...row,source:'schedule',realtime_source:'schedule',realtime_time:'',predicted_epoch:null,delay_sec:null,delay_min:null,delay_known:false,event_kind:'departure',status:['cancelled','skipped','deleted'].includes(row.status)?row.status:'scheduled',departed:false,elapsed:false,departure_confirmed:false};
  }
  function stableDepartures(d) {
    const context=[S.group,S.date,JSON.stringify(selectedPoles()),S.dest,d.service_date].join('|');
    const incoming=d.upcoming,index=new Map(incoming.map(v=>[itemKey(v),v])),passed=new Set(d.departed_keys||[]);
    if(S.rowContext!==context||!S.rows){S.rowContext=context;S.rows=incoming.map(v=>({...v}));}
    else S.rows=S.rows.map(old=>{
      const key=itemKey(old);
      if(passed.has(key)||old.departure_confirmed)return {...old,departed:true,departure_confirmed:true};
      if(index.has(key))return {...index.get(key),departed:false,departure_confirmed:false};
      return scheduledFallback(old);
    });
    S.pendingRows=incoming;
    const changed=S.rows.map(itemKey).join('\n')!==incoming.map(itemKey).join('\n');
    $('btn-apply-departures').hidden=!changed;
    const additions=incoming.filter(v=>!S.rows.some(r=>itemKey(r)===itemKey(v))).length;
    $('btn-apply-departures').textContent=`新しい発車一覧に切替${additions?' · '+additions+'件追加':''}`;
    if(S.touching||Date.now()<S.interactionUntil){S.rowPaintPending=true;return;}
    S.rowPaintPending=false;
    patch($('upcoming-bus-list'),S.rows.length?S.rows.map(departureCard).join(''):`<div class="empty-state">${esc(stateMessage(d))}</div>`);
  }
  function stopCard(g) {
    const preview=(g.next_buses||[]).filter(b=>!['cancelled','skipped','deleted'].includes(b.status)).slice(0,2);
    return `<article class="stop-card" data-key="${esc(g.group_id)}"><button data-action="stop" data-group="${esc(g.group_id)}"><span class="stop-name">${S.favorites.some(f=>f.group_id===g.group_id)?'★ ':''}${esc(g.name)}</span>${g.distance_m!==undefined?`<span class="stop-distance">${distance(g.distance_m)}</span>`:''}<p class="stop-meta">${esc(g.hira||g.kana||'')} ／ ${g.pole_count}のりば</p>${preview.map(b=>`<p class="stop-preview">${esc(timeText(b))} ${esc(b.headsign)} ${b.source==='prediction'?(b.event_kind==='arrival'?'〔到着予測〕':'〔発車予測〕'):'〔定刻〕'}</p>`).join('')}</button></article>`;
  }
  function stateMessage(detail) {
    if(detail.service_state==='out_of_range')return '選択日の時刻表データが有効期間外です。「設定 → 時刻表データ」から更新してください。';
    const expired=(detail.coverage||[]).filter(c=>!c.available);
    if(expired.length)return `${expired.map(c=>c.name).join('・')}の時刻表は有効期間外です。表示されない便があります。「設定 → 時刻表データ」から更新してください。`;
    if(detail.next_service_date)return `本日の掲載便は終了しました。${dateLabel(detail.next_service_date)}の始発便を表示しています。`;
    if(detail.service_state==='no_service')return 'この日・のりば・目的地に該当する掲載便はありません。条件や日付をご確認ください。';
    if(S.date!==today())return `${dateLabel(S.date)}の運行日データを表示中。リアルタイムの接近情報ではありません。`;
    return '位置情報を取得できない路線・便は定刻での表示を行っています。';
  }

  function initMap() {
    if(map||!window.L)return;
    map=L.map('transit-map',{zoomControl:false,minZoom:3,maxZoom:19,maxBounds:[[-85,-180],[85,180]],maxBoundsViscosity:1}).setView([S.center.lat,S.center.lon],16);
    L.control.zoom({position:'bottomright'}).addTo(map);
    markers=L.layerGroup().addTo(map);poles=L.layerGroup().addTo(map);vehiclesLayer=L.layerGroup().addTo(map);routeLayer=L.layerGroup().addTo(map);locationLayer=L.layerGroup().addTo(map);drawGPS();
    setTheme(document.documentElement.dataset.theme||'light');
    map.on('dragstart zoomstart',()=>{if(!suppressMap){S.follow=false;renderFollow();}});
    map.on('click',()=>{if(S.mapKind==='vehicles'&&S.selectedTrip)clearRadarSelection();});
    map.on('moveend',()=>{
      // Following is a camera update, not a new viewport search/render request.
      if(followPanning)return;
      renderMap();if(suppressMap)return;
      if(S.mapKind==='map')$('btn-search-this-area').hidden=false;
      else if(S.mapKind==='vehicles'){clearTimeout(areaTimer);areaTimer=setTimeout(()=>{const c=map.getCenter();S.center={lat:c.lat,lon:c.lng};S.revision++;refresh();},350);}
    });
  }
  function setTheme(theme) {
    $('map-theme-select').value=theme;$('transit-map').dataset.theme=theme;
    if(!map||S.mapTheme===theme)return;
    const style=new URL(`./map-styles/${theme==='dark'?'dark':'light'}.json`,document.baseURI).href;
    if(currentTile){S.mapTheme=theme;currentTile.getMaplibreMap().setStyle(style);return;}
    try{
      currentTile=L.maplibreGL({style,localIdeographFontFamily:'Yu Gothic, Meiryo, sans-serif',interactive:false}).addTo(map);
      S.mapTheme=theme;
      map.attributionControl.addAttribution('<a href="https://openfreemap.org/">OpenFreeMap</a> © <a href="https://openmaptiles.org/">OpenMapTiles</a> Data from <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>');
      const gl=currentTile.getMaplibreMap();
      gl.on('error',()=>{S.mapProblem='地図を取得できません。バス停名の検索は利用できます。';renderAnimationNotice();});
      gl.on('idle',()=>{S.mapProblem='';renderAnimationNotice();});
      gl.getCanvas().addEventListener('webglcontextlost',()=>{S.mapProblem='地図の描画が一時停止しています。';renderAnimationNotice();});
    }catch(e){currentTile=null;S.mapTheme=null;S.mapProblem='地図を描画できません。';renderAnimationNotice();}
  }
  function fly(lat,lon,zoom=17) {if(!map)return;S.center={lat,lon};suppressMap=true;map.setView([lat,lon],zoom);setTimeout(()=>suppressMap=false,200);}
  function clusters(items,size=64) {
    const parent=items.map((_,i)=>i),buckets=new Map(),points=[];
    const root=i=>{while(parent[i]!==i){parent[i]=parent[parent[i]];i=parent[i];}return i;};
    items.forEach((item,i)=>{
      const p=map.project([item.lat,item.lon],map.getZoom());points.push(p);
      const x=Math.floor(p.x/size),y=Math.floor(p.y/size);
      for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){
        for(const j of buckets.get(`${x+dx}:${y+dy}`)||[]){const q=points[j];if(Math.hypot(p.x-q.x,p.y-q.y)<size)parent[root(i)]=root(j);}
      }
      const key=`${x}:${y}`;if(!buckets.has(key))buckets.set(key,[]);buckets.get(key).push(i);
    });
    const groups=new Map();items.forEach((item,i)=>{const key=root(i);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(item);});
    return [...groups.values()];
  }
  function icon(html){return L.divIcon({className:'',html,iconSize:[48,48],iconAnchor:[24,24]});}
  function clusterMarker(list,layer,type) {
    const lat=list.reduce((s,v)=>s+v.lat,0)/list.length,lon=list.reduce((s,v)=>s+v.lon,0)/list.length;
    const unit=type==='バス'?'台':type==='バス停'?'か所':'か所';
    const marker=L.marker([lat,lon],{icon:icon(`<div class="map-cluster">${type} ${list.length}${unit} · 一覧</div>`),keyboard:true,title:`${type} ${list.length}${unit}の一覧`}).addTo(layer);
    marker.on('click',()=>showInfo(`${type}を選択`,list.map(v=>type==='バス停'?`<button data-action="stop" data-group="${esc(v.group_id)}">${esc(v.name)}</button>`:type==='のりば'?`<button data-action="pole" data-pole="${esc(v.same_pole_id)}">${esc(poleOption(v))}</button>`:`<button data-action="radar-select" ${tripAttrs(v)}>${companyTag(v.company)} ${esc(v.route_short_name)} ${esc(v.headsign)}方面</button>`).join('')));
  }
  function renderMap() {
    if(!map||!S.mapVisible)return;
    markers.clearLayers();poles.clearLayers();
    if(S.mapKind==='single'&&S.singleTrip){const target=tripFocusStop(S.singleTrip);if(target)L.marker([target.lat,target.lon],{title:target.stop_name,icon:icon(`<div class="map-marker"><span class="stop-dot"></span><span class="map-label">${esc(target.stop_name)}</span></div>`)}).addTo(markers);}
    const nearby=S.nearby.slice();if(S.detail&&!nearby.some(v=>v.group_id===S.group))nearby.push(S.detail);
    for(const list of clusters(S.mapKind==='stop'?(S.detail?[S.detail]:[]):S.mapKind==='map'?nearby:[],map.getZoom()<16?80:38)) {
      if(list.length>1){clusterMarker(list,markers,'バス停');continue;}
      const g=list[0];L.marker([g.lat,g.lon],{title:g.name,icon:icon(`<div class="map-marker ${S.group===g.group_id?'selected':''}"><span class="stop-dot"></span>${map.getZoom()>=16?`<span class="map-label">${esc(g.name)}</span>`:''}</div>`)}).on('click',()=>S.mapKind==='stop'?restoreStopScreen():openStop(g.group_id)).addTo(markers);
    }
    if(S.detail&&['map','stop'].includes(S.mapKind)){
      const ids=selectedPoles(),boardable=S.detail.poles.filter(p=>p.is_boardable!==false && p.stop_no!=='降車' && (!ids.length || ids.includes(p.same_pole_id)));
      for(const list of clusters(boardable,48)){
        if(list.length>1){clusterMarker(list,poles,'のりば');continue;}
        const p=list[0];L.marker([p.lat,p.lon],{title:poleOption(p),icon:icon(`<div class="map-marker ${S.pole===p.same_pole_id?'selected':''}"><span class="pole-dot">${esc(poleNumber(p.stop_no)||(unnumberedPlace()==='降車ホーム'?'降車ホーム':'乗車'))}</span></div>`)}).on('click',()=>selectPole(p.same_pole_id)).addTo(poles);
      }
    }
    const visibleVehicles=mapVehicles();
    motionLayoutAt=0;
    // Keep the relative stacking order independent of latitude and feed ordering.
    const ordered=[...visibleVehicles].sort((a,b)=>markerKey(a)<markerKey(b)?-1:markerKey(a)>markerKey(b)?1:0);
    const keep=new Set();
    for(const [index,v] of ordered.entries()){
      const key=markerKey(v);keep.add(key);
      const selected=S.selectedTrip && S.selectedTrip.company===v.company && S.selectedTrip.trip_id===v.trip_id;
      const compact=S.mapKind==='vehicles'&&!selected&&map.getZoom()<16;
      const micro=compact&&map.getZoom()<13;
      const direction=v.bearing===null||v.bearing===undefined?'●':`<span class="bus-arrow" style="transform:rotate(${v.bearing}deg)">▲</span>`;
      const html=`<div class="map-marker bus-marker ${compact?'compact':''} ${micro?'micro':''} ${selected?'selected':''} ${v.is_simulation?'simulation-marker':''} ${v.last_known?'last-known':''}"><span class="bus-pill" style="background:${esc(companyFill(v.company))}">${direction}${compact?'<svg class="bus-mini ui-icon" viewBox="0 0 24 24" aria-hidden="true"><use href="#icon-bus"/></svg>':routeMarkerLabel(v)}</span><span class="bus-simulation-tag" ${v.is_simulation?'':'hidden'}>推定</span>${v.last_known?`<span class="bus-delay">${stamp(v.position_updated_at,'の前回位置')}</span>`:''}</div>`;
      const title=`${v.route_short_name} ${v.headsign}方面・${v.is_simulation?simulationSource(v):'GPS取得位置（選択で取得時刻を確認）'}`;
      let entry=vehicleMarkers.get(key);
      if(!entry){const marker=L.marker([v.lat,v.lon],{icon:icon(html),title}).addTo(vehiclesLayer);entry={marker,html,value:v};marker.on('click',()=>selectRadar(entry.value));vehicleMarkers.set(key,entry);}
      else {const updated=!v.is_simulation&&entry.value.position_updated_at!==v.position_updated_at;entry.value=v;if(entry.html!==html){entry.marker.setIcon(icon(html));entry.html=html;}if(updated){const el=entry.marker.getElement();el?.classList.remove('gps-updated');requestAnimationFrame(()=>el?.classList.add('gps-updated'));}}
      const el=entry.marker.getElement();if(el&&el.title!==title)el.title=title;
      if(el){el.classList.add('bus-position-marker');el.style.setProperty('--bus-stack',String(selected?ordered.length+200:index+100));el.dataset.vehicleKey=key;}
      requestMotionPath(v);
    }
    for(const [key,entry] of vehicleMarkers)if(!keep.has(key)){vehiclesLayer.removeLayer(entry.marker);vehicleMarkers.delete(key);}
    const old=visibleVehicles.filter(v=>v.last_known).length;
    const loading=S.animation&&S.mapKind==='vehicles'?S.simulations.filter(v=>!motionPaths.has(motionKey(v))||motionQueue.some(j=>j.key===motionKey(v))).length:0;
    $('map-counts').textContent=S.mapKind==='stop'?`のりば ${S.detail?.poles.filter(p=>p.is_boardable!==false).length||0}か所`:S.mapKind==='map'?`バス停 ${nearby.length}か所`:S.animation?`推定 ${visibleVehicles.length}便${loading?' ／ 経路準備中':''}`:`GPS ${visibleVehicles.length}台${old?'（前回 '+old+'台）':''}`;
    paintVehicleMotion();startVehicleMotion();
    if(S.mapKind==='vehicles'&&S.animation)renderVehicles({vehicles:S.simulations,count:S.simulations.length});
  }
  function bounds() {if(!map)return undefined;const b=map.getBounds();return [b.getSouth(),b.getWest(),b.getNorth(),b.getEast()].join(',');}

  let wantedDemand=false,sentDemand=null,demandTask=null;
  function needsRealtime(){
    if(document.visibilityState!=='visible'||document.querySelector('dialog[open]'))return false;
    if(S.mapKind==='vehicles'||(S.mapKind==='single'&&(!S.selectedTrip?.service_date||S.selectedTrip.service_date<=today()))||(S.tab==='notices'&&!S.group))return true;
    return S.date===today()&&((S.group&&S.mode==='realtime'&&S.mapKind!=='stop')||!$('trip-timeline-modal').hidden);
  }
  function syncRealtimeDemand(){
    wantedDemand=!!needsRealtime();
    if(demandTask)return demandTask;
    if(sentDemand===wantedDemand)return Promise.resolve();
    demandTask=(async()=>{
      while(sentDemand!==wantedDemand){const value=wantedDemand;await api('/api/realtime/demand',{enabled:value?1:0});sentDemand=value;}
    })().finally(()=>{demandTask=null;});
    return demandTask;
  }
  async function refresh(force=false) {
    const demand=syncRealtimeDemand().catch(e=>error(e.message));
    if(S.refreshing){S.again=true;S.forceQueued=S.forceQueued||force;return S.refreshing;}
    const revision=S.revision,group=S.group,date=S.date;
    const endLoading=(force||!S.meta||revision!==S.renderedRevision)?BusBrandMotion.begin():null;let loadFailed=false;
    if(force){$('btn-manual-refresh').disabled=true;$('btn-manual-refresh').textContent='更新中…';}
    S.refreshing=(async()=>{
      try{
        await demand;
        if(force)await api('/api/refresh',{group_id:group,...poleParams()});
        const meta=await api('/api/meta',{group_id:group,...poleParams(),service_date:date,company:S.mapKind==='vehicles'?S.company:''});
        if(revision!==S.revision){S.again=true;return;}
        if(!force&&!group&&S.mapKind!=='single'&&!(S.mapKind==='vehicles'&&S.animation)&&S.renderedRevision===revision&&meta.realtime.generation===lastGeneration&&meta.data_update.updated_at===(S.dataState?.updated_at||0)){
          S.meta=meta;S.dataState=meta.data_update;error();renderMeta(meta);renderSourceStatus(meta);return;
        }
        const nearCenter=S.tab==='nearby'?S.gps:S.center;
        const requests=[
          nearCenter&&['nearby','map'].includes(S.tab)&&!group?api('/api/stops/nearby',{...nearCenter,service_date:date,radius:1200,limit:30}):Promise.resolve(null),
          S.mapKind==='vehicles'?(S.animation?api('/api/simulation/vehicles',{company:S.company}):api('/api/vehicles',{...S.center,bounds:bounds(),company:S.company})):Promise.resolve({vehicles:[],count:0}),
          group?api('/api/stops/detail',{group_id:group,...poleParams(),dest_group_id:S.dest,service_date:date}):Promise.resolve(null),
          group&&S.mode==='timetable'?api('/api/stops/timetable',{group_id:group,...poleParams(),service_date:date,route_filter:S.route}):Promise.resolve(null)];
        const [nearby,vehicles,detail,timetable]=await Promise.all(requests);
        if(revision!==S.revision){S.again=true;return;}
        error();S.meta=meta;S.dataState=meta.data_update;if(S.mapKind==='vehicles'&&S.animation)S.simulations=vehicles.vehicles;else S.vehicles=vehicles.vehicles;S.detail=detail;S.timetable=timetable;
        if(nearby){S.nearby=nearby.stops;renderNearby(nearby);}
        if(force&&detail)S.rows=null;
        renderMeta(meta);renderSourceStatus(meta);if(detail)renderDetail(detail);if(timetable)renderTimetable(timetable);
        renderVehicles(vehicles);renderMap();
        if(S.tab==='favorites'&&!group)await renderFavorites();
        if(S.mapKind==='single')await refreshSingle();
        if(S.selectedTrip&&!$('trip-timeline-modal').hidden&&meta.realtime.generation!==lastGeneration)await updateTrip();
        lastGeneration=meta.realtime.generation;
        S.renderedRevision=revision;
      }catch(e){loadFailed=true;if(group&&S.rows){S.rows=S.rows.map(scheduledFallback);patch($('upcoming-bus-list'),S.rows.map(departureCard).join(''));}error(e.message+'。保存済み表示の更新が止まっています。再度「更新」をお試しください。');}
      finally{endLoading?.(loadFailed);BusBrandMotion.ready();if(force){$('btn-manual-refresh').disabled=false;$('btn-manual-refresh').textContent='手動で更新';}S.refreshing=null;if(S.again){S.again=false;const queued=S.forceQueued;S.forceQueued=false;setTimeout(()=>refresh(queued),0);}}
    })();return S.refreshing;
  }
  function renderMeta(meta){
    S.policySeenAt=performance.now();
    renderUpdateStatus();
    const rt=meta.realtime;
    $('rt-status-text').dataset.state=rt.state;
    const working=rt.companies.filter(c=>['vehicles','trip_updates'].some(k=>['live','cached'].includes(c.feeds[k].state))).length;
    $('rt-status-text').textContent=rt.state==='loading'?'配信元から取得中…':rt.available?`取得可能 ${working}/13社 ／ 全域の実位置 ${rt.live_vehicle_count}台`:'運行情報を取得できません・時刻表を利用中';
    if(meta.realtime_policy&&!meta.realtime_policy.demanded)$('rt-status-text').textContent='運行情報の取得状況 · 自動取得は休止中';
    ingestNotices(meta.all_alerts||meta.alerts||[]);renderNotices();
    patch($('home-companies'),meta.companies.map(c=>companyTag(c.slug)).join(''));
    $('automatic-status').textContent=`取得 ${new Intl.DateTimeFormat('ja-JP',{timeZone:'Asia/Tokyo',hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(new Date(appNow()))}`;
    options($('map-company-filter'),meta.companies.map(c=>({value:c.slug,label:c.short})),S.company,'すべての事業者');
    options($('search-company'),meta.companies.map(c=>({value:c.slug,label:c.short})),S.searchCompany,'すべての事業者');
    if(!$('data-dialog').open)return;
    renderDataStatus(meta.data_update);
  }
  function renderNearby(data){
    $('nearby-count-badge').textContent=`${data.stops.length}か所`;
    if(S.tab==='nearby'){
      $('nearby-subtitle').textContent=S.gps?`現在地から1.2 km以内 · 距離は直線距離`:'現在地を取得してください';
      patch($('nearby-stops-list'),data.stops.length?data.stops.map(stopCard).join(''):'<div class="empty-state">現在地の近くに掲載されたバス停がありません。名前・地図からも探せます。</div>');
    }else patch($('map-stops-list'),data.stops.length?data.stops.map(stopCard).join(''):'<div class="empty-state">この範囲にバス停はありません。地図を動かして検索できます。</div>');
  }
  function renderDetail(d){
    $('btn-toggle-favorite').disabled=false;
    $('btn-stop-map').disabled=false;$('pole-select').disabled=false;$('dest-select').disabled=false;
    patch($('detail-companies'),d.companies.map(c=>companyTag(c)).join(''));
    $('detail-stop-name').textContent=d.name;$('detail-stop-sub').textContent=d.hira||d.kana||'';
    const favorite=S.favorites.some(f=>f.group_id===S.group&&JSON.stringify(f.pole_ids)===JSON.stringify([...selectedPoles()].sort()));$('btn-toggle-favorite').textContent=favorite?'★':'☆';$('btn-toggle-favorite').setAttribute('aria-pressed',String(favorite));$('btn-toggle-favorite').setAttribute('aria-label','お気に入りの登録・編集');
    options($('dest-select'),d.reachable_destinations.map(v=>({value:v.group_id,label:v.name})),S.dest,'すべての行き先');
    const destinations=S.dest?d.eligible_pole_ids:null;
    const boardable=d.poles.filter(p=>p.is_boardable!==false && p.stop_no!=='降車' && (!destinations||destinations.includes(p.same_pole_id)||p.same_pole_id===S.pole));
    options($('pole-select'),boardable.map(p=>({value:p.same_pole_id,label:poleOption(p)})),S.pole,'すべてののりば');
    renderPoleTrigger();
    $('service-notice').textContent=stateMessage(d);$('service-notice').classList.toggle('warning',d.service_state==='out_of_range'||(d.coverage||[]).some(c=>!c.available));
    stableDepartures(d);
    for(const b of document.querySelectorAll('.detail-mode-tab')){const active=b.dataset.detailMode===S.mode;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));}
    $('subview-realtime').hidden=S.mode!=='realtime';$('subview-timetable').hidden=S.mode!=='timetable';
    $('relevant-filter-label').hidden=true;
  }
  function renderTimetable(tt){
    options($('timetable-route-select'),tt.route_options.map(r=>({value:r.key,label:`${r.company_short} ${r.route_short_name} ${r.headsign}`})),S.route,'すべての系統・行き先');
    const out=tt.coverage.every(c=>!c.available);
    $('timetable-meta-summary').textContent=`${dateLabel(tt.service_date)}の実ダイヤ ／ ${tt.total_departures}便${out?' ／ 有効期間外：データを更新してください':''}`;
    const hour=Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Tokyo',hour:'2-digit',hourCycle:'h23'}).format(new Date(appNow())));
    patch($('timetable-grid-container'),tt.hourly_schedule.length?tt.hourly_schedule.map(row=>`<div class="hour-row ${S.date===today()&&row.hour===hour?'current-hour':''}" data-key="hour-${row.hour}" data-hour="${row.hour}"><div class="hour-label">${row.hour}<small>時</small></div><div class="hour-entries">${row.entries.map(e=>`<button class="tt-entry ${esc(e.status)}" data-key="${esc(itemKey(e))}" data-action="trip" ${tripAttrs(e)} aria-label="${esc(e.departure_time+' '+e.headsign+'方面 '+delayText(e))}"><span class="minute">${esc(e.minute)} <small>${esc(e.route_short_name)}</small></span><span>${esc(e.headsign)}</span>${['cancelled','skipped'].includes(e.status)?`<span>${esc(delayText(e))}</span>`:''}</button>`).join('')}</div></div>`).join(''):'<div class="empty-state">この条件の日付別時刻表はありません。日付・のりば・データの有効期間をご確認ください。</div>');
  }
  function renderVehicles(data){
    renderFreshness();
    if(S.animation&&S.mapKind==='vehicles'){
      const shown=S.visibleSimulations||[];
      $('vehicles-list-count').textContent=`推定 ${shown.length}便 ／ 全域候補 ${S.simulations.length}便`;
      $('previous-positions-label').hidden=true;
      $('vehicles-notice').textContent='時刻表・取得済み予測によるシミュレーションです。定刻の便は運行未確認です。近接記号は短い線で位置と結びます。';
      const missing=shown.filter(v=>v.route_unavailable).length;if(missing)$('vehicles-notice').textContent+=` 経路未取得の${missing}便は停留所位置で表示します。`;
      if($('active-vehicles-list').closest('details').open)patch($('active-vehicles-list'),shown.map(v=>`<article class="vehicle-card" data-key="${esc(motionKey(v))}"><div class="vehicle-heading">${companyTag(v.company)}<h3>${esc(v.route_short_name)} ${esc(v.headsign)}</h3></div><p>${esc(simulationSource(v))}</p><div class="card-actions"><button data-action="locate" ${tripAttrs(v)}>この便の地図</button><button data-action="trip" ${tripAttrs(v)}>停車順</button></div></article>`).join('')||'<div class="empty-state">この範囲に表示できる便はありません。経路の読み込み中は順次表示します。</div>');
      return;
    }
    const previous=data.vehicles.filter(v=>v.last_known).length;
    const shown=data.vehicles.filter(v=>S.showPrevious||!v.last_known);
    $('vehicles-list-count').textContent=`位置 ${data.count-previous}台${previous?' ／ 前回位置 '+previous+'台':''}`;
    $('previous-positions-label').hidden=previous===0;$('previous-positions-count').textContent=`前回位置も表示（${previous}台）`;
    $('vehicles-notice').textContent=previous?'更新を確認できない前回位置は通常表示から除外しています。必要な場合のみ表示でき、5分を超えた位置は消去します。':data.realtime?.available?'取得したGPS位置を基準に表示しています。推定表示と取得時刻をご確認ください。':'運行情報を取得できません。車両が運行していないことを意味しません。';
    $('vehicles-notice').textContent=previous?'薄い破線は前回位置です。最新の運行確認ではありません。5分を超える保存位置は消去します。':'取得時点のGPS位置です。車両ごとの測定時刻をご確認ください。';
    patch($('active-vehicles-list'),shown.length?shown.map(v=>`<article class="vehicle-card" data-key="${esc(v.company+'|'+v.vehicle_id)}"><div class="vehicle-heading"><span class="route-badge">${routeMarkerLabel(v)}</span><h3>${esc(v.headsign)}方面</h3></div><p>${companyTag(v.company)} ／ ${esc(v.segment)}</p><p>${stamp(v.position_updated_at,v.last_known?'の前回位置':'に取得したGPS')}${v.cached?'・再取得中':''}</p><div class="card-actions"><button data-action="locate" ${tripAttrs(v)}>地図で位置</button><button data-action="trip" ${tripAttrs(v)}>停車順</button></div></article>`).join(''):`<div class="empty-state">${previous?'新しい位置を確認できる車両がありません。「前回位置も表示」で保存位置を確認できます。':data.realtime?.available?'この表示範囲・条件では車両位置を取得していません。':'通信状況をご確認ください。保存済みの時刻表は利用できます。'}</div>`);
  }
  async function openStop(group,favorite=null){
    if($('info-dialog').open)$('info-dialog').close();
    S.returnTab=S.tab;S.group=group;S.detail=null;S.timetable=null;S.pole=favorite?.pole_ids.length===1?favorite.pole_ids[0]:'';S.poleIds=favorite?.pole_ids.length>1?[...favorite.pole_ids]:[];S.dest='';S.route='';S.mode='realtime';S.selectedTrip=null;S.singleVehicle=null;S.rows=null;S.revision++;
    $('btn-toggle-favorite').disabled=true;$('btn-stop-map').disabled=true;$('pole-select').disabled=true;$('dest-select').disabled=true;$('service-notice').textContent='';
    renderPoleTrigger();
    options($('pole-select'),[],'','すべてののりば');options($('dest-select'),[],'','すべての行き先');
    leaveMap();$('stop-detail-panel').hidden=false;$('main-tabs-container').hidden=true;$('content-deck').scrollTop=0;
    BusBrandMotion.page();$('detail-stop-name').textContent='停留所を取得中…';$('detail-stop-sub').textContent='';patch($('detail-companies'),'');
    patch($('upcoming-bus-list'),'<div class="empty-state">発車情報を取得しています。</div>');await refresh();
  }
  function closeStop(){S.group='';S.pole='';S.poleIds=[];S.dest='';S.detail=null;S.rows=null;S.selectedTrip=null;S.revision++;$('stop-detail-panel').hidden=true;$('main-tabs-container').hidden=false;switchTab(S.returnTab==='single'?'home':S.returnTab);}
  function selectPole(pole){if($('info-dialog').open)$('info-dialog').close();if(S.mapKind==='stop')restoreStopScreen();S.pole=pole;S.poleIds=[];S.route='';S.rows=null;S.revision++;refresh();}
  function switchTab(tab){
    $('trip-timeline-modal').hidden=true;
    S.group='';S.detail=null;S.rows=null;S.pole='';S.poleIds=[];S.dest='';S.selectedTrip=null;S.singleVehicle=null;S.tab=tab;S.revision++;
    $('stop-detail-panel').hidden=true;$('main-tabs-container').hidden=false;showTabPanel(tab);
    if(['map','vehicles'].includes(tab))enterMap(tab);else leaveMap();
    $('content-deck').scrollTop=0;if(tab==='search')runSearch();else refresh();
  }
  // Footer navigation suspends each workspace. In-screen Back still changes its stack.
  const workspaces=new Map();
  const workspaceKeys=['tab','group','pole','poleIds','dest','mode','route','date','pinned','detail','timetable','rows','rowContext','pendingRows','returnTab','stopScroll','selectedTrip','singleTrip','singleVehicle','singleReturn','company','search','kana','searchCompany','gps','nearby','searchResults'];
  function switchRoot(root){
    if(root===S.navRoot)return;
    rememberMap();
    const state=Object.fromEntries(workspaceKeys.map(k=>[k,S[k]]));
    workspaces.set(S.navRoot,{state,kind:S.mapKind,view:S.mapKind?S.mapViews[S.mapKind]:null,scroll:$('content-deck').scrollTop,follow:S.follow});
    leaveMap();$('trip-timeline-modal').hidden=true;
    const saved=workspaces.get(root);
    if(saved)Object.assign(S,saved.state);
    else Object.assign(S,{tab:root,group:'',pole:'',poleIds:[],dest:'',mode:'realtime',route:'',date:today(),pinned:false,detail:null,timetable:null,rows:null,rowContext:'',pendingRows:[],returnTab:root,stopScroll:0,selectedTrip:null,singleTrip:null,singleVehicle:null,singleReturn:null,company:'',search:'',kana:'',searchCompany:'',gps:null,nearby:[],searchResults:[]});
    S.navRoot=root;S.revision++;S.applyRequested=false;S.rowPaintPending=false;
    $('service-date').value=S.date;$('stop-search-input').value=S.search;$('search-company').value=S.searchCompany;
    document.querySelectorAll('[data-kana]').forEach(b=>b.classList.toggle('active',b.dataset.kana===S.kana));
    showTabPanel(S.tab);
    const stopVisible=!!S.group&&!saved?.kind;
    $('stop-detail-panel').hidden=!stopVisible;$('main-tabs-container').hidden=stopVisible;
    if(S.detail)renderDetail(S.detail);if(S.timetable)renderTimetable(S.timetable);
    if(saved?.kind){if(saved.view)S.mapViews[saved.kind]=saved.view;enterMap(saved.kind,saved.view);S.follow=saved.follow;renderFollow();if(saved.kind==='single'&&S.singleTrip){drawSingleRoute(S.singleTrip);renderSingle(S.singleVehicle);}}
    else if(root==='vehicles'&&!S.group)enterMap('vehicles');
    if(S.tab==='search')runSearch();
    const revision=S.revision,scroll=saved?.scroll||0;
    $('content-deck').scrollTop=scroll;
    refresh().finally(()=>{if(S.revision===revision)requestAnimationFrame(()=>{if(S.revision===revision)$('content-deck').scrollTop=scroll;});});
  }
  function showTabPanel(tab){
    BusBrandMotion.page();
    document.querySelectorAll('[id^="tab-panel-"]').forEach(el=>el.hidden=el.id!==`tab-panel-${tab}`);
    const nav=S.navRoot;
    document.querySelectorAll('.bottom-nav [data-tab]').forEach(b=>{const active=b.dataset.tab===nav;b.classList.toggle('active',active);if(active)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
    if(tab==='favorites')renderFavorites();
    if(tab==='notices'){renderNotices();$('notices-list').querySelectorAll('details').forEach(d=>d.open=false);}
  }
  function rememberMap(){if(map&&S.mapKind){const c=map.getCenter();S.mapViews[S.mapKind]={lat:c.lat,lon:c.lng,zoom:map.getZoom()};}}
  function leaveMap(){rememberMap();stopVehicleMotion();S.mapKind=null;S.follow=false;setMapVisible(false);$('app-shell').classList.remove('map-mode','single-mode');$('map-heading').hidden=true;$('map-toolbar').hidden=true;routeLayer?.clearLayers();}
  function enterMap(kind,initial){
    rememberMap();stopVehicleMotion();routeLayer?.clearLayers();S.mapEpoch=(S.mapEpoch||0)+1;const mapEpoch=S.mapEpoch;
    S.mapKind=kind;S.follow=false;S.tab=kind;if(['vehicles','single'].includes(kind))S.animation=S.positionModes[kind]!==false;
    $('app-shell').classList.add('map-mode');$('app-shell').classList.toggle('single-mode',kind==='single');
    $('map-heading').hidden=false;$('map-toolbar').hidden=false;$('btn-map-back').hidden=kind==='vehicles';
    $('map-title').textContent=kind==='stop'?S.detail?.name||'バス停の場所':kind==='map'?'地図から探す':kind==='single'?'この便のバス位置':'バス位置';
    $('map-eyebrow').textContent=kind==='stop'?'BUS STOP LOCATION':kind==='map'?'MAP SEARCH':kind==='single'?'SELECTED BUS':'LIVE BUS RADAR';
    $('map-subtitle').textContent=kind==='stop'?'乗車場所の位置を確認':kind==='map'?'バス停・のりばを選択':kind==='single'?'選んだ便だけを表示':'地図を眺める・バスを選ぶ';
    const busToolbar=['vehicles','single'].includes(kind);
    $('map-toolbar').classList.toggle('bus-toolbar',busToolbar);$('map-counts').hidden=busToolbar;
    $('map-company-filter').hidden=kind!=='vehicles';$('btn-search-this-area').hidden=true;$('btn-follow').hidden=['map','stop'].includes(kind);$('btn-map-gps').hidden=!busToolbar;$('position-mode-control').hidden=!busToolbar;renderFollow();renderAnimationNotice();
    setMapVisible(true);applyRadarDisplay();const v=['single','stop'].includes(kind)?initial:S.mapViews[kind]||initial;
    setTimeout(()=>{if(S.mapKind!==kind||S.mapEpoch!==mapEpoch)return;map?.invalidateSize();if(v?.fitTrip)fitSingleTrip(v.fitTrip);else if(v)fly(v.lat,v.lon,v.zoom??16);renderMap();if(kind==='vehicles'){S.revision++;refresh();}},50);
  }
  async function runSearch(){
    const query=S.search,company=S.searchCompany,kana=S.kana;
    try{const d=await api('/api/stops/search',{q:query,company,kana_row:kana},true);if(query!==S.search||company!==S.searchCompany||kana!==S.kana)return;S.searchResults=d.stops;$('search-result-count').textContent=`${d.total}か所${d.total>d.stops.length?'（先頭'+d.stops.length+'件を表示）':''}`;patch($('search-results-list'),d.stops.length?d.stops.map(stopCard).join(''):'<div class="empty-state">該当する停留所がありません。別の読み方や条件でお試しください。</div>');}catch(e){toast(e.message);}
  }
  let favoriteTask=null,favoriteRequest=0,favoriteContext='',favoriteUpdated=0;
  const favoriteCards=new Map();
  function renderFavorites(){
    const date=S.date,ids=[...S.favorites],context=JSON.stringify([date,ids]);
    const paint=()=>{if(context!==JSON.stringify([S.date,S.favorites]))return;patch($('favorites-stops-list'),ids.length?ids.map(f=>favoriteCards.get(favoriteKey(f))||favoriteCard(f,null,'時刻を取得中…')).join(''):'<div class="empty-state">バス停の☆を押すと登録できます。</div>');};
    if(context!==favoriteContext){favoriteContext=context;favoriteCards.clear();favoriteUpdated=0;favoriteTask=null;favoriteRequest++;}
    paint();
    if(favoriteTask||Date.now()-favoriteUpdated<5000)return favoriteTask||Promise.resolve();
    const request=++favoriteRequest;
    favoriteTask=Promise.all(ids.map(async f=>{
      let html;try{html=favoriteCard(f,await api('/api/stops/detail',{group_id:f.group_id,...poleParams(f.pole_ids),service_date:date,summary:1}));}
      catch{html=favoriteCard(f,null,'時刻を取得できませんでした。タップして確認');}
      if(request!==favoriteRequest)return;favoriteCards.set(favoriteKey(f),html);paint();
    })).finally(()=>{if(request===favoriteRequest){favoriteUpdated=Date.now();favoriteTask=null;}});
    return favoriteTask;
  }
  function tripValue(button){return {company:button.dataset.company,trip_id:button.dataset.tripId,service_date:button.dataset.date||S.date,stop_sequence:button.dataset.stopSequence||''};}
  function tripFocusStop(trip){return trip.stops.find(s=>s.is_highlighted&&s.lat!=null&&s.lon!=null)||trip.stops.find(s=>s.lat!=null&&s.lon!=null);}
  function drawSingleRoute(trip){if(S.mapKind!=='single'||trip!==S.singleTrip)return;routeLayer?.clearLayers();if(map&&trip.geometry_source==='gtfs_shape'&&trip.polyline.length>1){L.polyline(trip.polyline,{color:document.documentElement.dataset.theme==='dark'?'#b6c6da':'#fff',weight:7,opacity:.7,interactive:false}).addTo(routeLayer);L.polyline(trip.polyline,{color:trip.company==='geiyo'?'#0D1B2A':palette[trip.company]||trip.company_color,weight:4,opacity:.9,interactive:false}).addTo(routeLayer);}}
  function fitSingleTrip(trip){
    if(!map)return;const target=tripFocusStop(trip),points=[];
    if(target)points.push([target.lat,target.lon]);const v=S.animation&&trip.simulation?simulationVehicle(trip.simulation,true):trip.vehicle;if(v)points.push([v.lat,v.lon]);
    if(!points.length)return;const size=map.getSize();suppressMap=true;
    map.fitBounds(L.latLngBounds(points),{padding:[size.x*.15,size.y*.15],maxZoom:17,animate:false});
    setTimeout(()=>suppressMap=false,60);
  }
  async function locate(v){
    if($('info-dialog').open)$('info-dialog').close();
    const revision=S.revision;
    let trip;try{trip=await api('/api/trips/detail',{company:v.company,trip_id:v.trip_id,service_date:v.service_date,highlight_group_id:S.group,highlight_sequence:v.stop_sequence},true);}catch(e){toast(e.message);return;}
    if(S.revision!==revision)return;
    if(!trip.vehicle&&!tripFocusStop(trip)){toast('この便の位置・停留所座標を取得できません。');return;}
    S.singleReturn=S.mapKind==='vehicles'?'vehicles':S.group?'stop':'home';
    if(S.group)S.stopScroll=$('content-deck').scrollTop;
    S.selectedTrip=v;S.singleVehicle=trip.vehicle;S.singleTrip=trip;$('trip-timeline-modal').hidden=true;
    if(trip.simulation_profile)motionPaths.set(motionKey(v),BusRouteMotion.profile(trip.simulation_profile.points,trip.simulation_profile.stops));
    $('stop-detail-panel').hidden=true;$('main-tabs-container').hidden=false;showTabPanel('single');
    const zoom=S.mapViews.single?.zoom??map?.getZoom()??16;
    enterMap('single',{fitTrip:trip,zoom});drawSingleRoute(trip);S.revision++;renderSingle(trip.vehicle);refresh();
  }
  async function refreshSingle(){
    const v=S.selectedTrip;if(!v)return;
    const epoch=S.mapEpoch;
    try{const trip=await api('/api/trips/detail',{company:v.company,trip_id:v.trip_id,service_date:v.service_date,highlight_group_id:S.group,highlight_sequence:v.stop_sequence});if(S.mapKind!=='single'||S.selectedTrip!==v||S.mapEpoch!==epoch)return;S.singleTrip=trip;S.singleVehicle=trip.vehicle;if(trip.simulation_profile&&S.pwaProfileRevision!==motionKey(v)+'|'+trip.simulation_profile.signature){motionPaths.set(motionKey(v),BusRouteMotion.profile(trip.simulation_profile.points,trip.simulation_profile.stops));S.pwaProfileRevision=motionKey(v)+'|'+trip.simulation_profile.signature;}drawSingleRoute(trip);renderSingle(trip.vehicle);renderMap();}catch(e){if(S.mapKind!=='single'||S.selectedTrip!==v||S.mapEpoch!==epoch)return;if(S.singleVehicle&&appNow()/1000-S.singleVehicle.position_updated_at<=300)S.singleVehicle={...S.singleVehicle,last_known:true,cached:true};else S.singleVehicle=null;renderSingle(S.singleVehicle);renderMap();}
  }
  function renderSingle(v){
    if(S.animation&&S.singleTrip){const trip=S.singleTrip,sim=trip.simulation;patch($('selected-bus-summary'),`${companyTag(trip.company)}<strong>${esc(trip.route_short_name)} ${esc(trip.headsign)} 行き</strong>${sim?esc(simulationSource(sim)):'シミュレーション用の運行時刻を特定できません。GPS位置へ切り替えて確認できます。'}<span id="single-simulation-phase"></span>`);return;}
    patch($('selected-bus-summary'),v?`${companyTag(v.company)}<strong>${esc(v.route_short_name)} ${esc(v.headsign)} 行き</strong>${stamp(v.position_updated_at,v.last_known?'の前回位置':'に取得したGPS')} ${v.last_known?'・最新位置を確認中':v.cached?'・再取得中':''}`:`<strong>${S.singleTrip?.departure_state==='waiting'?'出発待ち':'現在位置は未取得です'}</strong>停留所と${S.singleTrip?.geometry_source?'経路':'乗車場所'}を表示しています。`);
  }
  async function openTrip(v){lastFocus=document.activeElement;if($('info-dialog').open)$('info-dialog').close();S.selectedTrip=v;S.timelineFocusPending=true;$('trip-modal-title').textContent='停車順を取得中…';$('trip-modal-note').textContent='';$('btn-locate-trip').disabled=true;patch($('trip-timeline-list'),'');$('trip-timeline-modal').hidden=false;$('btn-close-trip-modal').focus();await updateTrip();}
  function focusTimeline(waiting){
    const list=$('trip-timeline-list'),selected=list.querySelector('.is-highlighted'),current=waiting?null:list.querySelector('.current');
    const target=selected||current||list.firstElementChild;if(!target)return;
    const top=n=>n.getBoundingClientRect().top-list.getBoundingClientRect().top+list.scrollTop;
    let start=top(target),end=start+target.offsetHeight;
    if(current&&selected){const a=Math.min(start,top(current)),b=Math.max(end,top(current)+current.offsetHeight);if(b-a<=list.clientHeight-16){start=a;end=b;}}
    list.scrollTop=Math.max(0,(start+end-list.clientHeight)/2);
  }
  async function updateTrip(){
    const v=S.selectedTrip;if(!v)return;
    try{const trip=await api('/api/trips/detail',{company:v.company,trip_id:v.trip_id,service_date:v.service_date,highlight_group_id:S.group,highlight_sequence:v.stop_sequence},!!S.timelineFocusPending);if(S.selectedTrip!==v)return;
      $('trip-modal-company').innerHTML=companyTag(trip.company)+` <span class="route-badge" style="${companyStyle(trip.company)}">${esc(trip.route_short_name)}</span>`;$('trip-modal-title').textContent=`${trip.headsign}方面`;
      const position=trip.timeline_position;
      $('trip-modal-note').textContent=(trip.departure_state==='waiting'?'出発待ち ／ ':'')+(trip.vehicle||position?`${trip.vehicle?age(trip.vehicle.position_updated_at)+(trip.vehicle.last_known?'の前回位置':'のGPS'):'配信位置'} ／ ${position?.source==='gps_nearest'?'橙：最寄り（目安）':position?'橙：バス位置':'停車順との対応は未特定'} ／ 緑：選択停留所`:'GPS未取得です。地図では停留所・経路を確認できます。緑は選択停留所です');
      $('btn-locate-trip').disabled=!trip.vehicle&&!tripFocusStop(trip);
      patch($('trip-timeline-list'),trip.stops.map(s=>`<div class="timeline-stop-row ${esc(s.position_status)} ${esc(s.status)} ${s.is_highlighted?'is-highlighted':''}" data-key="${esc(itemKey(s))}"><div>${esc(s.stop_name)}${s.is_highlighted?'〔選択中〕':''}<small>${esc(poleNumber(s.stop_no)?'［'+poleNumber(s.stop_no)+'］ のりば':unnumberedPlace(s.group_id||'',s.stop_name))}${s.position_status==='current'?` <span class="current-position">${trip.vehicle?.last_known?'前回位置':'バス位置'}</span> <span class="position-explanation">${esc(s.position_label||'配信で示された停留所')}</span>`:''}${s.position_status==='passed'?' ／ 通過済み':s.position_status==='estimated_passed'?' ／ 位置からの通過目安':''}${s.status==='cancelled'?' ／ 運休':s.status==='skipped'?' ／ 通過':''}</small></div><div class="timeline-time"><span>${esc(timeText(s))}</span><small>${s.departure_state==='waiting'?'出発待ち':s.source==='prediction'?(s.event_kind==='arrival'?'到着予測':'発車予測'):'定刻'}</small></div></div>`).join(''));
      if(S.timelineFocusPending){S.timelineFocusPending=false;requestAnimationFrame(()=>focusTimeline(trip.departure_state==='waiting'));}
      // Stop sequence is textual; do not draw a stop-to-stop straight line as a driving route.
    }catch(e){$('trip-modal-note').textContent=e.message;}
  }
  function closeTrip(){if(S.mapKind!=='single')S.selectedTrip=null;$('trip-timeline-modal').hidden=true;routeLayer?.clearLayers();if(lastFocus?.isConnected)lastFocus.focus({preventScroll:true});}
  function showInfo(title,html){$('info-title').textContent=title;patch($('info-body'),html);if(!$('info-dialog').open)$('info-dialog').showModal();}
  function showStatuses(){
    if(window.BusLocalAPI&&S.meta?.realtime.source==='offline'){showInfo('運行情報の取得状況','<p>定刻時刻表モードです。「リアルタイム情報の取得先」でCloudflareの中継URLと認証トークンを設定すると、発車予測・運行案内を取得できます。</p>');return;}
    if(!S.meta)return;
    const rt=S.meta.realtime,d=rt.relay_diagnostics||{};
    const reasons={RelayNetworkError:'中継への通信に失敗',RelayUnauthorized:'認証が一致しません（HTTP 401）',RelayUnavailable:'中継が停止中・収集待ち・期限切れです（HTTP 503）',RelayBundleError:'中継データの形式が不正',RelayExpired:'中継データの期限切れ・端末時計との差異',RelayFeedMissing:'中継にこのデータがありません',RelayMetadataError:'中継の取得時刻情報が不正',RelayFeedExpired:'配信元からの取得時刻が期限外',FeedParseError:'GTFSデータの読み取りに失敗',FeedTimestampError:'配信データの時刻が古いか不正',Expired:'最終取得情報の有効期限切れ',FetchError:'通信に失敗'};
    const source=`<p>取得先：${rt.source==='relay'?'Cloudflare経由':'直接取得'}</p>${S.meta.realtime_policy&&!S.meta.realtime_policy.demanded?'<p>自動取得は休止中です。バス位置・当日の発車案内・お知らせを開くと必要に応じて取得します。</p>':''}`;
    const diagnostic=rt.source==='relay'?`<p>${d.bytes?`中継受信：${esc(d.bytes)} bytes ／ 読み取り成功 ${esc(d.parsed_feeds??0)}/39種類`:'中継データ未受信'}${d.bundle_age_seconds!==undefined?` ／ 保存から約${esc(d.bundle_age_seconds)}秒`:''}</p>${d.error?`<p>${esc(reasons[d.error]||d.error)}</p>`:''}`:'';
    const clock=appClock.status(),clockDetail=clock.synchronized?`時刻同期済み ／ 端末との差 ${clock.device_offset_seconds>=0?'+':''}${clock.device_offset_seconds.toFixed(1)}秒 ／ 誤差目安±${Math.max(1,Math.ceil(clock.uncertainty_seconds))}秒`:'中継時刻は未同期です。端末時計を使用しています。';
    const receipt=`<p>${esc(clockDetail)}</p>${d.collected_at?`<p>中継保存：${timeStage(d.collected_at)}</p>`:''}${d.device_received_at?`<p>端末確認：${timeStage(d.device_received_at)}</p>`:''}`;
    showInfo('事業者別の取得状況',source+receipt+diagnostic+rt.companies.map(c=>`<div class="info-item"><strong>${esc(c.short)}</strong>${Object.entries(c.feeds).map(([k,f])=>`<p>${({vehicles:'車両位置',trip_updates:'発車予測',alerts:'運行案内'})[k]}：${({live:'取得済み',cached:'再取得中・最終成功情報',last_known:'前回位置（最新確認中）',unavailable:'取得できません',loading:'取得中'})[f.state]}<br>配信生成：${timeStage(f.updated_at)}${f.received_at?`<br>${rt.source==='relay'?'中継':'端末'}取得：${timeStage(f.received_at)}`:''}${f.error?`<br><small>${esc(reasons[f.error]||'取得できません')}</small>`:''}</p>`).join('')}</div>`).join(''));
  }
  function showAlerts(){switchRoot('notices');}

  function renderDataStatus(d){
    if(!d)return;
    S.dataState=d;$('data-update-message').textContent=d.message;$('data-saved-at').textContent=d.updated_at?'保存データ更新：'+new Date(d.updated_at*1000).toLocaleString('ja-JP',{timeZone:'Asia/Tokyo'}):'同梱の時刻表データを使用しています';
    const busy=['checking','updating'].includes(d.state);
    if(busy&&!dataLoadEnd)dataLoadEnd=BusBrandMotion.begin();
    if(!busy&&dataLoadEnd){dataLoadEnd(d.state==='error');dataLoadEnd=null;}
    $('data-progress').hidden=!busy;$('data-progress').value=d.progress||0;$('btn-update-data').disabled=busy;$('btn-check-data').disabled=busy;
    const coverage=S.meta?.coverage||[];patch($('coverage-list'),coverage.map(c=>`<div class="coverage-row" data-key="${esc(c.company)}"><strong>${esc(c.name)}</strong><span>${esc(c.start||'不明')} 〜 ${esc(c.end||'不明')}${!c.available?' ／ 選択日は有効期間外':''}</span><span>版：${esc(c.version||'記載なし')}</span></div>`).join(''));
    if(d.updated_at && d.updated_at!==lastDataUpdated){lastDataUpdated=d.updated_at;motionPaths.clear();motionModels.clear();motionFailures.clear();S.nearby=[];S.revision++;refresh();}
    if(busy&&!dataTimer)dataTimer=setTimeout(pollData,1200);
  }
  async function pollData(){dataTimer=null;try{const d=await api('/api/data/status');renderDataStatus(d);}catch(e){dataLoadEnd?.(true);dataLoadEnd=null;toast(e.message);}}
  function setMapVisible(value){S.mapVisible=value;$('map-section').classList.toggle('collapsed',!value);if(value){initMap();setTimeout(()=>{map?.invalidateSize();renderMap();},30);}}

  function changeDate(date,pinned=true){if(!date)return;S.date=date;S.pinned=pinned;S.route='';S.rows=null;S.revision++;$('service-date').value=date;refresh();}
  function tomorrow(){const d=new Date(today()+'T12:00:00+09:00');d.setUTCDate(d.getUTCDate()+1);return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tokyo',year:'numeric',month:'2-digit',day:'2-digit'}).format(d);}
  function nearCurrentHour(){const hour=Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Tokyo',hour:'2-digit',hourCycle:'h23'}).format(new Date(appNow())));const elements=[...document.querySelectorAll('.hour-row')];const target=elements.find(e=>Number(e.dataset.hour)>=hour)||elements[0];target?.scrollIntoView({block:'start'});}

  // Shared operator palette: white text in both appearance modes.
  const palette={hiroden:'#1B7F3B',hirobus:'#D32F2F',hiroko:'#E65100',geiyo:'#1565C0',bihoku:'#0075C9',bonbus:'#2CB693',forble:'#E60012',jrbus:'#1565C0',sasaki:'#C18A26',kure:'#4AA9DB',hatsukaichi:'#E57994',onomichi:'#009E96',asahi:'#1E3A8A'};
  const names={hiroden:'広電バス',hirobus:'広島バス',hiroko:'広島交通',geiyo:'芸陽バス',bihoku:'備北交通',bonbus:'ボン・バス',forble:'フォーブル',jrbus:'JRバス中国',sasaki:'ささき観光',kure:'呉市生活',hatsukaichi:'廿日市バス',onomichi:'おのみち',asahi:'朝日交通'};
  function companyFill(id){return id==='geiyo'?'linear-gradient(to right,#D32F2F 50%,#1565C0 50%) bottom / 100% 3px no-repeat, #0D1B2A':palette[id]||'#526475';}
  function companyStyle(id){return `--company:${palette[id]||'#526475'};--company-fill:${companyFill(id)}`;}
  function companyTag(id){return `<span class="company-tag" data-company="${esc(id)}" style="${companyStyle(id)}">${esc(names[id]||id)}</span>`;}
  function saveLocal(key,value){try{localStorage.setItem(key,JSON.stringify(value));}catch{toast('設定を端末に保存できませんでした');}}

  // Theme choices are persisted separately from data-refresh operations.
  const themeKey='hiroshima_bus_appearance_v3',osAppearance=matchMedia('(prefers-color-scheme: dark)');
  const themeNames={light:'ライト',dark:'ダーク',auto:'AUTO',schedule:'時間設定'};
  let appearance=stored(themeKey,{mode:'auto',light:'07:00',dark:'18:00'});
  const validTime=v=>typeof v==='string'&&/^([01]\d|2[0-3]):[0-5]\d$/.test(v);
  if(!appearance||!themeNames[appearance.mode]||!validTime(appearance.light)||!validTime(appearance.dark)||appearance.light===appearance.dark)appearance={mode:'auto',light:'07:00',dark:'18:00'};
  function applyAppTheme(){
    let theme=appearance.mode;
    if(theme==='auto')theme=osAppearance.matches?'dark':'light';
    if(theme==='schedule'){
      const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Tokyo',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date(appNow())).split(':');
      const minute=Number(parts[0])*60+Number(parts[1]),toMinute=v=>Number(v.slice(0,2))*60+Number(v.slice(3));
      const light=toMinute(appearance.light),dark=toMinute(appearance.dark);
      theme=(light<dark?minute>=light&&minute<dark:minute>=light||minute<dark)?'light':'dark';
    }
    document.documentElement.dataset.theme=theme;setTheme(theme);
    try{window.BusBrand?.appearance(JSON.stringify(appearance));}catch{}
    $('theme-summary').textContent=themeNames[appearance.mode]+(appearance.mode==='schedule'?` · ライト ${appearance.light} / ダーク ${appearance.dark}`:'');
  }
  osAppearance.addEventListener('change',()=>{if(appearance.mode==='auto')applyAppTheme();});
  setInterval(applyAppTheme,15000);
  function openSettings(){document.querySelectorAll('dialog[open]').forEach(d=>d.close());$('settings-dialog').showModal();}
  function openSettingsChild(id){document.querySelectorAll('dialog[open]').forEach(d=>d.close());$(id).showModal();}
  $('btn-settings').onclick=openSettings;
  function renderSourceStatus(meta){
    const rt=meta.realtime;
    if(window.BusLocalAPI&&rt.source==='offline'){$('realtime-source-summary').textContent='PWA：定刻時刻表';$('rt-status-text').textContent='定刻時刻表モード';return;}
    $('realtime-source-summary').textContent=rt.source==='relay'?'Cloudflare経由（中継API）':'直接取得（配信元へ接続）';
    if(rt.source_error)error(rt.source_error);
  }
  let sourceSettings=null;
  const sourceFields=()=>{$('realtime-relay-fields').hidden=$('realtime-mode').value!=='relay';};
  $('realtime-mode').onchange=sourceFields;
  $('btn-open-realtime').onclick=async()=>{
    try{
      sourceSettings=await api('/api/realtime/settings');
      $('realtime-mode').value=sourceSettings.mode;$('realtime-url').value=sourceSettings.url;
      $('realtime-token').value='';$('realtime-token-note').textContent=sourceSettings.token_saved?'トークンは保存済みです。変更しない場合は空欄のまま保存できます。':'Cloudflare側のCLIENT_TOKENと同じ値を入力してください。';
      $('realtime-settings-error').hidden=true;sourceFields();openSettingsChild('realtime-dialog');
    }catch(e){toast(e.message);}
  };
  function saveSource(values){
    if(window.BusLocalAPI)return window.BusLocalAPI.request('/api/realtime/settings',{config:values});
    if(window.BusSettings)return new Promise((resolve,reject)=>{
      window.busSettingsResult=data=>{delete window.busSettingsResult;data.error?reject(new Error(data.error)):resolve(data);};
      try{window.BusSettings.saveRealtimeSettings(JSON.stringify(values));}
      catch(e){delete window.busSettingsResult;reject(new Error('Android側で設定保存を開始できませんでした。アプリを再起動してお試しください。'));}
    });
    return fetch('/api/realtime/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(values),cache:'no-store'}).then(async res=>{
      const data=await res.json();if(!res.ok||data.error)throw new Error(data.error||'保存できませんでした');return data;
    });
  }
  $('btn-save-realtime').onclick=async()=>{
    const button=$('btn-save-realtime');button.disabled=true;$('realtime-settings-error').hidden=true;
    try{
      const values={mode:$('realtime-mode').value,url:$('realtime-url').value};
      if($('realtime-token').value)values.token=$('realtime-token').value;
      sourceSettings=await saveSource(values);$('realtime-token').value='';
      S.revision++;S.rows=null;S.vehicles=[];S.singleVehicle=null;lastGeneration=-1;closeTrip();
      if(map){vehiclesLayer?.clearLayers();vehicleMarkers.clear();}
      openSettings();toast('取得先を保存しました');await refresh();
    }catch(e){$('realtime-settings-error').textContent=e.message;$('realtime-settings-error').hidden=false;}
    finally{button.disabled=false;}
  };
  $('btn-open-theme').onclick=()=>{
    $('app-theme-mode').value=appearance.mode;$('theme-light-at').value=appearance.light;$('theme-dark-at').value=appearance.dark;
    $('theme-time-fields').hidden=appearance.mode!=='schedule';$('theme-error').hidden=true;openSettingsChild('theme-dialog');
  };
  $('app-theme-mode').onchange=e=>$('theme-time-fields').hidden=e.target.value!=='schedule';
  $('btn-save-theme').onclick=()=>{
    const mode=$('app-theme-mode').value,light=$('theme-light-at').value,dark=$('theme-dark-at').value;
    if(mode==='schedule'&&(!validTime(light)||!validTime(dark)||light===dark)){$('theme-error').textContent='開始時刻を入力し、ライトとダークに異なる時刻を指定してください。';$('theme-error').hidden=false;return;}
    const useTimes=validTime(light)&&validTime(dark)&&light!==dark;
    appearance={mode,light:useTimes?light:appearance.light,dark:useTimes?dark:appearance.dark};
    saveLocal(themeKey,appearance);applyAppTheme();openSettings();
  };
  const infoPages={
    disclaimer:['免責事項・ご利用にあたって','ひろしまバスナビは非公式アプリです。各バス事業者や「くるけん」の公式アプリではありません。','時刻表・車両位置・発車予測は配信された情報に基づきます。公開配信に掲載されていない臨時変更などは反映できないため、事業者の案内もご確認ください。','通信できない場合は、有効期限内の最終取得情報を取得時刻付きで表示します。期限が切れた場合は時刻表のみを表示します。'],
    privacy:['プライバシー','現在地は「位置情報で探す」や地図の「現在地」を押して許可した場合にのみ取得し、端末内で近隣バス停の検索に使います。','お気に入り、表示設定、既読のお知らせは端末内に保存します。アカウント登録、広告、アクセス解析、開発者への位置履歴送信はありません。','地図の表示領域のタイル番号やIPアドレス等が地図配信元へ伝わります。現在地付近を表示すると、そのおおよその地域が伝わります。運行情報・時刻表の取得でもIPアドレス等が配信元に伝わります。','バス停索引と、開いたバス停・便の時刻表を静的配信先から取得します。保存済みデータはオフラインで利用できます。設定した中継の認証トークンは端末内に保存します。端末による保存データの削除を完全には防げません。'],
    credits:['データ提供元・ライセンス','時刻表・運行情報：各バス事業者、GTFS配信サービス','地図：OpenFreeMap ／ © OpenMapTiles ／ OpenStreetMap。地図内にも帰属表示を掲載しています。','MapLibre GL JS：BSD-3-Clause ／ MapLibre GL Leaflet：ISC ／ Leaflet：BSD-2-Clause ／ Chaquopy：MIT ／ Python：PSF License ／ AndroidX WebKit：Apache-2.0'],
    about:['このアプリについて','ひろしまバスナビ　PWA検証版 0.3.0','広島のバス時刻表・車両位置を表示する非公式アプリです。']
  };
  function showAppInfo(kind){const p=infoPages[kind];if(!p)return;$('settings-dialog').close();showInfo(p[0],'<button data-settings-back>‹ 設定へ戻る</button>'+p.slice(1).map(v=>`<p>${esc(v)}</p>`).join('')+(kind==='credits'?'<p><a href="./about-android.html#licenses">提供元・ライセンスの詳細</a></p>':''));}

  // Content identity excludes delivery IDs, changing route selectors and rolling active periods.
  const noticeText=v=>String(v||'').normalize('NFKC').replace(/[\u200b\u200c\u200d\ufeff]/g,'').trim().replace(/\s+/g,' ');
  const noticeKey=a=>JSON.stringify(['notice-v5',a.company||a.company_name,...['header','description'].map(k=>noticeText(a[k])),String(a.url||'').trim()]);
  const noticeVersion=noticeKey;
  function noticeTargets(a){
    const targets=Array.isArray(a.targets)?a.targets:[];
    return targets.length?targets:[{labels:[(a.informed_entity||[]).some(e=>e.route_id||e.stop_id||e.trip?.trip_id)?'対象：詳細を照合できていません':'対象路線・便：配信に詳細の指定なし'],unresolved:true}];
  }
  function noticeTripCount(a){return new Set(noticeTargets(a).filter(t=>t.trip).map(t=>t.trip_key||JSON.stringify(t.labels))).size;}
  function noticeContext(a){
    const targets=noticeTargets(a),count=noticeTripCount(a);
    const rows=targets.map(t=>`<li>${t.labels.map(line=>`<span>${esc(line)}</span>`).join('')}</li>`);
    const instant=epoch=>{const date=new Date(Number(epoch)*1000);return epoch&&Number.isFinite(date.getTime())?new Intl.DateTimeFormat('ja-JP',{timeZone:'Asia/Tokyo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(date):'';};
    const periods=[...new Set((a.active_period||[]).map(p=>{const start=instant(p.start),end=instant(p.end);return start||end?`${start||'開始の指定なし'} ～ ${end||'終了の指定なし'}`:'';}).filter(Boolean))];
    const unknownNote=a.effect===1||/運休/.test(a.header||'')?'詳細を特定できない対象があります。事業者全体の運休を示すものではありません。':'対象の詳細は配信元の案内をご確認ください。';
    return `<div class="notice-context"><p class="notice-target-title">${count?'対象便 '+count+'便':'対象情報'}<small>保存済み時刻表で名称を照合</small></p><ul>${rows.slice(0,4).join('')}</ul>${rows.length>4?`<details class="notice-target-more"><summary>ほか ${rows.length-4}件の対象を表示</summary><ul>${rows.slice(4).join('')}</ul></details>`:''}${targets.some(t=>t.unresolved)?`<p class="notice-context-note">${esc(unknownNote)}</p>`:''}<p class="notice-period">配信上の適用期間：${periods.length?periods.map(esc).join('<br>'):'指定なし'}</p></div>`;
  }
  function ingestNotices(alerts){
    const read=new Set(S.readNotices),archive=new Map();
    for(const old of S.notices){const key=noticeKey(old),v={...old,key,version:noticeVersion(old)};if(read.has(old.key)||read.has(old.version))read.add(v.version);if(!archive.has(key)||(old.seenAt||0)>(archive.get(key).seenAt||0))archive.set(key,v);}
    const current=new Map();
    for(const alert of alerts){const key=noticeKey(alert),prior=current.get(key),targets=[...new Map([...(prior?.targets||[]),...(alert.targets||[])].map(t=>[JSON.stringify(t),t])).values()];current.set(key,{...alert,key,targets,seenAt:Date.now(),active_period:[...(prior?.active_period||[]),...(alert.active_period||[])],informed_entity:[...(prior?.informed_entity||[]),...(alert.informed_entity||[])]});}
    S.activeNotices=[...current.values()].map(a=>({...a,version:noticeVersion(a)}));
    for(const a of S.activeNotices)archive.set(a.key,a);
    S.notices=[...archive.values()].filter(a=>Date.now()-(a.seenAt||0)<30*86400000).sort((a,b)=>a.seenAt-b.seenAt).slice(-100);
    const versions=new Set(S.notices.map(a=>a.version));S.readNotices=[...read].filter(v=>versions.has(v));
    saveLocal('hiroshima_bus_notices_v3',S.notices);saveLocal('hiroshima_bus_read_notices_v3',S.readNotices);
  }
  function renderNotices(){
    const active=S.activeNotices||[],unread=active.filter(a=>!S.readNotices.includes(a.version)),read=active.filter(a=>S.readNotices.includes(a.version));
    const firstCount=unread.length?noticeTripCount(unread[0]):0;
    $('alert-button').hidden=!unread.length;$('alert-summary').textContent=unread.length?`未読 ${unread.length}件：${unread[0].header||unread[0].description}${firstCount?' ／ 対象'+firstCount+'便':''}`:'';
    const card=a=>`<article class="info-item" data-key="${esc(a.key)}"><strong>${esc(a.company_name||names[a.company]||'')}：${esc(a.header||'運行案内')}</strong><p>${esc(a.description)}</p>${noticeContext(a)}${a.url?.startsWith('https://')?`<a href="${esc(a.url)}">配信元の案内を開く</a>`:''}<label class="check-label"><input type="checkbox" data-notice-key="${esc(a.version)}" ${S.readNotices.includes(a.version)?'checked':''}>内容を確認した（既読）</label></article>`;
    const keys=new Set(active.map(a=>a.key)),history=S.notices.filter(a=>!keys.has(a.key)).reverse();
    patch($('notices-list'),`<p class="notice-count" role="status">現在の案内 ${active.length}件（未読 ${unread.length}件・既読 ${read.length}件）</p>`+
      (unread.length?unread.map(card).join(''):`<p class="empty-state">${active.length?'未読のお知らせはありません。':'現在取得できている案内はありません。'}</p>`)+
      (read.length?`<details class="notice-history notice-read" data-key="read"><summary>既読のお知らせ ${read.length}件</summary>${read.map(card).join('')}</details>`:'')+
      (history.length?`<details class="notice-history" data-key="history"><summary>過去の案内 ${history.length}件</summary>${history.map(card).join('')}</details>`:''));
  }
  document.addEventListener('change',e=>{if(e.target.dataset.noticeKey!==undefined){const key=e.target.dataset.noticeKey;S.readNotices=S.readNotices.filter(k=>k!==key);if(e.target.checked)S.readNotices.push(key);saveLocal('hiroshima_bus_read_notices_v3',S.readNotices);renderNotices();}});

  function locateGPS(){
    S.gps=null;const endLoading=BusBrandMotion.begin();
    switchTab('nearby');patch($('nearby-stops-list'),'<div class="empty-state">現在地を取得中…</div>');
    if(!navigator.geolocation){endLoading(true);patch($('nearby-stops-list'),'<div class="empty-state">位置情報に対応していません。名前・地図から探せます。</div>');return;}
    navigator.geolocation.getCurrentPosition(async p=>{
      try{S.gps={lat:p.coords.latitude,lon:p.coords.longitude,accuracy:p.coords.accuracy};if(S.tab!=='nearby')return;S.revision++;toast(`現在地の精度：約${Math.round(p.coords.accuracy)} m`);await refresh();}
      finally{endLoading(false);}
    },()=>{endLoading(true);if(S.tab==='nearby')patch($('nearby-stops-list'),'<div class="empty-state">現在地を取得できません。位置情報の許可を確認するか、名前・地図から探してください。</div>');},{enableHighAccuracy:true,timeout:15000,maximumAge:30000});
  }
  function restoreStopScreen(){leaveMap();S.tab=S.returnTab;$('stop-detail-panel').hidden=false;$('main-tabs-container').hidden=true;$('content-deck').scrollTop=S.stopScroll||0;S.revision++;refresh();}
  $('btn-stop-map').onclick=()=>{
    if(!S.detail){toast('バス停の場所を取得中です');return;}
    S.stopScroll=$('content-deck').scrollTop;
    const d=S.detail;$('stop-detail-panel').hidden=true;$('main-tabs-container').hidden=false;showTabPanel('map');
    enterMap('stop',{lat:d.lat,lon:d.lon,zoom:S.mapViews.stop?.zoom||17});
  };
  function drawGPS(){
    if(!locationLayer)return;locationLayer.clearLayers();if(!S.gps)return;
    const point=[S.gps.lat,S.gps.lon];
    if(Number.isFinite(S.gps.accuracy)&&S.gps.accuracy>0)L.circle(point,{radius:S.gps.accuracy,color:'#167bd9',weight:1,fillOpacity:.08,interactive:false}).addTo(locationLayer);
    L.circleMarker(point,{radius:7,color:'#fff',weight:3,fillColor:'#167bd9',fillOpacity:1}).bindTooltip('現在地').addTo(locationLayer);
  }
  $('btn-map-gps').onclick=()=>{
    if(!navigator.geolocation){toast('位置情報に対応していません');return;}
    const kind=S.mapKind,button=$('btn-map-gps');button.disabled=true;
    navigator.geolocation.getCurrentPosition(p=>{
      button.disabled=false;S.gps={lat:p.coords.latitude,lon:p.coords.longitude,accuracy:p.coords.accuracy};drawGPS();
      if(S.mapKind!==kind)return;S.follow=false;renderFollow();fly(S.gps.lat,S.gps.lon,map.getZoom());S.revision++;refresh();toast(`現在地の精度：約${Math.round(p.coords.accuracy)} m`);
    },()=>{button.disabled=false;toast('現在地を取得できません。位置情報の許可を確認してください。');},{enableHighAccuracy:true,timeout:15000,maximumAge:15000});
  };
  const motionModels=new Map();
  const markerKey=v=>v.is_simulation?'sim|'+motionKey(v):`${v.company}|${v.vehicle_id||v.trip_id}`;
  const unnumberedBusIcon='<svg class="bus-mini ui-icon" viewBox="0 0 24 24" role="img" aria-label="系統番号なし"><use href="#icon-bus"/></svg>';
  function routeMarkerLabel(v){return String(v.route_short_name||'').trim()?esc(v.route_short_name):unnumberedBusIcon;}
  function simulationSource(v){return v.simulation_source==='prediction'?'発車予測で補正した推定位置':v.simulation_source==='last_prediction'?'前回の発車予測で補正した推定位置':'定刻シミュレーション・運行未確認';}
  function timeStage(epoch){return epoch?`${esc(new Date(epoch*1000).toLocaleTimeString('ja-JP',{timeZone:'Asia/Tokyo',hour12:false}))} ${stamp(epoch)}`:'未提供';}
  function informationTimes(v){
    const feed=v.is_simulation?v.prediction_feed_generated_at:v.feed_generated_at;
    const measured=v.is_simulation?v.prediction_updated_at:v.position_updated_at;
    const source=v.is_simulation?v.prediction_time_source:v.position_time_source;
    const received=v.is_simulation?v.prediction_received_at:v.relay_received_at;
    return `${measured&&source!=='feed'?`<p>${v.is_simulation?'予測の基準測定':'GPS測定'}：${timeStage(measured)}</p>`:''}${feed?`<p>配信生成：${timeStage(feed)}</p>`:''}${received?`<p>${S.meta?.realtime.source==='relay'?'中継':'端末'}取得：${timeStage(received)}</p>`:''}${S.meta?.realtime.relay_diagnostics?.device_received_at?`<p>端末確認：${timeStage(S.meta.realtime.relay_diagnostics.device_received_at)}</p>`:''}`;
  }
  function simulationVehicle(v,single=false){const p=motionPosition(v,appNow()/1000,single);return p?{...v,lat:p.point[0],lon:p.point[1],route_unavailable:p.routeUnavailable}:null;}
  function mapVehicles(){
    if(!['single','vehicles'].includes(S.mapKind))return [];
    if(!S.animation)return S.mapKind==='single'?(S.singleVehicle?[S.singleVehicle]:[]):S.vehicles.filter(v=>S.showPrevious||!v.last_known);
    const candidates=S.mapKind==='single'?(S.singleTrip?.simulation?[S.singleTrip.simulation]:[]):S.simulations;
    const box=map.getBounds(),now=appNow()/1000;
    const shown=[];
    for(const v of candidates){
      requestMotionPath(v);const p=motionPosition(v,now,S.mapKind==='single');if(!p)continue;
      if(S.mapKind==='vehicles'&&(p.opacity<=0||!box.contains(p.point)))continue;
      shown.push({...v,lat:p.point[0],lon:p.point[1],route_unavailable:p.routeUnavailable});
    }
    if(S.mapKind==='vehicles')S.visibleSimulations=shown;
    return shown;
  }
  function motionPosition(v,now,single=S.mapKind==='single'){
    if(!v.is_simulation)return {point:[v.lat,v.lon],simulated:false,opacity:1};
    const key=motionKey(v),data=motionPaths.get(key);
    const correction=S.mapKind==='vehicles'?radarDisplay.correction:'8',duration=Number(correction);
    const signature=(v.timing_key||'schedule')+'|'+correction;
    let cached=motionModels.get(key);
    if(!cached||cached.signature!==signature||cached.data!==data){
      const model=BusRouteMotion.clockPlan(data,v.timing);
      const samePath=cached?.data===data;
      cached={signature,data,model,correctionFrom:samePath?cached?.lastAlong:undefined,lastAlong:samePath?cached?.lastAlong:undefined,lastAt:samePath?cached?.lastAt:undefined,correctionAt:now};motionModels.set(key,cached);
      while(motionModels.size>1536)motionModels.delete(motionModels.keys().next().value);
    }
    const p=BusRouteMotion.clockPosition(cached.model,now,single);if(!p)return null;
    if(!p.routeUnavailable&&correction==='forward'){
      p.along=BusRouteMotion.forwardCorrection(cached.lastAlong,p.along,now-(cached.lastAt??now));p.point=BusRouteMotion.at(cached.model.route,p.along);
    }else if(!p.routeUnavailable&&Number.isFinite(cached.correctionFrom)&&now-cached.correctionAt<duration){
      const t=Math.max(0,Math.min(1,(now-cached.correctionAt)/duration)),ease=t*t*(3-2*t);
      p.along=cached.correctionFrom+(p.along-cached.correctionFrom)*ease;p.point=BusRouteMotion.at(cached.model.route,p.along);
    }
    cached.lastAlong=p.along;cached.lastAt=now;return p;
  }
  function paintVehicleMotion(){
    if(!map||!S.mapVisible||document.visibilityState!=='visible')return;
    const now=appNow()/1000;
    for(const entry of vehicleMarkers.values()){
      const v=entry.value,p=motionPosition(v,now);if(!p)continue;
      if(!entry.point||Math.abs(entry.point[0]-p.point[0])+Math.abs(entry.point[1]-p.point[1])>1e-9){entry.marker.setLatLng(p.point);entry.point=p.point;}
      if(entry.opacity!==p.opacity){entry.marker.setOpacity(p.opacity);entry.opacity=p.opacity;}
      const label=entry.marker.getElement()?.querySelector('.bus-simulation-tag');if(label)label.hidden=!p.simulated;
      if(S.mapKind==='single'&&v.is_simulation){const el=$('single-simulation-phase');if(el)el.textContent=' ／ '+({waiting:'出発待ち',running:'走行中（推定）',dwell:'停車中（推定）',arrived:'終点到着（推定）'}[p.phase]||'')+(p.routeUnavailable?' ／ 経路未取得・停留所位置の目安':'')+((v.prediction_feed_generated_at||v.prediction_updated_at)?' ／ 基準配信 '+age(v.prediction_feed_generated_at||v.prediction_updated_at):'');}
      if(S.follow&&S.selectedTrip?.company===v.company&&S.selectedTrip?.trip_id===v.trip_id)followVehicle({lat:p.point[0],lon:p.point[1]});
    }
    if(performance.now()>=motionLayoutAt){layoutCompactVehicles();motionLayoutAt=performance.now()+(vehicleMarkers.size>200?750:250);}
  }
  function layoutCompactVehicles(){
    const compact=[];
    for(const [key,entry] of vehicleMarkers){
      const el=entry.marker.getElement()?.querySelector('.bus-marker');if(!el)continue;
      el.classList.remove('offset-marker');el.style.setProperty('--shift-x','0px');el.style.setProperty('--shift-y','0px');
      if(entry.value.is_simulation&&el.classList.contains('compact')&&!el.classList.contains('micro')){const p=entry.marker.getLatLng();compact.push({lat:p.lat,lon:p.lng,key,el});}
    }
    for(const group of clusters(compact,24)){
      if(group.length<2)continue;
      group.sort((a,b)=>a.key.localeCompare(b.key));
      group.forEach((p,i)=>{
        const angle=2*Math.PI*i/group.length,radius=Math.min(28,14+group.length*2),x=Math.cos(angle)*radius,y=Math.sin(angle)*radius;
        p.el.classList.add('offset-marker');p.el.style.setProperty('--shift-x',x.toFixed(1)+'px');p.el.style.setProperty('--shift-y',y.toFixed(1)+'px');
        p.el.style.setProperty('--leader-length',radius+'px');p.el.style.setProperty('--leader-angle',angle+'rad');
      });
    }
  }
  function startVehicleMotion(){
    if(motionFrame||!S.animation||!S.mapVisible||!['vehicles','single'].includes(S.mapKind)||document.visibilityState!=='visible'||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
    function frame(now){
      motionFrame=0;
      if(!S.animation||!S.mapVisible||document.visibilityState!=='visible')return;
      const interval=S.mapKind==='vehicles'&&radarDisplay.fps?1000/radarDisplay.fps:vehicleMarkers.size>400?100:vehicleMarkers.size>150?67:40;
      if(now-motionPaint>=interval){paintVehicleMotion();motionPaint=now;}
      motionFrame=requestAnimationFrame(frame);
    }
    motionFrame=requestAnimationFrame(frame);
  }
  function renderAnimationNotice(){
    $('btn-animation').setAttribute('aria-checked',String(S.animation));$('position-mode-control').classList.toggle('simulation-on',S.animation);
    $('map-update-status').hidden=!['vehicles','single'].includes(S.mapKind);
    $('map-position-note').textContent=['vehicles','single'].includes(S.mapKind)?S.animation?'ⓘ 運行シミュレーションです。時刻表・取得済み予測からの推定で、運行未確認の便を含みます':'ⓘ 取得時点のGPS位置です。車両ごとの測定時刻をご確認ください':'ⓘ バス停・のりばの場所を表示しています';
    if(S.mapProblem)$('map-position-note').textContent+=' ／ '+S.mapProblem;
    renderUpdateStatus();
  }
  function renderUpdateStatus(){
    if(!['vehicles','single'].includes(S.mapKind))return;
    const clock=appClock.status(),clockText=clock.synchronized?`時計：${clock.source==='cloudflare'?'中継同期済み':'HTTP時刻同期'}（誤差目安±${Math.max(1,Math.ceil(clock.uncertainty_seconds))}秒）`:'時計：端末設定（中継未同期）';
    const remaining=Math.max(0,Math.ceil((S.meta?.realtime_policy?.next_check_in_seconds||0)-(performance.now()-(S.policySeenAt??performance.now()))/1000));
    $('map-update-status').textContent=clockText+(S.animation?'':' ／ '+(remaining>3?`次回取得まで約${remaining}秒`:remaining?'まもなく取得':'更新を確認中…'));
  }
  function renderFreshness(){
    const values=S.animation?(S.visibleSimulations||[]):S.vehicles;
    const stamps=values.map(v=>S.animation?v.prediction_feed_generated_at||v.prediction_updated_at:v.position_updated_at).filter(v=>Number.isFinite(v)&&v>0);
    const ages=stamps.map(v=>Math.max(0,Math.round(appNow()/1000-v)));
    const text=ages.length?`${S.animation?'推定に使う予測配信':'位置情報'}：${Math.min(...ages)}${Math.max(...ages)>Math.min(...ages)?'〜'+Math.max(...ages):''}秒前`:'予測配信時刻を確認できません';
    const unconfirmed=S.animation?values.filter(v=>v.simulation_source==='schedule').length:0;
    $('vehicles-freshness').textContent='ⓘ '+text+(unconfirmed?` ／ 定刻のみ ${unconfirmed}便`:'');
  }
  function stopVehicleMotion(){cancelAnimationFrame(motionFrame);motionFrame=0;cancelAnimationFrame(followFrame);followFrame=0;followTarget=null;for(const job of motionQueue)motionPaths.delete(job.key);motionQueue.length=0;}
  function applyRadarDisplay(){
    // Only the global radar is limited; stop and individual-trip maps keep their full range.
    const minZoom=S.mapKind==='vehicles'&&!radarZoomUnlocked?16:3;
    if(map){map.setMinZoom(minZoom);if(map.getZoom()<minZoom){map.stop();map.setZoom(minZoom,{animate:false});}}
    $('radar-zoom-summary').textContent=radarZoomUnlocked?'ズーム制限解除中':'大型アイコンの範囲まで';
    $('radar-zoom-state').textContent=radarZoomUnlocked?'現在：ズーム制限解除中':'現在：大型アイコンの範囲まで';
    $('btn-toggle-radar-zoom').textContent=radarZoomUnlocked?'ズーム制限を戻す':'ズーム制限を解除';
    $('btn-toggle-radar-zoom').setAttribute('aria-pressed',String(radarZoomUnlocked));
  }
  $('btn-open-radar-display').onclick=()=>{applyRadarDisplay();openSettingsChild('radar-display-dialog');};
  $('btn-toggle-radar-zoom').onclick=()=>{
    radarZoomUnlocked=!radarZoomUnlocked;saveLocal(radarZoomKey,radarZoomUnlocked);applyRadarDisplay();
  };
  applyRadarDisplay();
  $('btn-animation').onclick=()=>{S.animation=!S.animation;S.positionModes[S.mapKind]=S.animation;saveLocal('hiroshima_bus_position_modes_v2',S.positionModes);stopVehicleMotion();S.revision++;renderAnimationNotice();if(S.mapKind==='single'){renderSingle(S.singleVehicle);if(S.singleTrip)fitSingleTrip(S.singleTrip);}renderMap();refresh();};
  $('show-previous-positions').onchange=e=>{S.showPrevious=e.target.checked;renderVehicles({vehicles:S.vehicles,count:S.vehicles.length,realtime:S.meta?.realtime});renderMap();};
  function followVehicle(v){
    if(!map||!S.follow||!S.mapVisible||!Number.isFinite(v.lat)||!Number.isFinite(v.lon))return;
    followTarget={lat:v.lat,lon:v.lon,epoch:S.mapEpoch};
    if(followFrame)return;
    // Coalesce requests and never pan synchronously from renderMap/moveend.
    followFrame=requestAnimationFrame(()=>{
      followFrame=0;const target=followTarget;followTarget=null;
      if(!target||!S.follow||!S.mapVisible||target.epoch!==S.mapEpoch)return;
      const point=[target.lat,target.lon],center=map.getSize().divideBy(2);
      // Leaflet rounds camera offsets to pixels. A metre-based threshold can
      // endlessly retry a subpixel offset, especially when zoomed out.
      if(map.latLngToContainerPoint(point).distanceTo(center)<2)return;
      const previousSuppress=suppressMap;followPanning=true;suppressMap=true;
      try{map.panTo(point,{animate:false});}finally{followPanning=false;suppressMap=previousSuppress;}
    });
  }
  function renderFollow(){$('btn-follow').textContent=S.follow?'追尾 ON':'追尾 OFF';$('btn-follow').setAttribute('aria-pressed',String(S.follow));}
  function selectRadar(v){
    if(S.mapKind==='vehicles'&&S.selectedTrip?.company===v.company&&S.selectedTrip?.trip_id===v.trip_id){clearRadarSelection();return;}
    if($('info-dialog').open)$('info-dialog').close();
    S.selectedTrip={company:v.company,trip_id:v.trip_id,service_date:v.service_date};renderMap();
    showInfo('選択したバス',companyTag(v.company)+`<h3>${esc(v.route_short_name)} ${esc(v.headsign)}方面</h3><p class="selected-route-name">路線名：${esc(v.route_long_name||'配信データに記載なし')}</p><p>${v.is_simulation?esc(simulationSource(v)):stamp(v.position_updated_at,'に取得したGPS')}</p>${informationTimes(v)}<button data-action="trip" ${tripAttrs(v)}>停車順・時刻</button><button data-action="follow">このバスを追尾</button>${S.mapKind==='vehicles'?'<button data-action="clear-radar-selection">選択を解除</button>':''}`);
  }
  function clearRadarSelection(){if(S.mapKind!=='vehicles')return;S.selectedTrip=null;S.follow=false;if($('info-dialog').open)$('info-dialog').close();renderFollow();renderMap();}
  $('btn-follow').onclick=()=>{if(!S.selectedTrip){toast('地図上のバスを選択してください');return;}S.follow=!S.follow;renderFollow();if(S.follow){const v=mapVehicles().find(v=>v.company===S.selectedTrip.company&&v.trip_id===S.selectedTrip.trip_id);if(v)followVehicle(v);}};
  $('btn-map-back').onclick=()=>{
    if(['single','stop'].includes(S.mapKind)&&S.group)restoreStopScreen();
    else switchTab(S.mapKind==='single'&&S.singleReturn==='vehicles'?'vehicles':'home');
  };
  function safeToChange(){return !S.touching&&Date.now()>=S.interactionUntil&&!$('upcoming-bus-list').contains(document.activeElement);}
  $('btn-apply-departures').onclick=()=>{S.applyRequested=true;tryApplyRows();};
  function tryApplyRows(){if(!S.applyRequested)return;if(!safeToChange()){setTimeout(tryApplyRows,200);return;}S.applyRequested=false;S.rows=S.pendingRows.map(v=>({...v}));if(S.detail)stableDepartures(S.detail);}
  $('content-deck').addEventListener('pointerdown',()=>{S.touching=true;S.interactionUntil=Date.now()+500;});
  document.addEventListener('pointerup',()=>{S.touching=false;S.interactionUntil=Date.now()+350;});
  document.addEventListener('pointercancel',()=>{S.touching=false;S.interactionUntil=Date.now()+350;});
  $('content-deck').addEventListener('scroll',()=>{S.interactionUntil=Date.now()+500;},{passive:true});
  setInterval(()=>{if(S.rowPaintPending&&safeToChange()&&S.detail)stableDepartures(S.detail);},600);
  window.busNavigateBack=()=>{if(['single','stop'].includes(S.mapKind)){$('btn-map-back').click();return true;}if(S.group){closeStop();return true;}if(S.navRoot!=='home'){switchRoot('home');return true;}if(S.tab!=='home'){switchTab('home');return true;}return false;};
  window.busHandleBack=()=>{const dialog=document.querySelector('dialog[open]');if(dialog){if(dialog.querySelector('[data-settings-back]'))openSettings();else dialog.close();return true;}if(!$('trip-timeline-modal').hidden){closeTrip();return true;}return window.busNavigateBack();};

  document.addEventListener('click',e=>{
    const button=e.target.closest('button');if(!button)return;
    if(button.hasAttribute('data-settings-back')){openSettings();return;}
    if(button.dataset.info){showAppInfo(button.dataset.info);return;}
    if(button.dataset.action==='follow'){$('info-dialog').close();S.follow=true;renderFollow();const v=mapVehicles().find(v=>v.company===S.selectedTrip?.company&&v.trip_id===S.selectedTrip?.trip_id);if(v)followVehicle(v);return;}
    if(button.dataset.closeDialog){$(button.dataset.closeDialog).close();return;}
    if(button.dataset.tab){if(button.closest('.bottom-nav'))switchRoot(button.dataset.tab);else switchTab(button.dataset.tab);return;}
    if(button.dataset.terminal){openStop(button.dataset.terminal);return;}
    const action=button.dataset.action;
    if(action==='favorite'){const f=S.favorites.find(f=>favoriteKey(f)===button.dataset.favorite);if(f)openStop(f.group_id,f);return;}
    if(action==='remove-favorite'){S.favorites=S.favorites.filter(f=>favoriteKey(f)!==button.dataset.favorite);saveFavorites();renderFavoriteEditor();if(S.detail)renderDetail(S.detail);return;}
    if(action==='clear-radar-selection'){clearRadarSelection();return;}
    if(action==='stop')openStop(button.dataset.group);
    if(action==='pole')selectPole(button.dataset.pole);
    if(action==='trip')openTrip(tripValue(button));
    if(action==='locate')locate(tripValue(button));
    if(action==='radar-select'){const v=mapVehicles().find(v=>v.company===button.dataset.company&&v.trip_id===button.dataset.tripId);if(v)selectRadar(v);}
    if(button.dataset.kana!==undefined){S.kana=button.dataset.kana;document.querySelectorAll('[data-kana]').forEach(b=>b.classList.toggle('active',b===button));runSearch();}
    if(button.dataset.detailMode){S.mode=button.dataset.detailMode;S.revision++;refresh().then(()=>{if(S.mode==='timetable')nearCurrentHour();});}
  });
  $('btn-today').onclick=()=>changeDate(today(),false);$('btn-tomorrow').onclick=()=>changeDate(tomorrow());$('service-date').onchange=e=>changeDate(e.target.value);
  $('btn-manual-refresh').onclick=()=>refresh(true);$('btn-close-stop-detail').onclick=closeStop;$('btn-close-trip-modal').onclick=closeTrip;
  $('btn-locate-trip').onclick=()=>{if(S.selectedTrip)locate(S.selectedTrip);};
  $('trip-timeline-modal').addEventListener('click',e=>{if(e.target===$('trip-timeline-modal'))closeTrip();});
  document.addEventListener('keydown',e=>{if(!$('trip-timeline-modal').hidden){if(e.key==='Escape'){e.preventDefault();closeTrip();}if(e.key==='Tab'){const focusables=[...$('trip-timeline-modal').querySelectorAll('button:not(:disabled),a[href]')];if(e.shiftKey&&document.activeElement===focusables[0]){e.preventDefault();focusables.at(-1).focus();}else if(!e.shiftKey&&document.activeElement===focusables.at(-1)){e.preventDefault();focusables[0].focus();}}}});
  $('dest-select').onchange=e=>{S.rows=null;S.dest=e.target.value;S.pole='';S.poleIds=[];S.route='';S.revision++;refresh();};$('pole-select').onchange=e=>selectPole(e.target.value);
  $('btn-pole-picker').onclick=openPolePicker;
  $('pole-picker-choices').onchange=e=>{if(e.target.type!=='radio')return;$('pole-picker-dialog').close();if(e.target.value!=='__saved__')selectPole(e.target.value);};
  $('favorite-dialog').onchange=renderFavoriteEditor;
  $('btn-save-favorite').onclick=saveFavoriteSelection;
  $('only-relevant').onchange=e=>{S.relevant=e.target.checked;S.revision++;refresh();};$('timetable-route-select').onchange=e=>{S.route=e.target.value;S.revision++;refresh();};
  $('map-company-filter').onchange=e=>{S.company=e.target.value;S.revision++;refresh();};
  $('active-vehicles-list').closest('details').addEventListener('toggle',()=>{if(S.mapKind==='vehicles')renderVehicles({vehicles:S.vehicles,count:S.vehicles.length,realtime:S.meta?.realtime});});
  $('search-company').onchange=e=>{S.searchCompany=e.target.value;runSearch();};
  let composing=false;$('stop-search-input').addEventListener('compositionstart',()=>composing=true);$('stop-search-input').addEventListener('compositionend',e=>{composing=false;S.search=e.target.value;runSearch();});
  $('stop-search-input').oninput=e=>{S.search=e.target.value;if(composing)return;clearTimeout(searchTimer);searchTimer=setTimeout(runSearch,250);};
  $('btn-search-this-area').onclick=()=>{const c=map.getCenter();S.center={lat:c.lat,lon:c.lng};$('btn-search-this-area').hidden=true;S.revision++;refresh();};
  $('btn-gps-locate').onclick=locateGPS;$('btn-gps-retry').onclick=locateGPS;
  $('btn-toggle-favorite').onclick=openFavoriteEditor;
  $('btn-current-hour').onclick=nearCurrentHour;$('rt-status-text').onclick=showStatuses;$('alert-button').onclick=showAlerts;
  $('btn-open-data').onclick=()=>{openSettingsChild('data-dialog');renderDataStatus(S.dataState);};
  $('btn-check-data').onclick=async()=>{try{renderDataStatus(await api('/api/data/update',{action:'check'},true));}catch(e){toast(e.message);}};
  $('btn-update-data').onclick=async()=>{try{renderDataStatus(await api('/api/data/update',{},true));}catch(e){toast(e.message);}};
  $('kana-buttons').innerHTML=['','あ','か','さ','た','な','は','ま','や','ら','わ'].map(k=>`<button data-kana="${k}" class="${!k?'active':''}" aria-label="${k?k+'行で絞る':'すべての読み'}">${k||'全'}</button>`).join('');
  function tick(){
    const now=appNow()/1000;
    let positionsChanged=false;
    S.vehicles=S.vehicles.filter(v=>{if(now-v.position_updated_at>300){positionsChanged=true;return false;}if(now-v.position_updated_at>120&&!v.last_known){v.last_known=true;positionsChanged=true;}return true;});
    if(S.singleVehicle&&now-S.singleVehicle.position_updated_at>300){S.singleVehicle=null;positionsChanged=true;}
    else if(S.singleVehicle&&now-S.singleVehicle.position_updated_at>120&&!S.singleVehicle.last_known){S.singleVehicle={...S.singleVehicle,last_known:true,cached:true};positionsChanged=true;}
    if(positionsChanged){if(S.mapKind==='single')renderSingle(S.singleVehicle);if(S.mapKind==='vehicles')renderVehicles({vehicles:S.vehicles,count:S.vehicles.length,realtime:S.meta?.realtime});renderMap();}
    if(!positionsChanged&&S.animation&&['vehicles','single'].includes(S.mapKind)&&document.visibilityState==='visible')renderMap();
    renderUpdateStatus();
    $('live-clock').textContent=new Intl.DateTimeFormat('ja-JP',{timeZone:'Asia/Tokyo',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date(appNow()));
    document.querySelectorAll('[data-age]').forEach(el=>el.textContent=age(Number(el.dataset.age))+(el.dataset.ageLabel||''));
    if(!S.pinned&&!S.group&&S.date!==today())changeDate(today(),false);
  }
  $('service-date').value=S.date;saveFavorites();applyAppTheme();tick();refresh();
  new MutationObserver(()=>{syncRealtimeDemand().catch(e=>error(e.message));}).observe(document.body,{subtree:true,attributes:true,attributeFilter:['open','hidden']});
  setInterval(tick,1000);
  setInterval(()=>{if(document.visibilityState==='visible'&&!S.refreshing)refresh();},10000);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState!=='visible')stopVehicleMotion();syncRealtimeDemand().catch(e=>error(e.message));if(document.visibilityState==='visible'){tick();applyAppTheme();S.revision++;refresh();}});
})();
