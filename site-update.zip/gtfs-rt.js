/* Small strict GTFS-Realtime decoder, matching the Android parser's fields. */
(() => {
 const text=b=>new TextDecoder().decode(b),number=n=>{const v=Number(n);if(!Number.isSafeInteger(v))throw Error('Unsafe protobuf integer');return v;};
 function* fields(bytes){let p=0;const vint=()=>{let n=0n;for(let i=0;i<10;i++){if(p>=bytes.length)throw Error('Truncated varint');const b=bytes[p++];if(i===9&&b>1)throw Error('Invalid varint');n|=BigInt(b&127)<<BigInt(i*7);if(!(b&128))return n;}throw Error('Invalid varint');};
  while(p<bytes.length){const tag=number(vint()),f=Math.floor(tag/8),w=tag%8;if(!f)throw Error('Invalid protobuf field');let v;if(w===0)v=vint();else if([1,2,5].includes(w)){const size=w===1?8:w===5?4:number(vint());if(size>bytes.length-p)throw Error('Truncated field');v=bytes.subarray(p,p+size);p+=size;}else throw Error('Unsupported protobuf wire');yield [f,w,v];}
 }
 const signed=(v,bits)=>number(BigInt.asIntN(bits,v));
 function message(bytes,spec){const o={};for(const [f,w,v] of fields(bytes)){const s=spec[f];if(!s)continue;const [name,kind,repeated]=s;const wire=kind==='text'||typeof kind==='function'?2:kind==='float'?5:0;if(w!==wire)throw Error('Unexpected protobuf wire');let value=kind==='text'?text(v):typeof kind==='function'?kind(v):kind==='float'?new DataView(v.buffer,v.byteOffset,4).getFloat32(0,true):kind==='s32'?signed(v,32):kind==='s64'?signed(v,64):number(v);if(repeated)(o[name]??=[]).push(value);else o[name]=value;}return o;}
 const trip=b=>message(b,{1:['trip_id','text'],2:['start_time','text'],3:['start_date','text'],4:['schedule_relationship','uint'],5:['route_id','text'],6:['direction_id','uint']});
 const vehicle=b=>message(b,{1:['id','text'],2:['label','text'],3:['license_plate','text']});
 const position=b=>message(b,{1:['latitude','float'],2:['longitude','float'],3:['bearing','float'],5:['speed','float']});
 const event=b=>message(b,{1:['delay','s32'],2:['time','s64'],3:['uncertainty','s32'],4:['scheduled_time','s64']});
 const stop=b=>message(b,{1:['stop_sequence','uint'],2:['arrival',event],3:['departure',event],4:['stop_id','text'],5:['schedule_relationship','uint']});
 const update=b=>({stop_time_updates:[],...message(b,{1:['trip',trip],2:['stop_time_updates',stop,true],3:['vehicle',vehicle],4:['timestamp','uint'],5:['delay','s32'],6:['trip_properties',v=>message(v,{1:['trip_id','text'],2:['start_date','text'],3:['start_time','text'],4:['shape_id','text'],5:['trip_headsign','text'],6:['trip_short_name','text']})]})});
 const vp=b=>message(b,{1:['trip',trip],2:['position',position],3:['current_stop_sequence','uint'],4:['current_status','uint'],5:['timestamp','uint'],7:['stop_id','text'],8:['vehicle',vehicle],9:['occupancy_status','uint']});
 const translated=b=>{const items=message(b,{1:['items',v=>message(v,{1:['text','text'],2:['language','text']}),true]}).items||[];return (items.find(t=>t.language?.startsWith('ja'))||items.find(t=>t.text)||{}).text||'';};
 const selector=b=>message(b,{1:['agency_id','text'],2:['route_id','text'],4:['trip',trip],5:['stop_id','text'],6:['direction_id','uint']});
 const alert=b=>({active_period:[],informed_entity:[],...message(b,{1:['active_period',v=>message(v,{1:['start','uint'],2:['end','uint']}),true],5:['informed_entity',selector,true],6:['cause','uint'],7:['effect','uint'],8:['url',translated],10:['header_text',translated],11:['description_text',translated]})});
 function parse(bytes){const raw=message(bytes,{1:['header',v=>message(v,{2:['incrementality','uint'],3:['timestamp','uint']})],2:['entities',v=>message(v,{1:['entity_id','text'],2:['deleted','uint'],3:['trip_updates',update],4:['vehicles',vp],5:['alerts',alert]}),true]});const result={timestamp:raw.header?.timestamp||0,incrementality:raw.header?.incrementality||0,vehicles:[],trip_updates:[],alerts:[],deleted:[]};if(!raw.header)throw Error('Missing GTFS header');for(const e of raw.entities||[]){if(e.deleted){result.deleted.push(e.entity_id||'');continue;}for(const kind of ['vehicles','trip_updates','alerts'])if(e[kind])result[kind].push({...e[kind],entity_id:e.entity_id||''});}return result;}
 globalThis.BusGTFS={parse};
})();
