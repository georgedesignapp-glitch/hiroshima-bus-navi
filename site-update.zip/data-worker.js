/* Browser-only timetable prototype. UI and realtime integration follow separately. */
let indexPromise, dbPromise;
const normalize=s=>String(s||'').normalize('NFKC').replace(/[ァ-ヶ]/g,c=>String.fromCharCode(c.charCodeAt(0)-96)).toLowerCase().replace(/\s/g,'');
function database(){return dbPromise||=new Promise((resolve,reject)=>{const r=indexedDB.open('hbn-pwa-data-prototype',1);r.onupgradeneeded=()=>r.result.createObjectStore('files');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function read(key){const db=await database();return new Promise((resolve,reject)=>{const t=db.transaction('files');const r=t.objectStore('files').get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function save(key,value){const db=await database();return new Promise((resolve,reject)=>{const t=db.transaction('files','readwrite');t.objectStore('files').put(value,key);t.oncomplete=resolve;t.onerror=()=>reject(t.error);});}
async function index(){return indexPromise||= (async()=>{try{const r=await fetch('./data/index.json',{cache:'no-cache'});if(!r.ok)throw Error('バス停索引を取得できません');const value=await r.json();if(value.schema!==1)throw Error('未対応のデータ形式です');await save('index',value);return value;}catch(error){const old=await read('index');if(old)return old;throw error;}})();}
const inflight=new Map();
async function rows(group){const key=group.file+'|'+group.revision;if(inflight.has(key))return inflight.get(key);const job=(async()=>{let value=await read(key);if(value)return value;const r=await fetch('./data/'+group.file).catch(()=>{throw Error('時刻表を取得できません。未保存のバス停は通信が必要です');});if(!r.ok)throw Error('時刻表を取得できません。未保存のバス停は通信が必要です');const raw=await r.arrayBuffer();const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',raw))].map(v=>v.toString(16).padStart(2,'0')).join('');if(hash!==group.revision)throw Error('時刻表の版が一致しません。索引を更新して再度お試しください');value=JSON.parse(new TextDecoder().decode(raw));await save(key,value);return value;})();inflight.set(key,job);try{return await job;}finally{inflight.delete(key);}}
importScripts('./gtfs-rt.js','./rt-model.js','./relay-client.js','./trip-support.js','./operations-descriptor.js','./api-worker.js');
self.onmessage=async({data:request})=>{try{if(request.type==='api'){const started=performance.now(),result=await handleLocalAPI(request.path,request.values);if(request.path==='/api/meta')result.clock_sync=relay.clock(relay.now()-(performance.now()-started));self.postMessage({id:request.id,result});return;}const source=await index();let result;
if(request.type==='search'){const q=normalize(request.query);result=source.groups.filter(g=>!q||[g.name,g.hira,g.kana].some(v=>normalize(v).includes(q))).slice(0,80);}
else if(request.type==='departures'){
if(!/^\d{4}-\d{2}-\d{2}$/.test(request.date))throw Error('運行日を指定してください');
const group=source.groups.find(g=>g.group_id===request.group_id);if(!group)throw Error('バス停が見つかりません');
const table=await rows(group),at=Object.fromEntries(table.columns.map((c,i)=>[c,i]));
const active=new Set(Object.entries(source.services).filter(([,dates])=>dates.includes(request.date)).map(([key])=>key));
result=table.rows.filter(r=>active.has(r[at.service_key])&&r[at.pickup_type]!==1&&!r[at.is_last_stop]&&(!request.pole_ids?.length||request.pole_ids.includes(r[at.same_pole_id]))).map(r=>Object.fromEntries(table.columns.map((c,i)=>[c,r[i]])));
}else throw Error('未対応の操作です');self.postMessage({id:request.id,result});
}catch(error){self.postMessage({id:request.id,error:error.message});}};

